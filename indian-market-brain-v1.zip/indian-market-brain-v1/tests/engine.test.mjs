import test from 'node:test';import assert from 'node:assert/strict';import {parseOhlc,analyze,positionRisk,sma,ema,rsi,atr,indiaMarketSession} from '../engine.mjs';import {lessons,strategies,answerQuestion,fibonacciStudy,sources} from '../knowledge.mjs';
const fixture=(amount=80,bias=3)=>{const a=['time,open,high,low,close,volume'];let last=25000;for(let i=0;i<amount;i++){let op=last;last+=bias+i%2;const t=new Date(Date.parse('2026-07-01T09:15:00+05:30')+i*86400000).toISOString();a.push(`${t},${op},${Math.max(last,op)+8},${Math.min(last,op)-8},${last},0`)}return a.join('\n')};
test('index scope explicitly excludes crypto and other benchmarks',()=>{let r=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(r.index,'NIFTY 50');assert.throws(()=>analyze(parseOhlc(fixture()),'BTC'),/NIFTY/);assert.equal(analyze(parseOhlc(fixture()),'SENSEX').index,'SENSEX')});
test('untrusted CSV is never a live signal',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.decision,'NO LIVE CALL');assert.equal(a.actualMarketFeedConnected,false);assert.match(a.source,/unverified/) });
test('60 to 80 real chronology verifies signal logic',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.trend,'UPTREND');assert.ok(a.rsi14>=0&&a.rsi14<=100);assert.ok(a.atr14>0);assert.equal(a.strategies.length,6)});
test('bearish research scenario does not place sell order',()=>{let a=analyze(parseOhlc(fixture(80,-10)),'SENSEX');assert.equal(a.trend,'DOWNTREND');assert.equal(a.decision,'NO LIVE CALL')});
test('min candles',()=>assert.throws(()=>parseOhlc(fixture(34)),/35/));
test('reject malformed count',()=>assert.throws(()=>parseOhlc(fixture().replace('time,open,high,low,close,volume','x')),/Row 1/));
test('reject invalid OHLC ordering',()=>{const f=fixture().split('\n');const cells=f[4].split(',');cells[2]='0';f[4]=cells.join(',');assert.throws(()=>parseOhlc(f.join('\n')),/invalid/) });
test('reject duplicate and reversed timestamps',()=>{const f=fixture().split('\n');f[5]=f[4];assert.throws(()=>parseOhlc(f.join('\n')),/chronological/)});
test('reject NaN',()=>{const f=fixture().split('\n');{const cells=f[4].split(',');cells[4]='Infinity';f[4]=cells.join(',');}assert.throws(()=>parseOhlc(f.join('\n')),/invalid/)});
test('reject timestamps with absent timezone',()=>{const f=fixture().split('\n');f[4]=f[4].replace('Z,',',');assert.throws(()=>parseOhlc(f.join('\n')),/timezone/)});
test('reject oversized payload',()=>assert.throws(()=>parseOhlc('x'.repeat(450001)),/450 KB/));
test('reject unreasonably future candle',()=>{const f=fixture().split('\n');f[f.length-1]=f.at(-1).replace('2026-09-18','2040-01-01');assert.throws(()=>parseOhlc(f.join('\n')),/future|chronological/)});
test('sma ema constant series',()=>{assert.equal(sma(Array(50).fill(100),20),100);assert.equal(ema(Array(50).fill(100),12),100)});
test('RSI constant 50, up 100, down 0',()=>{assert.equal(rsi(Array(30).fill(4)),50);assert.equal(rsi(Array.from({length:30},(_,i)=>i+1)),100);assert.equal(rsi(Array.from({length:30},(_,i)=>30-i)),0)});
test('risk calculator respects 2% cap',()=>{let r=positionRisk(100000,.5,25000,24900);assert.equal(r.budget,500);assert.equal(r.maxUnits,5);assert.throws(()=>positionRisk(100000,3,25000,24900),/risk/) });
test('market hours IST weekend closed',()=>{let s=indiaMarketSession(new Date('2026-10-25T10:00:00Z'));assert.equal(s.regularSession,false);assert.equal(s.holidayCalendarConnected,false)});
test('market hours IST weekday open',()=>{let s=indiaMarketSession(new Date('2026-10-26T05:00:00Z'));assert.equal(s.regularSession,true)});
test('lessons are substantial and BTC not in knowledge',()=>{assert.ok(lessons.length>=25);assert.ok(strategies.length>=15);assert.ok(lessons.every(l=>!l.join(' ').includes('BTC')))});
test('search curated topics',()=>{let r=answerQuestion('RBI monetary policy');assert.ok(r.length);assert.match(r[0].title,/RBI/);assert.deepEqual(answerQuestion(''),[])});

test('missing numeric field is rejected, not interpreted as zero',()=>{const a=fixture().split('\n');const f=a[4].split(',');f[5]='';a[4]=f.join(',');assert.throws(()=>parseOhlc(a.join('\n')),/missing/)})

test('video tutorial knowledge is explicitly in the deployed retrieval library',()=>{
 assert.ok(lessons.length>=36);
 assert.ok(strategies.length>=23);
 for(const term of ['Fibonacci retracement','Fibonacci three-anchor extension','Parallel ascending','Chart snapshots','trendlines','support and resistance']){
   assert.ok(lessons.some(([category,title])=>category==='Chart Tutorial'&&title.toLowerCase().includes(term.toLowerCase())),term);
 }
 assert.ok(sources.some(x=>x.url==='https://youtu.be/jwSIXMKTd9Q'));
 assert.ok(lessons.some(([cat,title])=>cat==='Chart Tutorial'&&title==='Fibonacci retracement'));
});
test('manual Fibonacci upswing and ABC projection calculations',()=>{
 const r=fibonacciStudy(24000,25000,24600);
 assert.equal(r.direction,'upswing');
 assert.equal(r.retracements.find(x=>x.ratio===0.382).level,24618);
 assert.equal(r.retracements.find(x=>x.ratio===0.618).level,24382);
 assert.equal(r.extensions.find(x=>x.ratio===1).level,25600);
 assert.equal(r.extensions.find(x=>x.ratio===1.618).level,26218);
 assert.match(r.status,/NO LIVE/);
});
test('manual Fibonacci downswing produces reversed price levels',()=>{
 const r=fibonacciStudy(25000,24000,24400);
 assert.equal(r.direction,'downswing');
 assert.equal(r.retracements.find(x=>x.ratio===0.382).level,24382);
 assert.equal(r.extensions.find(x=>x.ratio===1.618).level,22782);
});
test('Fibonacci excludes invalid, fabricated or outside retracement points',()=>{
 for(const v of [NaN,Infinity,-100,0,'25000'])assert.throws(()=>fibonacciStudy(v,26000),/positive finite/);
 assert.throws(()=>fibonacciStudy(25000,25000),/different/);
 for(const v of [25000,24000,27000,NaN])assert.throws(()=>fibonacciStudy(24000,25000,v),/Retracement C/);
 assert.equal(fibonacciStudy(24000,25000).extensions,null);
});

// Source-video v3 knowledge must ship with the live static bundle, not merely exist in conversation.
import {detectHistoricalZones} from '../engine.mjs';
test('second Tamil video knowledge and supply/demand references are indexed',()=>{
  assert.equal(lessons.filter(x=>x[0]==='Supply & Demand').length,12);assert.equal(strategies.filter(x=>x[1].includes('video 2018')).length,5);
  assert.ok(sources.some(x=>x.url==='https://youtu.be/-hua6K-GFZ0'));
  for(const term of ['Demand zone','Supply zone','Double-bottom','Indicators','Options premiums','Institutional trading claims']){
    assert.ok(lessons.some(([category,title])=>category==='Supply & Demand'&&title.toLowerCase().includes(term.toLowerCase())),term);
  }
  assert.equal(answerQuestion('demand zone')[0].category,'Supply & Demand');
  assert.ok(strategies.filter(x=>x[1].includes('video 2018')).length>=5);
});
const zoneFixture=(count=40)=>Array.from({length:count},(_,i)=>({time:Date.parse('2026-06-01T09:15:00+05:30')+i*86400000,open:100,high:101,low:99,close:100.5,volume:0}));
test('candidate zone only materializes after two right-side completed candles',()=>{
  let rows=zoneFixture();rows[38].low=95;rows[38].high=105;
  assert.equal(detectHistoricalZones(rows).zones.length,0);
  rows=zoneFixture();rows[35].low=95;rows[35].high=105;
  const z=detectHistoricalZones(rows);assert.equal(z.decision,'NO LIVE CALL');assert.equal(z.feed,'UNVERIFIED USER CSV');
  assert.equal(z.zones.length,2);assert.equal(z.zones.find(x=>x.type==='demand').low,95);
  assert.equal(z.zones.find(x=>x.type==='supply').high,105);
  assert.equal(z.zones.find(x=>x.type==='demand').pivotIndex,35);
  assert.equal(z.zones.find(x=>x.type==='demand').confirmedTime,new Date(rows[37].time).toISOString());
});
test('closing below demand invalidates that zone, without changing opposite supply',()=>{
  const rows=zoneFixture();rows[34].low=95;rows[34].high=105;rows[38].low=94;rows[38].close=94.5;
  const r=detectHistoricalZones(rows);
  assert.equal(r.candidates,2);assert.equal(r.invalidated,1);
  assert.deepEqual(r.zones.map(z=>z.type),['supply']);
});
test('closing above supply invalidates it but retains demand',()=>{
  const rows=zoneFixture();rows[34].low=95;rows[34].high=105;rows[38].high=108;rows[38].close=106;
  const r=detectHistoricalZones(rows);
  assert.equal(r.invalidated,1);assert.deepEqual(r.zones.map(z=>z.type),['demand']);
});
test('zone algorithm rejects malformed/missing chronological data and does not pretend to be a trade',()=>{
  assert.throws(()=>detectHistoricalZones([]),/seven/);
  assert.throws(()=>detectHistoricalZones(zoneFixture(),1),/pivot wings/);
  const r=zoneFixture();r[2].time=r[1].time;assert.throws(()=>detectHistoricalZones(r),/Invalid historical/);
  assert.equal(detectHistoricalZones(zoneFixture()).decision,'NO LIVE CALL');
});


// Third video is an educational discussion, not permission to issue live trades.
import {detectHistoricalDoubleTops} from '../engine.mjs';
test('third Indian price-action video is integrated into actual knowledge library',()=>{
 assert.equal(lessons.length,58);assert.equal(strategies.length,32);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/YJvYUOAjKWQ'));
 assert.equal(lessons.filter(x=>x[0]==='Price Action').length,10);
 for(const term of ['Double-top','Fibonacci 78.6%', 'Top-down daily', 'Aggressive versus conservative','Old price targets']){
  assert.ok(lessons.some(x=>x[0]==='Price Action'&&x[1].includes(term)),term);
 }
 assert.ok(answerQuestion('double top neckline').some(x=>x.title.toLowerCase().includes('double-top')));
 assert.ok(strategies.some(x=>x[0]==='Confirmed double-top neckline' && x[1].includes('Historical pattern study')));
});
const doubleFixture=(n=42)=>Array.from({length:n},(_,i)=>({time:Date.parse('2026-06-01T09:15:00+05:30')+i*86400000,open:100,high:101,low:99,close:100.5,volume:0}));
function withDoubleTop(n=42){let rows=doubleFixture(n);rows[20].high=110;rows[24].low=94;rows[28].high=109;return rows}
test('double top requires confirmed comparable highs and an intervening trough',()=>{
 const rows=withDoubleTop();const result=detectHistoricalDoubleTops(rows);
 assert.equal(result.decision,'NO LIVE CALL');assert.equal(result.source,'UNVERIFIED USER CSV');
 assert.equal(result.candidateCount,1);assert.equal(result.patterns[0].neckline,94);
 assert.equal(result.patterns[0].status,'AWAITING NECKLINE BREAK');assert.equal(result.patterns[0].confirmationIndex,30);
});
test('a neckline break is recognized only AFTER second high has been confirmed',()=>{
 const rows=withDoubleTop();rows[31].close=93;rows[31].low=92;
 const result=detectHistoricalDoubleTops(rows);assert.equal(result.patterns[0].status,'HISTORICAL BREAK CONFIRMED');
 assert.equal(result.patterns[0].eventIndex,31);
 assert.ok(result.patterns[0].eventIndex>result.patterns[0].confirmationIndex);
});
test('unconfirmed second high cannot produce hindsight double top',()=>{
 const rows=doubleFixture(42);rows[20].high=110;rows[24].low=94;rows[40].high=109;
 assert.equal(detectHistoricalDoubleTops(rows).candidateCount,0);
});
test('highs too different cannot be treated as double top',()=>{
 const rows=withDoubleTop();rows[28].high=103;
 assert.equal(detectHistoricalDoubleTops(rows).candidateCount,0);
});
test('invalidation of a double-top candidate is labeled and timestamped',()=>{
 const rows=withDoubleTop();rows[31].high=114;rows[31].close=113;
 const result=detectHistoricalDoubleTops(rows);assert.equal(result.patterns[0].status,'INVALIDATED');
 assert.equal(result.patterns[0].eventIndex,31);
});
test('validates malformed rows and invalid study parameters',()=>{
 const rows=withDoubleTop();rows[2].time=rows[1].time;
 assert.throws(()=>detectHistoricalDoubleTops(rows),/Invalid historical/);
 assert.throws(()=>detectHistoricalDoubleTops(withDoubleTop(),{tolerancePct:50}),/Unsupported/);
 assert.throws(()=>detectHistoricalDoubleTops(withDoubleTop(),{wing:1}),/pivot wings/);
});
test('no crypto live orders or outdated levels wired into Indian brain',()=>{
 assert.ok(lessons.every(x=>!x.join(' ').includes('BTC')));
 assert.match(lessons.find(x=>x[1]==='Old price targets and testimonials are not current proof')[2],/Never use old thresholds as live calls/);
});
