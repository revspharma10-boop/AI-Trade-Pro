import test from 'node:test';import assert from 'node:assert/strict';import {parseOhlc,analyze,positionRisk,sma,ema,rsi,atr,indiaMarketSession} from '../engine.mjs';import {lessons,strategies,answerQuestion} from '../knowledge.mjs';
const fixture=(amount=80,bias=3)=>{const a=['time,open,high,low,close,volume'];let last=25000;for(let i=0;i<amount;i++){let op=last;last+=bias+i%2;const t=new Date(Date.parse('2026-07-01T09:15:00+05:30')+i*86400000).toISOString();a.push(`${t},${op},${Math.max(last,op)+8},${Math.min(last,op)-8},${last},0`)}return a.join('\n')};
test('index scope explicitly excludes crypto and other benchmarks',()=>{let r=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(r.index,'NIFTY 50');assert.throws(()=>analyze(parseOhlc(fixture()),'BTC'),/NIFTY/);assert.equal(analyze(parseOhlc(fixture()),'SENSEX').index,'SENSEX')});
test('untrusted CSV is never a live signal',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.decision,'NO LIVE CALL');assert.equal(a.actualMarketFeedConnected,false);assert.match(a.source,/unverified/) });
test('60 to 80 real chronology verifies signal logic',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.trend,'UPTREND');assert.ok(a.rsi14>=0&&a.rsi14<=100);assert.ok(a.atr14>0);assert.equal(a.strategies.length,6)});
test('bearish research scenario does not place sell order',()=>{let a=analyze(parseOhlc(fixture(80,-10)),'SENSEX');assert.equal(a.trend,'DOWNTREND');assert.equal(a.decision,'NO LIVE CALL')});
test('min candles',()=>assert.throws(()=>parseOhlc(fixture(34)),/35/));
test('reject malformed count',()=>assert.throws(()=>parseOhlc(fixture().replace('time,open,high,low,close,volume','x')),/Row 1/));
test('reject invalid OHLC ordering',()=>{const f=fixture().split('\n');const cells=f[4].split(',');cells[2]='0';f[4]=cells.join(',');assert.throws(()=>parseOhlc(f.join('\n')),/invalid/) });
test('reject duplicate and reversed timestamps',()=>{const f=fixture().split('\n');f[5]=f[4];assert.throws(()=>parseOhlc(f.join('\n')),/chronological/)});
test('reject NaN',()=>{const f=fixture().split('\n');{const cells=f[4].split(',');cells[4]='Infinity';f[4]=cells.join(',');}assert.throws(()=>parseOhlc(f.join('\n')),/invalid/)});
test('reject timestamps with absent timezone',()=>{const f=fixture().split('\n');f[4]=f[4].replace('Z,',',');assert.throws(()=>parseOhlc(f.join('\n')),/timezone/)});
test('reject oversized payload',()=>assert.throws(()=>parseOhlc('x'.repeat(450001)),/450 KB/));
test('reject unreasonably future candle',()=>{const f=fixture().split('\n');f[f.length-1]=f.at(-1).replace('2026-09-18','2040-01-01');assert.throws(()=>parseOhlc(f.join('\n')),/future|chronological/)});
test('sma ema constant series',()=>{assert.equal(sma(Array(50).fill(100),20),100);assert.equal(ema(Array(50).fill(100),12),100)});
test('RSI constant 50, up 100, down 0',()=>{assert.equal(rsi(Array(30).fill(4)),50);assert.equal(rsi(Array.from({length:30},(_,i)=>i+1)),100);assert.equal(rsi(Array.from({length:30},(_,i)=>30-i)),0)});
test('risk calculator respects 2% cap',()=>{let r=positionRisk(100000,.5,25000,24900);assert.equal(r.budget,500);assert.equal(r.maxUnits,5);assert.throws(()=>positionRisk(100000,3,25000,24900),/risk/) });
test('market hours IST weekend closed',()=>{let s=indiaMarketSession(new Date('2026-10-25T10:00:00Z'));assert.equal(s.regularSession,false);assert.equal(s.holidayCalendarConnected,false)});
test('market hours IST weekday open',()=>{let s=indiaMarketSession(new Date('2026-10-26T05:00:00Z'));assert.equal(s.regularSession,true)});
test('lessons are substantial and BTC not in knowledge',()=>{assert.ok(lessons.length>=25);assert.ok(strategies.length>=15);assert.ok(lessons.every(l=>!l.join(' ').includes('BTC')))});
test('search curated topics',()=>{let r=answerQuestion('RBI monetary policy');assert.ok(r.length);assert.match(r[0].title,/RBI/);assert.deepEqual(answerQuestion(''),[])});

test('missing numeric field is rejected, not interpreted as zero',()=>{const a=fixture().split('\n');const f=a[4].split(',');f[5]='';a[4]=f.join(',');assert.throws(()=>parseOhlc(a.join('\n')),/missing/)})
