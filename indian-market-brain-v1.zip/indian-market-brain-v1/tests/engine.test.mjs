import test from 'node:test';import assert from 'node:assert/strict';import {parseOhlc,analyze,positionRisk,sma,ema,rsi,atr,indiaMarketSession} from '../engine.mjs';import {lessons,strategies,answerQuestion,fibonacciStudy,sources} from '../knowledge.mjs';
const fixture=(amount=80,bias=3)=>{const a=['time,open,high,low,close,volume'];let last=25000;for(let i=0;i<amount;i++){let op=last;last+=bias+i%2;const t=new Date(Date.parse('2026-07-01T09:15:00+05:30')+i*86400000).toISOString();a.push(`${t},${op},${Math.max(last,op)+8},${Math.min(last,op)-8},${last},0`)}return a.join('\n')};
test('index scope explicitly excludes crypto and other benchmarks',()=>{let r=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(r.index,'NIFTY 50');assert.throws(()=>analyze(parseOhlc(fixture()),'BTC'),/NIFTY/);assert.equal(analyze(parseOhlc(fixture()),'SENSEX').index,'SENSEX')});
test('untrusted CSV is never a live signal',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.decision,'NO LIVE CALL');assert.equal(a.actualMarketFeedConnected,false);assert.match(a.source,/unverified/) });
test('60 to 80 real chronology verifies signal logic',()=>{let a=analyze(parseOhlc(fixture()),'NIFTY50');assert.equal(a.trend,'UPTREND');assert.ok(a.rsi14>=0&&a.rsi14<=100);assert.ok(a.atr14>0);assert.equal(a.strategies.length,6)});
test('bearish research scenario does not place sell order',()=>{let a=analyze(parseOhlc(fixture(80,-10)),'SENSEX');assert.equal(a.trend,'DOWNTREND');assert.equal(a.decision,'NO LIVE CALL')});
test('min candles',()=>assert.throws(()=>parseOhlc(fixture(34)),/35/));
test('reject malformed count',()=>assert.throws(()=>parseOhlc(fixture().replace('time,open,high,low,close,volume','x')),/Row 1/));
test('reject invalid OHLC ordering',()=>{const f=fixture().split('\n');const cells=f[4].split(',');cells[2]='0';f[4]=cells.join(',');assert.throws(()=>parseOhlc(f.join('\n')),/invalid/) });
test('reject duplicate and reversed timestamps',()=>{const f=fixture().split('\n');f[5]=f[4];assert.throws(()=>parseOhlc(f.join('\n')),/chronological/)});
test('reject NaN',()=>{const f=fixture().split('\n');{const cells=f[4].split(',');cells[4]='Infinity';f[4]=cells.join(',');}assert.throws(()=>parseOhlc(f.join('\n')),/invalid/)});
test('reject timestamps with absent timezone',()=>{const f=fixture().split('\n');f[4]=f[4].replace('Z,',',');assert.throws(()=>parseOhlc(f.join('\n')),/timezone/)});
test('reject oversized payload',()=>assert.throws(()=>parseOhlc('x'.repeat(450001)),/450 KB/));
test('reject unreasonably future candle',()=>{const f=fixture().split('\n');f[f.length-1]=f.at(-1).replace('2026-09-18','2040-01-01');assert.throws(()=>parseOhlc(f.join('\n')),/future|chronological/)});
test('sma ema constant series',()=>{assert.equal(sma(Array(50).fill(100),20),100);assert.equal(ema(Array(50).fill(100),12),100)});
test('RSI constant 50, up 100, down 0',()=>{assert.equal(rsi(Array(30).fill(4)),50);assert.equal(rsi(Array.from({length:30},(_,i)=>i+1)),100);assert.equal(rsi(Array.from({length:30},(_,i)=>30-i)),0)});
test('risk calculator respects 2% cap',()=>{let r=positionRisk(100000,.5,25000,24900);assert.equal(r.budget,500);assert.equal(r.maxUnits,5);assert.throws(()=>positionRisk(100000,3,25000,24900),/risk/) });
test('market hours IST weekend closed',()=>{let s=indiaMarketSession(new Date('2026-10-25T10:00:00Z'));assert.equal(s.regularSession,false);assert.equal(s.holidayCalendarConnected,false)});
test('market hours IST weekday open',()=>{let s=indiaMarketSession(new Date('2026-10-26T05:00:00Z'));assert.equal(s.regularSession,true)});
test('lessons are substantial and BTC not in knowledge',()=>{assert.ok(lessons.length>=25);assert.ok(strategies.length>=15);assert.ok(lessons.every(l=>!l.join(' ').includes('BTC')))});
test('search curated topics',()=>{let r=answerQuestion('RBI monetary policy');assert.ok(r.length);assert.match(r[0].title,/RBI/);assert.deepEqual(answerQuestion(''),[])});

test('missing numeric field is rejected, not interpreted as zero',()=>{const a=fixture().split('\n');const f=a[4].split(',');f[5]='';a[4]=f.join(',');assert.throws(()=>parseOhlc(a.join('\n')),/missing/)})

test('video tutorial knowledge is explicitly in the deployed retrieval library',()=>{
 assert.ok(lessons.length>=36);
 assert.ok(strategies.length>=23);
 for(const term of ['Fibonacci retracement','Fibonacci three-anchor extension','Parallel ascending','Chart snapshots','trendlines','support and resistance']){
   assert.ok(lessons.some(([category,title])=>category==='Chart Tutorial'&&title.toLowerCase().includes(term.toLowerCase())),term);
 }
 assert.ok(sources.some(x=>x.url==='https://youtu.be/jwSIXMKTd9Q'));
 assert.ok(lessons.some(([cat,title])=>cat==='Chart Tutorial'&&title==='Fibonacci retracement'));
});
test('manual Fibonacci upswing and ABC projection calculations',()=>{
 const r=fibonacciStudy(24000,25000,24600);
 assert.equal(r.direction,'upswing');
 assert.equal(r.retracements.find(x=>x.ratio===0.382).level,24618);
 assert.equal(r.retracements.find(x=>x.ratio===0.618).level,24382);
 assert.equal(r.extensions.find(x=>x.ratio===1).level,25600);
 assert.equal(r.extensions.find(x=>x.ratio===1.618).level,26218);
 assert.match(r.status,/NO LIVE/);
});
test('manual Fibonacci downswing produces reversed price levels',()=>{
 const r=fibonacciStudy(25000,24000,24400);
 assert.equal(r.direction,'downswing');
 assert.equal(r.retracements.find(x=>x.ratio===0.382).level,24382);
 assert.equal(r.extensions.find(x=>x.ratio===1.618).level,22782);
});
test('Fibonacci excludes invalid, fabricated or outside retracement points',()=>{
 for(const v of [NaN,Infinity,-100,0,'25000'])assert.throws(()=>fibonacciStudy(v,26000),/positive finite/);
 assert.throws(()=>fibonacciStudy(25000,25000),/different/);
 for(const v of [25000,24000,27000,NaN])assert.throws(()=>fibonacciStudy(24000,25000,v),/Retracement C/);
 assert.equal(fibonacciStudy(24000,25000).extensions,null);
});

// Source-video v3 knowledge must ship with the live static bundle, not merely exist in conversation.
import {detectHistoricalZones} from '../engine.mjs';
test('second Tamil video knowledge and supply/demand references are indexed',()=>{
  assert.equal(lessons.filter(x=>x[0]==='Supply & Demand').length,12);assert.equal(strategies.filter(x=>x[1].includes('video 2018')).length,5);
  assert.ok(sources.some(x=>x.url==='https://youtu.be/-hua6K-GFZ0'));
  for(const term of ['Demand zone','Supply zone','Double-bottom','Indicators','Options premiums','Institutional trading claims']){
    assert.ok(lessons.some(([category,title])=>category==='Supply & Demand'&&title.toLowerCase().includes(term.toLowerCase())),term);
  }
  assert.equal(answerQuestion('demand zone')[0].category,'Supply & Demand');
  assert.ok(strategies.filter(x=>x[1].includes('video 2018')).length>=5);
});
const zoneFixture=(count=40)=>Array.from({length:count},(_,i)=>({time:Date.parse('2026-06-01T09:15:00+05:30')+i*86400000,open:100,high:101,low:99,close:100.5,volume:0}));
test('candidate zone only materializes after two right-side completed candles',()=>{
  let rows=zoneFixture();rows[38].low=95;rows[38].high=105;
  assert.equal(detectHistoricalZones(rows).zones.length,0);
  rows=zoneFixture();rows[35].low=95;rows[35].high=105;
  const z=detectHistoricalZones(rows);assert.equal(z.decision,'NO LIVE CALL');assert.equal(z.feed,'UNVERIFIED USER CSV');
  assert.equal(z.zones.length,2);assert.equal(z.zones.find(x=>x.type==='demand').low,95);
  assert.equal(z.zones.find(x=>x.type==='supply').high,105);
  assert.equal(z.zones.find(x=>x.type==='demand').pivotIndex,35);
  assert.equal(z.zones.find(x=>x.type==='demand').confirmedTime,new Date(rows[37].time).toISOString());
});
test('closing below demand invalidates that zone, without changing opposite supply',()=>{
  const rows=zoneFixture();rows[34].low=95;rows[34].high=105;rows[38].low=94;rows[38].close=94.5;
  const r=detectHistoricalZones(rows);
  assert.equal(r.candidates,2);assert.equal(r.invalidated,1);
  assert.deepEqual(r.zones.map(z=>z.type),['supply']);
});
test('closing above supply invalidates it but retains demand',()=>{
  const rows=zoneFixture();rows[34].low=95;rows[34].high=105;rows[38].high=108;rows[38].close=106;
  const r=detectHistoricalZones(rows);
  assert.equal(r.invalidated,1);assert.deepEqual(r.zones.map(z=>z.type),['demand']);
});
test('zone algorithm rejects malformed/missing chronological data and does not pretend to be a trade',()=>{
  assert.throws(()=>detectHistoricalZones([]),/seven/);
  assert.throws(()=>detectHistoricalZones(zoneFixture(),1),/pivot wings/);
  const r=zoneFixture();r[2].time=r[1].time;assert.throws(()=>detectHistoricalZones(r),/Invalid historical/);
  assert.equal(detectHistoricalZones(zoneFixture()).decision,'NO LIVE CALL');
});


// Third video is an educational discussion, not permission to issue live trades.
import {detectHistoricalDoubleTops} from '../engine.mjs';
test('third Indian price-action video is integrated into actual knowledge library',()=>{
 assert.equal(lessons.length,102);assert.equal(strategies.length,50);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/YJvYUOAjKWQ'));
 assert.equal(lessons.filter(x=>x[0]==='Price Action').length,10);
 for(const term of ['Double-top','Fibonacci 78.6%', 'Top-down daily', 'Aggressive versus conservative','Old price targets']){
  assert.ok(lessons.some(x=>x[0]==='Price Action'&&x[1].includes(term)),term);
 }
 assert.ok(answerQuestion('double top neckline').some(x=>x.title.toLowerCase().includes('double-top')));
 assert.ok(strategies.some(x=>x[0]==='Confirmed double-top neckline' && x[1].includes('Historical pattern study')));
});
const doubleFixture=(n=42)=>Array.from({length:n},(_,i)=>({time:Date.parse('2026-06-01T09:15:00+05:30')+i*86400000,open:100,high:101,low:99,close:100.5,volume:0}));
function withDoubleTop(n=42){let rows=doubleFixture(n);rows[20].high=110;rows[24].low=94;rows[28].high=109;return rows}
test('double top requires confirmed comparable highs and an intervening trough',()=>{
 const rows=withDoubleTop();const result=detectHistoricalDoubleTops(rows);
 assert.equal(result.decision,'NO LIVE CALL');assert.equal(result.source,'UNVERIFIED USER CSV');
 assert.equal(result.candidateCount,1);assert.equal(result.patterns[0].neckline,94);
 assert.equal(result.patterns[0].status,'AWAITING NECKLINE BREAK');assert.equal(result.patterns[0].confirmationIndex,30);
});
test('a neckline break is recognized only AFTER second high has been confirmed',()=>{
 const rows=withDoubleTop();rows[31].close=93;rows[31].low=92;
 const result=detectHistoricalDoubleTops(rows);assert.equal(result.patterns[0].status,'HISTORICAL BREAK CONFIRMED');
 assert.equal(result.patterns[0].eventIndex,31);
 assert.ok(result.patterns[0].eventIndex>result.patterns[0].confirmationIndex);
});
test('unconfirmed second high cannot produce hindsight double top',()=>{
 const rows=doubleFixture(42);rows[20].high=110;rows[24].low=94;rows[40].high=109;
 assert.equal(detectHistoricalDoubleTops(rows).candidateCount,0);
});
test('highs too different cannot be treated as double top',()=>{
 const rows=withDoubleTop();rows[28].high=103;
 assert.equal(detectHistoricalDoubleTops(rows).candidateCount,0);
});
test('invalidation of a double-top candidate is labeled and timestamped',()=>{
 const rows=withDoubleTop();rows[31].high=114;rows[31].close=113;
 const result=detectHistoricalDoubleTops(rows);assert.equal(result.patterns[0].status,'INVALIDATED');
 assert.equal(result.patterns[0].eventIndex,31);
});
test('validates malformed rows and invalid study parameters',()=>{
 const rows=withDoubleTop();rows[2].time=rows[1].time;
 assert.throws(()=>detectHistoricalDoubleTops(rows),/Invalid historical/);
 assert.throws(()=>detectHistoricalDoubleTops(withDoubleTop(),{tolerancePct:50}),/Unsupported/);
 assert.throws(()=>detectHistoricalDoubleTops(withDoubleTop(),{wing:1}),/pivot wings/);
});
test('no crypto live orders or outdated levels wired into Indian brain',()=>{
 assert.ok(lessons.every(x=>!x.join(' ').includes('BTC')));
 assert.match(lessons.find(x=>x[1]==='Old price targets and testimonials are not current proof')[2],/Never use old thresholds as live calls/);
});


// Fourth video: defined and reproducible price compression, never a live signal.
import {detectHistoricalInsideBars} from '../engine.mjs';
const insideFixture=(n=40)=>Array.from({length:n},(_,i)=>({time:Date.parse('2026-08-01T09:15:00+05:30')+i*86400000,open:100,high:102,low:98,close:100,volume:0}));
test('inside bar knowledge and sources are shipped in the searchable Indian library',()=>{
 assert.equal(lessons.length,102);assert.equal(strategies.length,50);
 assert.equal(lessons.filter(x=>x[0]==='Inside Bar').length,11);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/lj12i9y-Sm0'));
 for(const term of ['Mother candle','Nested consolidation','Close-confirmed breakout','Wick-only','Round-number','Invalidation'])assert.ok(lessons.some(x=>x[0]==='Inside Bar'&&x[1].toLowerCase().includes(term.toLowerCase())),term);
 assert.ok(answerQuestion('inside bar mother candle').some(x=>x.category==='Inside Bar'));
 assert.equal(strategies.filter(x=>x[1].includes('2026 inside-bar video')).length,5);
});
function configuredInside(n=40){const rows=insideFixture(n);rows[20]={...rows[20],open:100,high:110,low:90,close:101};rows[21]={...rows[21],open:100,high:105,low:95,close:101};return rows;}
test('inside bar is direction-neutral until a later complete candle closes outside the mother range',()=>{
 const rows=configuredInside(22);const r=detectHistoricalInsideBars(rows);
 assert.equal(r.decision,'NO LIVE CALL');assert.equal(r.confirmedBreaks,0);assert.ok(r.patterns.some(x=>x.motherIndex===20 && x.status==='AWAITING CLOSE BREAK'));
});
test('a completed bullish or bearish close-break belongs to the later candle, never the mother bar',()=>{
 const up=configuredInside();up[22]={...up[22],open:104,high:113,low:103,close:111};
 const r=detectHistoricalInsideBars(up);const e=r.patterns.find(x=>x.motherIndex===20);
 assert.equal(e.status,'UP CLOSE BREAK');assert.equal(e.breakIndex,22);assert.equal(e.breakClose,111);assert.ok(new Date(e.breakTime).getTime()>new Date(e.firstInsideTime).getTime());
 const down=configuredInside();down[22]={...down[22],open:96,high:97,low:88,close:89};
 const r2=detectHistoricalInsideBars(down);assert.equal(r2.patterns.find(x=>x.motherIndex===20).status,'DOWN CLOSE BREAK');
});
test('wick outside mother range and close inside is not a breakout',()=>{
 const rows=configuredInside(23);rows[22]={...rows[22],open:101,high:112,low:97,close:103};
 const r=detectHistoricalInsideBars(rows);const e=r.patterns.find(x=>x.motherIndex===20);
 assert.equal(e.status,'AWAITING CLOSE BREAK');assert.equal(e.wickOnlyProbes,1);assert.equal(e.breakTime,null);
});
test('strict containment excludes equal or outside bars as initial inside bar',()=>{
 const rows=insideFixture(5);rows[1]={...rows[1],high:102,low:99};assert.equal(detectHistoricalInsideBars(rows).candidateCount,0);
});
test('subsequent strictly inside candles share the same mother and count once',()=>{
 const rows=configuredInside(23);rows[22]={...rows[22],high:107,low:94,close:100};
 const e=detectHistoricalInsideBars(rows).patterns.find(x=>x.motherIndex===20);assert.equal(e.insideCandles,2);assert.equal(e.status,'AWAITING CLOSE BREAK');
});
test('inside bar study rejects malformed/out-of-order data and insufficient history',()=>{
 assert.throws(()=>detectHistoricalInsideBars([]),/4–3000/);
 const rows=configuredInside();rows[5].time=rows[4].time;assert.throws(()=>detectHistoricalInsideBars(rows),/Invalid historical/);
 const bad=configuredInside();bad[9].close=999;assert.throws(()=>detectHistoricalInsideBars(bad),/Invalid historical/);
});
test('Indian browser UI wires pattern render, lesson filter and fail-closed data clearing',async()=>{
 const {readFile}=await import('node:fs/promises');const html=await readFile(new URL('../index.html',import.meta.url),'utf8');const js=await readFile(new URL('../app.mjs',import.meta.url),'utf8');
 for(const k of ['id="inside-results"','id="inside-chapters"','data-category="Inside Bar"'])assert.ok(html.includes(k),k);
 for(const k of ['showHistoricalInsideBars(rows)','Inside-bar study unavailable','Inside-bar study cleared.','lj12i9y-Sm0'])assert.ok(js.includes(k),k);
});


// Fifth source: rule-based classifications from October 2026 Tamil spinning-top video.
import {detectHistoricalIndecisionCandles} from '../engine.mjs';
const indecisionFixture=(n=20)=>Array.from({length:n},(_,i)=>({time:Date.parse('2026-10-01T15:30:00+05:30')+i*86400000,open:99,high:103,low:97,close:101,volume:0}));
const spinSetup=(n=20)=>{const rows=indecisionFixture(n);rows[12]={...rows[12],open:98,high:110,low:90,close:102};return rows;};
test('fifth video knowledge and timestamped original video are included in deployed library',async()=>{
 assert.equal(lessons.length,102);assert.equal(strategies.length,50);
 assert.equal(lessons.filter(x=>x[0]==='Indecision Candles').length,11);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/oyqbwKMVHjo'));
 assert.ok(answerQuestion('spinning top indecision').some(x=>x.category==='Indecision Candles'));
 assert.ok(lessons.some(x=>x[1].includes('Long-legged doji')));
 assert.equal(strategies.filter(x=>x[1].includes('2026 spinning-top video')).length,5);
});
test('spinning top is neutral when no next close breaks its high-low range',()=>{
 const rows=spinSetup(13);const r=detectHistoricalIndecisionCandles(rows);
 const candidate=r.patterns.find(x=>x.candleIndex===12);
 assert.equal(candidate.type,'SPINNING TOP');assert.equal(candidate.confirmation,'AWAITING NEXT CANDLE');
 assert.equal(candidate.confirmationTime,null);assert.equal(r.decision,'NO LIVE CALL');
});
test('candle color alone and wick-only excursion do NOT confirm a spinning top',()=>{
 const rows=spinSetup(14);rows[13]={...rows[13],open:102,high:113,low:98,close:108};
 const candidate=detectHistoricalIndecisionCandles(rows).patterns.find(x=>x.candleIndex===12);
 assert.equal(candidate.confirmation,'NO CLOSE-THROUGH');assert.equal(candidate.confirmationIndex,13);
});
test('later strong close beyond top or bottom is attributed to following completed candle only',()=>{
 let rows=spinSetup(14);rows[13]={...rows[13],open:101,high:118,low:100,close:113};
 let cand=detectHistoricalIndecisionCandles(rows).patterns.find(x=>x.candleIndex===12);
 assert.equal(cand.confirmation,'HISTORICAL UP CLOSE BREAK');assert.equal(cand.confirmationIndex,13);
 assert.ok(new Date(cand.confirmationTime).getTime()>new Date(cand.candleTime).getTime());
 rows=spinSetup(14);rows[13]={...rows[13],open:100,high:101,low:82,close:86};
 cand=detectHistoricalIndecisionCandles(rows).patterns.find(x=>x.candleIndex===12);
 assert.equal(cand.confirmation,'HISTORICAL DOWN CLOSE BREAK');
});
test('weak next body outside range must be rejected',()=>{
 const rows=spinSetup(14);rows[13]={...rows[13],open:111,high:114,low:99,close:112};
 const cand=detectHistoricalIndecisionCandles(rows).patterns.find(x=>x.candleIndex===12);
 assert.equal(cand.confirmation,'UNCONFIRMED SMALL-BODY BREAK');
});
test('doji and long-legged doji are distinguishable without predicting direction',()=>{
 const a=spinSetup(14);a[12]={...a[12],open:100,close:100.1,high:110,low:90};
 assert.equal(detectHistoricalIndecisionCandles(a).patterns.find(x=>x.candleIndex===12).type,'LONG-LEGGED DOJI');
 a[12]={...a[12],open:104,close:104.1,high:110,low:90};
 assert.equal(detectHistoricalIndecisionCandles(a).patterns.find(x=>x.candleIndex===12).type,'DOJI');
});
test('prior only range-middle classification is cautious and independent of next candle',()=>{
 const rows=spinSetup(13);rows[12].close=100;
 const cand=detectHistoricalIndecisionCandles(rows).patterns.find(x=>x.candleIndex===12);
 assert.equal(cand.rangePosition,'MIDDLE OF RECENT RANGE (CAUTION)');
 assert.equal(cand.confirmation,'AWAITING NEXT CANDLE');
});
test('indecision study refuses malformed, unsequenced and untrusted input; no live broker',()=>{
 assert.throws(()=>detectHistoricalIndecisionCandles([]),/4–3000/);
 const a=spinSetup(14);a[3].time=a[2].time;
 assert.throws(()=>detectHistoricalIndecisionCandles(a),/Invalid completed/);
 const b=spinSetup(14);b[12].close=500;
 assert.throws(()=>detectHistoricalIndecisionCandles(b),/Invalid completed/);
 assert.throws(()=>detectHistoricalIndecisionCandles(spinSetup(14),{dojiBodyMax:.8}),/thresholds/);
 assert.equal(detectHistoricalIndecisionCandles(spinSetup(14)).source,'UNVERIFIED USER CSV');
});
test('fifth-video browser wiring, category, clear/error states and timestamped chapter links',async()=>{
 const {readFile}=await import('node:fs/promises');
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const app=await readFile(new URL('../app.mjs',import.meta.url),'utf8');
 for(const needle of ['id="indecision-results"','id="indecision-chapters"','data-category="Indecision Candles"','oyqbwKMVHjo'])assert.ok(html.includes(needle),needle);
 for(const needle of ['showHistoricalIndecision(rows)','Indecision study unavailable','Indecision study cleared.','oyqbwKMVHjo'])assert.ok(app.includes(needle),needle);
 const opening=(html.match(/<section(?:\s|>)/g)||[]).length,closing=(html.match(/<\/section>/g)||[]).length;
 assert.equal(opening,closing);
});

import {detectHistoricalReversalCandles} from '../engine.mjs';
function trendCandles(direction='down',n=13){
 return Array.from({length:n},(_,i)=>{const v=direction==='down'?130-i*2:90+i*2;return {time:Date.parse('2026-08-01T09:15:00+05:30')+i*86400000,open:v-.3,high:v+1,low:v-1,close:v,volume:0}});
}
function setPattern(arr,shape){const i=12;
 const specs={hammer:[105,107,97,106],inverted:[100,110,99,101],hanging:[115,117,107,116],shooting:[115,123,114,116],dragonfly:[106,106.3,97,106],gravestone:[116,125,115.7,116]};
 const [open,high,low,close]=specs[shape];Object.assign(arr[i],{open,high,low,close});return arr;
}
function appendConfirm(arr,open,high,low,close){arr.push({time:arr.at(-1).time+86400000,open,high,low,close,volume:0});return arr}
test('reversal video lessons, source and six candlestick terms are searchable in deployed knowledge',()=>{
 assert.equal(lessons.length,102);assert.equal(strategies.length,50);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/UGxJRkP42YQ'));
 assert.equal(lessons.filter(x=>x[0]==='Reversal Candles').length,12);
 for(const term of ['Hammer','Hanging man','Dragonfly','Gravestone','Shooting star','Correction'])
  assert.ok(lessons.some(x=>x[0]==='Reversal Candles'&&x[1].toLowerCase().includes(term.toLowerCase())),term);
 assert.ok(answerQuestion('dragonfly doji support').some(x=>x.category==='Reversal Candles'));
});
test('bottom lower wick identifies hammer, requires completed next candle for historical confirmation',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');const r=detectHistoricalReversalCandles(rows);
 const p=r.patterns.find(x=>x.formationIndex===12);assert.equal(p.type,'HAMMER');assert.equal(p.confirmation,'AWAITING NEXT COMPLETED CANDLE');assert.equal(p.confirmationIndex,null);assert.equal(r.decision,'NO LIVE CALL');
 appendConfirm(rows,106,113,105,111);const after=detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12);
 assert.equal(after.confirmation,'HISTORICAL CLOSE CONFIRMED');assert.equal(after.confirmationIndex,13);assert.equal(after.direction,'UP');
});
test('inverted hammer at lows has dominant upper wick despite different name from shooting star',()=>{
 const rows=setPattern(trendCandles('down'),'inverted');
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).type,'INVERTED HAMMER');
});
test('high context makes a hanging man, not a hammer',()=>{
 const rows=setPattern(trendCandles('up'),'hanging');
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).type,'HANGING MAN');
 appendConfirm(rows,113,114,102,104);assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).confirmation,'HISTORICAL CLOSE CONFIRMED');
});
test('shooting star is a bearish high-context candidate with upper wick',()=>{
 const rows=setPattern(trendCandles('up'),'shooting');
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).type,'SHOOTING STAR');
});
test('dragonfly doji classifies near-equal open/close and long lower tail after decline',()=>{
 const rows=setPattern(trendCandles('down'),'dragonfly');
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).type,'DRAGONFLY DOJI');
});
test('gravestone doji classifies near-equal open/close and long upper tail after advance',()=>{
 const rows=setPattern(trendCandles('up'),'gravestone');
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).type,'GRAVESTONE DOJI');
});
test('directional candle color without full-range close-through is not confirmation',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');
 appendConfirm(rows,106,107,104,106.5);const p=detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12);
 assert.equal(p.confirmation,'NO CLOSE-THROUGH');assert.equal(p.confirmationTime,new Date(rows[13].time).toISOString());
});
test('wick-only excursion past pattern extreme remains unconfirmed',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');
 appendConfirm(rows,106,110,105,106.5);
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).confirmation,'WICK ONLY — UNCONFIRMED');
});
test('weak-body close outside full range is unconfirmed',()=>{
 const rows=setPattern(trendCandles('up'),'shooting');
 appendConfirm(rows,113,130,109,112); // closes below shooting-star low=114, but tiny body relative to range
 assert.equal(detectHistoricalReversalCandles(rows).patterns.find(x=>x.formationIndex===12).confirmation,'WEAK BODY — UNCONFIRMED');
});
test('no pattern when chart lacks prior top/bottom trend direction',()=>{
 const rows=trendCandles('down');for(let j=0;j<12;j++){Object.assign(rows[j],{open:100,high:101,low:99,close:100})};setPattern(rows,'hammer');
 assert.equal(detectHistoricalReversalCandles(rows).candidateCount,0);
});
test('reversal study validates finite ordered completed price data and ratios',()=>{
 assert.throws(()=>detectHistoricalReversalCandles([]),/sufficient/);
 assert.throws(()=>detectHistoricalReversalCandles(trendCandles('down'),{longWickMin:.1}),/thresholds/);
 const rows=setPattern(trendCandles('down'),'hammer');rows[12].time=rows[11].time;
 assert.throws(()=>detectHistoricalReversalCandles(rows),/Invalid historical reversal/);
});
test('sixth video browser wiring, source chapter links, clear and error states',async()=>{
 const {readFile}=await import('node:fs/promises');
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const app=await readFile(new URL('../app.mjs',import.meta.url),'utf8');
 for(const needle of ['id="reversal-results"','id="reversal-chapters"','data-category="Reversal Candles"','UGxJRkP42YQ'])assert.ok(html.includes(needle),needle);
 for(const needle of ['showHistoricalReversals(rows)','Reversal study unavailable','Reversal study cleared.','UGxJRkP42YQ'])assert.ok(app.includes(needle),needle);
 assert.equal((html.match(/<section(?:\s|>)/g)||[]).length,(html.match(/<\/section>/g)||[]).length);
});


// Seventh video: Hammer and Hanging Man (9 Oct 2026): overlap with sixth,
// but its own searchable lessons and historical confirmation audit are tested.
import {auditHistoricalHammerHanging} from '../engine.mjs';
test('video seven Tamil lesson is truly searchable with its own timestamped source',()=>{
 assert.equal(lessons.length,102);assert.equal(strategies.length,50);
 assert.equal(lessons.filter(x=>x[0]==='Hammer & Hanging Man').length,10);
 assert.ok(sources.some(x=>x.url==='https://youtu.be/0j8x6ZBDtMo'));
 for(const term of ['Hammer lower shadow','Hanging man','Support exception','Resistance exception','next-candle'])
  assert.ok(lessons.some(x=>x[0]==='Hammer & Hanging Man'&&x[1].toLowerCase().includes(term.toLowerCase())),term);
 assert.ok(answerQuestion('hanging man prior trend').length>0);
});
test('historical hammer audit awaits next completed candle, then confirms only close-through',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');let r=auditHistoricalHammerHanging(rows);
 assert.equal(r.hammer,1);assert.equal(r.hangingMan,0);assert.equal(r.confirmed,0);assert.equal(r.awaiting,1);assert.equal(r.unconfirmed,0);
 assert.equal(r.patterns[0].confirmationIndex,null);assert.equal(r.decision,'NO LIVE CALL');
 appendConfirm(rows,106,113,105,111);r=auditHistoricalHammerHanging(rows);
 assert.equal(r.confirmed,1);assert.equal(r.awaiting,0);assert.equal(r.patterns[0].confirmationIndex,13);
 assert.ok(new Date(r.patterns[0].confirmationTime)>new Date(r.patterns[0].formationTime));
});
test('hanging man audit confirms below candle low after preceding rise',()=>{
 const rows=setPattern(trendCandles('up'),'hanging');appendConfirm(rows,113,114,102,103);
 const r=auditHistoricalHammerHanging(rows);
 assert.equal(r.hammer,0);assert.equal(r.hangingMan,1);assert.equal(r.confirmed,1);
 assert.equal(r.patterns[0].type,'HANGING MAN');
});
test('opposite or inside-range following candle does not become BUY/SELL confirmation',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');appendConfirm(rows,106,108,104,107);
 const r=auditHistoricalHammerHanging(rows);
 assert.equal(r.totalCandidates,1);assert.equal(r.confirmed,0);assert.equal(r.unconfirmed,1);
 assert.equal(r.patterns[0].confirmation,'WICK ONLY — UNCONFIRMED');
});
test('historical audit labels weak-body range-break as unconfirmed',()=>{
 const rows=setPattern(trendCandles('down'),'hammer');appendConfirm(rows,111,117,99,112);
 const r=auditHistoricalHammerHanging(rows);
 assert.equal(r.totalCandidates,1);assert.equal(r.confirmed,0);assert.equal(r.unconfirmed,1);
 assert.equal(r.patterns[0].confirmation,'WEAK BODY — UNCONFIRMED');
});
test('wrong prior trend does not qualify as a hammer or hanging man',()=>{
 const rows=trendCandles('down');for(let j=0;j<12;j++)Object.assign(rows[j],{open:100,high:101,low:99,close:100});
 setPattern(rows,'hammer');const r=auditHistoricalHammerHanging(rows);
 assert.equal(r.totalCandidates,0);assert.equal(r.confirmed,0);assert.equal(r.awaiting,0);
});
test('audit rejects invalid sequence and forbidden threshold values',()=>{
 assert.throws(()=>auditHistoricalHammerHanging([]),/sufficient/);
 const rows=setPattern(trendCandles('down'),'hammer');rows[12].time=rows[11].time;
 assert.throws(()=>auditHistoricalHammerHanging(rows),/Invalid historical reversal/);
 assert.throws(()=>auditHistoricalHammerHanging(setPattern(trendCandles('down'),'hammer'),{lookback:3}),/thresholds/);
});
test('seventh-video browser wiring, chapter links, counts and clear/error behavior',async()=>{
 const {readFile}=await import('node:fs/promises');
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const app=await readFile(new URL('../app.mjs',import.meta.url),'utf8');
 for(const part of ['id="hammer-results"','id="hammer-chapters"','data-category="Hammer &amp; Hanging Man"','0j8x6ZBDtMo'])assert.ok(html.includes(part),part);
 for(const part of ['showHistoricalHammerAudit(rows)','Hammer/hanging-man study cleared.','Hammer/hanging-man audit unavailable','0j8x6ZBDtMo'])assert.ok(app.includes(part),part);
 assert.equal((html.match(/<section(?:\s|>)/g)||[]).length,(html.match(/<\/section>/g)||[]).length);
});
