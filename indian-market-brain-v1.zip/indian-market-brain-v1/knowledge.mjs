export const sources=Object.freeze([
 {label:'NSE — NIFTY 50 index',url:'https://www.nseindia.com/static/products-services/indices-nifty50-index'},
 {label:'NSE — Trading session timings',url:'https://www.nseindia.com/static/market-data/market-timings'},
 {label:'NSE — Licensed real-time data',url:'https://www.nseindia.com/static/market-data/real-time-data-subscription'},
 {label:'NSE — Index data subscription',url:'https://www.nseindia.com/static/nse-indices/index-data-subscription'},
 {label:'SEBI — Derivatives risk education',url:'https://investor.sebi.gov.in/understanding_derivatives.html'},
 {label:'Trade Achievers (2017) — Investing.com charting tutorial (video education only)',url:'https://youtu.be/jwSIXMKTd9Q'},
 {label:'Trade Achievers (2018) — Supply and demand video (Tamil, imperfect auto captions)',url:'https://youtu.be/-hua6K-GFZ0'},
 {label:'Trade Achievers (2018) — Live-market script analysis and price action (Tamil, imperfect auto captions)',url:'https://youtu.be/YJvYUOAjKWQ'},
 {label:'Trade Achievers (2026) — Inside bar candlestick pattern, lesson 17 (imperfect automated captions)',url:'https://youtu.be/lj12i9y-Sm0'},
 {label:'SEBI — Equity F&O loss study',url:'https://www.sebi.gov.in/media-and-notifications/press-releases/sep-2024/updated-sebi-study-reveals-93-of-individual-traders-incurred-losses-in-equity-fando-between-fy22-and-fy24-aggregate-losses-exceed-1-8-lakh-crores-over-three-years_86906.html'}
]);
// Deliberately curated and explicitly limited to Indian equity benchmarks.
export const lessons=[
 ['Basics','What is NIFTY 50?','The NIFTY 50 is a free-float market-capitalization-weighted Indian equity index of 50 constituent securities, maintained by NSE Indices. It is an index level, not a directly purchasable share. An ETF or derivative creates tradable exposure.'],
 ['Basics','What is SENSEX?','The BSE SENSEX is a broad Indian large-company benchmark tracking 30 constituents, with free-float-adjusted market-capitalization weighting. It reflects the performance of its basket, not the trade price of a single security.'],
 ['Basics','How index prices move','An index rises when weighted gains across its constituents outweigh weighted declines, and falls when the reverse occurs. Large-weight constituents can dominate even when most stocks move differently.'],
 ['Basics','How an index is traded','An index cannot be delivered like a share. Traders access benchmark exposure via index-tracking ETFs, futures or options. Contracts introduce basis, margin and expiry risks.'],
 ['Basics','NSE and BSE sessions','Regular equity trading is generally 09:15–15:30 IST on eligible trading days. Holidays, special sessions, auctions, and derivatives schedules require exchange-calendar verification.'],
 ['Fundamentals','RBI monetary policy','Policy rates influence borrowing costs, discount rates, bank margins, bond yields and investor risk appetite. The same announcement can affect industries differently; surprises relative to expectations matter.'],
 ['Fundamentals','Inflation, yields and valuations','Higher expected rates can reduce the present value investors assign to future earnings, but inflation effects depend on pricing power, growth and policy expectations.'],
 ['Fundamentals','Corporate earnings','Index performance is ultimately connected to profit growth, margins, guidance, and valuations among its constituents. One company can have outsized impact through index weight.'],
 ['Fundamentals','FII / DII flows','Foreign and domestic institutional buying/selling can correlate with market pressure. Aggregate flow summaries can include offsetting activity and do not mechanically predict the next index candle.'],
 ['Fundamentals','USD/INR and crude oil','Rupee depreciation affects importers and exporters differently; oil prices affect India’s import bill and many sectors. Always examine the direction and nature of the shock.'],
 ['Fundamentals','Sector rotation and breadth','A headline index rally led by just a few large stocks may have weak breadth. Advance/decline breadth requires actual constituent data, not index OHLC alone.'],
 ['Technical','Support and resistance','Past swing highs/lows and high-volume areas are candidate reference levels, not guaranteed barriers. Breakouts should be checked for participation and false-break risk.'],
 ['Technical','EMA and SMA trends','Moving averages smooth historical closes. EMA12–EMA26 momentum can describe trend direction but lags turning points and often whipsaws in sideways periods.'],
 ['Technical','RSI momentum','RSI14 tracks average up versus down closes on a 0–100 scale. Overbought is not an automatic sell and oversold is not an automatic buy.'],
 ['Technical','ATR volatility','Average True Range measures range magnitude including gaps; it is non-directional. Use volatility for stop distances and position sizing, not for price forecasts.'],
 ['Technical','VWAP trading','Volume-weighted average price is meaningful with traded instrument-level intraday volume. A benchmark index OHLC file without constituent or derivative trade volume cannot support an authentic VWAP.'],
 ['Derivatives','Futures basis','Index futures may differ from the spot index because of financing, dividends, expiry, demand and market frictions. Basis can change without spot direction reversing.'],
 ['Derivatives','Options premium','Option value reflects underlying level, strike, time to expiry, implied volatility, interest rates and dividends. A correct directional call can still lose due to premium decay.'],
 ['Derivatives','Open interest interpretation','Increasing OI means more outstanding futures/options positions, not automatically new buyers. Read alongside price, option strikes, volume and implied volatility.'],
 ['Derivatives','Put-call ratio (PCR)','PCR describes option put versus call activity or outstanding positions under a specified definition. It does not reliably indicate direction on its own.'],
 ['Derivatives','Option Greeks','Delta measures price sensitivity to the underlying, gamma delta sensitivity, theta time decay and vega implied volatility sensitivity. Risks rise around short-dated options and events.'],
 ['Derivatives','Expiry and max pain','Expiry can drive hedging and position changes. “Max pain” is a descriptive calculation, not a force pulling prices to a guaranteed settlement.'],
 ['Risk','Why index F&O is risky','Leverage, gaps, margin and rapid time decay can overwhelm an apparently correct idea. SEBI documents that most individual equity F&O traders incur losses.'],
 ['Risk','Position sizing','Decide capital at risk before entry; use distance to invalidation and the instrument’s true lot size, tick, premium, fees and margins. Do not size directly from index points.'],
 ['Risk','Backtesting pitfalls','Avoid look-ahead bias, survivorship bias, overfitting, ignoring fees, and choosing a strategy only because it performs on past samples. Use walk-forward and out-of-sample checks.'],
 ['Risk','Data provenance','Only licensed and timestamped data can be displayed as live NSE/BSE quotes. An uploaded CSV is research input. Index-level “buy/sell ratio” cannot be derived from index price movement.'],

 ['Chart Tutorial','Select index symbols and chart timeframes','Video 0:29–2:09: Search NIFTY 50 or another instrument, choose a timeframe and a candlestick or line view. The 2017 video demonstrates chart navigation, not a proven trading system. Current chart platform menus and free-feed terms may differ.'],
 ['Chart Tutorial','Draw horizontal support and resistance','Video 2:09–3:00: A horizontal line can mark a previously observed swing or trading zone. These are potential reaction areas, not guaranteed floors or ceilings. Define swings using only confirmed candles to avoid future-data leakage.'],
 ['Chart Tutorial','Draw rising and falling trendlines','Video 2:09–3:00 and 8:53: Connect previously confirmed swing lows for potential rising support, or confirmed swing highs for potential falling resistance. Require unambiguous pivot rules and retest before any automatic signal.'],
 ['Chart Tutorial','Parallel ascending and descending channels','Video 3:00–3:17: Draw a trend boundary and a roughly parallel opposite boundary to visualize a price channel. Channel edges may break or be redrawn; do not assume a touch causes reversal.'],
 ['Chart Tutorial','Fibonacci retracement','Video 3:17–4:08: Select an established directional swing low-to-high in an upswing (or high-to-low in a downswing), then calculate potential pullback levels such as 38.2%, 50%, and 61.8%. The calculator below uses manually chosen anchors and provides no predicted outcome.'],
 ['Chart Tutorial','Fibonacci three-anchor extension','Video 4:08–5:14: Choose initial swing start A, swing end B, and an already confirmed retracement C; project C + ratio × (B − A). 127.2% and 161.8% are common illustrative extension ratios, not guaranteed targets.'],
 ['Chart Tutorial','Chart annotations and rectangle zones','Video 5:31–7:49: Text notes, arrows, trend boxes, rectangles and highlighted ranges can document hypotheses. A rectangle is not itself a mathematically verified supply or demand zone.'],
 ['Chart Tutorial','Repeat drawing, zoom, and remove drawings','Video 7:49–9:26: The presenter demonstrates drawing-mode lock, zoom/pan and chart cleanup. These are interface controls, not automatic technical indicators.'],
 ['Chart Tutorial','Chart snapshots and saved layouts','Video 9:43–11:43: Saved snapshots and chart layouts support auditability and repeatable research. The 2017 demonstration uses Investing.com; our Indian Market Brain does not automatically import, save, or retrieve Investing.com accounts or drawings.'],
 ['Chart Tutorial','Historical chart data is not necessarily live','Video 12:02–12:51 makes historical claims about free feeds. Real-time data permissions, licensing and delay vary by market and may have changed since 2017. No live NSE/BSE integration has been established here.'],


 ['Supply & Demand','Demand zone from price reactions','Video 11:56–13:18: A previously confirmed swing-low area can be labeled a potential demand zone if price reacted upward there. For NIFTY/SENSEX, derive candidate price ranges from completed index OHLC, not a claim that unseen institutional buy orders remain. Later closes below the range weaken or invalidate the historical reference.'],
 ['Supply & Demand','Supply zone from price reactions','Video 13:33–15:09: A supply zone is a candidate area where price previously met selling pressure; a confirmed swing high can help mark it. Price can pass through the region or react only briefly. Index candles do not reveal who placed underlying orders.'],
 ['Supply & Demand','Trendline break versus nearby demand','Video 13:33–14:05: The presenter contrasts a trendline break with a nearby demand zone. An apparent break can fail when other support is close; require trend, volatility, close location and subsequent evidence rather than treating one line break as definitive.'],
 ['Supply & Demand','Double-bottom area versus proven demand','Video 12:13–12:45: A double bottom may coincide with a previously tested zone, but identifying the second bottom requires confirmation. Define the pivot and neckline without using later candles as evidence for an earlier decision; a chart pattern by itself is not proof of large participant orders.'],
 ['Supply & Demand','Breakout and retest of a price zone','Video 3:36–4:24 and 13:33–15:09: The video describes consolidation, breakouts and zones. A repeatable test would define the zone, a completed close beyond it, a later retest, and invalidation with a maximum holding window. Avoid assuming every breakout or retest succeeds.'],
 ['Supply & Demand','Confirmed-pivot historical zone detector','Research implementation: A candidate swing low must have two earlier and two later completed candles with higher lows; a candidate swing high analogously uses lower highs. The last two candles cannot create new confirmed zones. Any subsequent close beyond a demand lower bound or supply upper bound marks that candidate invalidated. This is only a historical heuristic, not an institutional order-flow detector.'],
 ['Supply & Demand','Indicators offer context, not proof','Video 5:11–6:49: The presenter cautions against trading solely because an indicator prints a signal. Describe context from market structure, trend, liquidity and volatility, then record explicit invalidation. Indicators alone cannot confirm a profit outcome.'],
 ['Supply & Demand','Risk control around zones','Video 10:48–11:56 and 16:15–17:20: The speaker emphasizes predefined stops, discipline and risk control. A stop based on a price zone still needs a volatility buffer, executable instrument, lot size, costs and gap/slippage assumptions. Trading the index itself is not possible.'],
 ['Supply & Demand','Patience and no-trade decisions','Video 14:05–14:53: The presenter emphasizes waiting for a setup and avoiding constant trades. Our Brain should retain NO LIVE CALL and prefer no-trade research over fabricated confidence when price action is ambiguous or feeds are missing.'],
 ['Supply & Demand','Institutional trading claims need proof','Video 9:27–11:06: Institutions and retail behavior are discussed as possible explanations for price moves. Candlestick shapes alone cannot verify institutional intent, stop hunting or trader profit transfers. Such assertions require actual authenticated trade/flow data and should not become automatic signals.'],
 ['Supply & Demand','Options premiums can be lost entirely','Video 21:36–22:55 discusses options and fixed premiums. Long options limit loss to the premium paid plus costs, but that premium can be lost in full; option spreads, short options, assignment, margin and gaps require separate risk models. Promotional monthly performance claims must not enter the Brain as expected returns.'],
 ['Supply & Demand','Old price targets are historical examples','Video 1:12–4:40 quotes old NIFTY, BANK NIFTY, crude oil and gold price levels. They were specific to 2018 and do not provide current actionable NIFTY/SENSEX entries or price forecasts. BANK NIFTY and commodities remain outside this Brain’s active scope.'],
 ['Price Action','Start with market structure, not indicator signals','Video 5:44–6:19, 11:41–13:03, 15:30–16:01: The presenter contrasts manual price-action analysis with automatic indicator signals. Use confirmed highs/lows, trend regime, support/resistance and invalidation as contextual evidence. A price-action explanation is not proof of forecast accuracy.'],
 ['Price Action','Top-down daily structure and trend context','Video 6:19–7:27: The example assesses a broad downtrend on a daily chart even as price rebounds. A temporary rally can be a correction within a larger decline. Evaluate completed candles on the selected timeframe; avoid calling an unverified rally a major reversal.'],
 ['Price Action','Double-top candidate and neckline','Video 7:27–8:50: The presenter discusses repeated highs, resistance and a neckline or break level. Two comparable confirmed swing highs separated by a pullback form a candidate double top; a later neckline close may confirm a bearish breakdown, but does not guarantee a decline.'],
 ['Price Action','Do not anticipate a double-top break','Research rule from video 7:27–8:50: Require completed right-hand confirmation candles around both highs, a distinct intervening trough, and a breakdown observed *after* pattern confirmation. The historical detector reports NO LIVE CALL and does not backdate a signal to the second high.'],
 ['Price Action','Role of horizontal support and resistance','Video 6:53–8:19 and 10:52–11:25: Historical highs or lows can behave as reference resistance/support. A retest, bounce or break is possible; prior reaction cannot establish current institutional order interest, future holding probability or executable fill.'],
 ['Price Action','Fibonacci 78.6% retracement in a falling market','Video 8:50–10:18: A 78.6% retracement is examined on a historical falling NIFTY swing. Use a fully confirmed high-to-low move and calculate the rebound level as end − 0.786 × (end − start). Reaching that level is neither guaranteed resistance nor a SELL instruction.'],
 ['Price Action','Price levels, confirmation and targets','Video 1:26–3:21 provides historical conditional buy-above / sell-below index thresholds with two proposed targets. Treat these as dated examples of rule structure, not current market prices. Future levels must come from a timestamped authorized feed, declared methodology, risk limit and out-of-sample validation.'],
 ['Price Action','Multiple independent confirmations need testing','Video 10:52–11:41 argues for checking trendlines, channels, support/resistance and Fibonacci together. Correlated technical tools do not become independent evidence merely because several agree; backtest the combined rule against simpler benchmarks and account for selection bias.'],
 ['Price Action','Aggressive versus conservative entry conditions','Video 13:03–14:08 contrasts more aggressive and conservative approaches around support/resistance breaks. A research design can compare touch, close-through and retest requirements; these have different entry prices, missed-trade rates and false-break exposures.'],
 ['Price Action','Old price targets and testimonials are not current proof','Video 1:26–5:44 gives NIFTY, BANK NIFTY, crude and gold levels dating to 2018; later sections discuss classes and anecdotal trading results. Never use old thresholds as live calls or testimonials as expected returns. BANK NIFTY and commodities remain out of this NIFTY/SENSEX-only Brain.'],

 ['Inside Bar','Mother candle reference range','Video 1:13–2:22: The mother candle high and low provide the reference range for later inside candles. The v5 research tool requires strictly lower high and higher low of a subsequent completed candle, rather than predicting the next direction.'],
 ['Inside Bar','Inside bar and nested consolidation','Video 1:31–2:02: One or more candles may consolidate within a prior larger candle. This is compression in historical prices, not proof that a breakout will occur or of the direction it will take.'],
 ['Inside Bar','Close-confirmed breakout versus wick','Video 2:02–2:38: The video distinguishes a boundary excursion from a valid breakout close. The historical study requires a completed close beyond the original mother high or low to label a close break; no trade is generated.'],
 ['Inside Bar','Wick-only fakeout warning','Video 2:22 and 11:34–12:40: A wick through resistance/support with a return inside the range can be a false-break warning. The research tool reports wick-only probes, not a confirmed trade or proof of manipulation.'],
 ['Inside Bar','Aggressive breakout or conservative retest','Video 3:45–4:58 and 13:40–16:33: Compare the hypothetical close-through entry with a later retest of the broken boundary. Retest entries can avoid some false signals but may never fill; costs and slippage must be considered.'],
 ['Inside Bar','Support resistance and mother-candle invalidation','Video 4:15 and 11:34–16:33: Mother-candle boundaries are price references, not guaranteed structural levels. A stop or invalidation cannot be selected solely from a chart drawing without position sizing and instrument risk.'],
 ['Inside Bar','Round-number confluence is unproven','Video 6:29–9:49: The presenter discusses patterns near round levels such as large round index values. Treat this as a hypothesis requiring a prespecified tolerance, control group and out-of-sample test, not a claim of higher win probability.'],
 ['Inside Bar','Confirmation before automatic classification','Video 5:43–6:10: Set the breakout rule before studying results, require finished candles, and never backdate a breakout to its mother/inside candle. The v5 detector reports only historical evidence.'],
 ['Inside Bar','Trend continuation and reversal context','Video 8:42 and 17:00–17:40: The presentation describes reversal and continuation contexts. Inside bars alone are direction-neutral; evaluate higher-timeframe trend and nearby levels independently.'],
 ['Inside Bar','Avoid trades directly into nearby levels','Video 11:34–17:18: A breakout into a known nearby opposing zone may offer poor distance to the next barrier. Assess reward-to-risk, competing technical levels and gaps before considering a paper-study setup.'],
 ['Inside Bar','Pattern sample limitations','The 21 Oct 2026 recording demonstrates a chart pattern but does not provide reproducible profitability statistics. Automated captions omit portions of speech. The rule engine uses an explicit, simplified OHLC definition, and ignores old/unverifiable win-rate claims.'],

];
export const strategies=[
 ['EMA 12/26 trend','Implemented in research analyzer','Direction based on completed candle EMA alignment; fails in ranging markets.'],
 ['20-candle moving average','Implemented in research analyzer','Trend filter from the close relative to SMA20.'],
 ['RSI 14 momentum','Implemented in research analyzer','Momentum band comparison; overbought/oversold not automatic countertrend entries.'],
 ['20-candle breakout','Implemented in research analyzer','Recent range breakout; needs volume/context confirmation.'],
 ['Latest-candle momentum','Implemented in research analyzer','Single-period move; noisy and not a standalone signal.'],
 ['ATR 14 volatility filter','Implemented in research analyzer','Non-directional realized range for risk context.'],
 ['VWAP pullback','Knowledge only — needs intraday traded instrument volume','Observe volume-weighted mean and deviations on an actual tradeable underlying.'],
 ['Opening-range breakout','Knowledge only — needs verified intraday data','Observe first trading interval and examine subsequent breakouts with session logic.'],
 ['Support/resistance retest','Knowledge only','Require a reproducible swing definition and backtest for false-break patterns.'],
 ['Gap and go / gap fade','Knowledge only','Use previous-close and today-open gaps; trading-calendar alignment matters.'],
 ['MACD confirmation','Knowledge only','Trend/momentum confirmation with lag and whipsaw risk.'],
 ['Bollinger mean reversion','Knowledge only','Needs regime filtering and real transaction costs.'],
 ['Market breadth confirmation','Knowledge only — needs constituent feed','Confirm participation with actual advancers/decliners and weights.'],
 ['FII/DII flow context','Knowledge only — needs dated official flow data','Describe participant trends, not deterministic next-day forecasts.'],
 ['OI / PCR options context','Knowledge only — needs licensed derivatives feed','Requires contract-specific expiry, strike and instrument data.'],
 ['Implied-volatility regime','Knowledge only — needs options feed','Avoid assumptions that high IV guarantees price reversal.'],
 ['Event-risk filter','Knowledge only — needs verified event calendar','RBI, budget, election, earnings and global-data events change uncertainty.'],
 ['Walk-forward strategy test','Knowledge only — needs historical research dataset','Use isolated out-of-sample periods and realistic transaction assumptions.'],

 ['Confirmed-pivot trendlines','Knowledge only — video chart tutorial','Identify causal swings; avoid fitting lines to future highs/lows and assess out-of-sample breaks or retests.'],
 ['Parallel price channels','Knowledge only — video chart tutorial','Study rising, falling and sideways channels with objective endpoints; visually fitting hindsight channels is not backtesting.'],
 ['Fibonacci confluence','Knowledge only — manual levels supported','Study whether swing retracements coincide with independently confirmed structure; simple overlap does not establish an edge.'],
 ['Fibonacci ABC extensions','Knowledge only — manual calculation supported','Project swing distance from confirmed pullback; test extension outcomes separately from stop and fees.'],
 ['Horizontal zone retest','Knowledge only — video chart tutorial','Specify zone width, causally confirmed support/resistance, breakout thresholds and validation.'],

 ['Supply/demand pivot regions','Knowledge and historical-zone study only — video 2018','Map two-sided completed-candle pivots to candidate historical bands; do not infer institutional orders.'],
 ['Zone invalidation / failed breakout','Knowledge only — video 2018','Look for completed closes beyond predeclared zone limits; define whipsaw handling, execution costs and backtest periods.'],
 ['Demand-zone retest with trend context','Knowledge only — video 2018','Define a prior confirmed zone, independent trend filter, completed retest and risk-based invalidation before considering a hypothetical setup.'],
 ['Supply-zone reversal study','Knowledge only — video 2018','Test reactions to previously confirmed supply, allowing missed fills, trend continuations and adverse gaps.'],
 ['Double-bottom near demand','Knowledge only — video 2018','Compare neckline confirmation and swing-low support without assuming a profitable reversal.'],
 ['Confirmed double-top neckline','Historical pattern study only — 2018 price-action video','Two close, right-side-confirmed highs and an intervening trough; breakdown only after pattern confirmation, not a live SELL.'],
 ['Daily-trend counter-rally filter','Knowledge only — 2018 price-action video','Research whether intraday rallies inside daily declines behave differently from trend-aligned rallies. Timeframe sync and forward validation required.'],
 ['78.6% retracement confluence','Knowledge only — 2018 price-action video','Study deep rebound levels after preconfirmed bearish swings; Fibonacci coincidence is not a reversal guarantee.'],
 ['Level-break close versus retest','Knowledge only — 2018 price-action video','Compare risk, follow-through and missed trades for close-through, failed break and retest studies on historical completed candles.'],
 ['Inside-bar mother-range compression','Historical pattern study only — 2026 inside-bar video','Find strict fully contained completed bars and classify a later close above/below the mother range. No orders or automatic calls.'],
 ['Inside-bar wick-only breakout warning','Historical pattern study only — 2026 inside-bar video','Count wicks outside the mother range when the close remains inside; distinguish a probe from a confirmed close break.'],
 ['Inside-bar breakout retest study','Knowledge only — 2026 inside-bar video','Test future retest outcomes only after a completed breakout; fees, gaps, non-fills and overnight sessions need explicit modeling.'],
 ['Inside-bar round-number context','Knowledge only — 2026 inside-bar video','Prespecify psychologically round index levels and compare outcomes against unmatched controls before asserting a confluence advantage.'],
 ['Inside-bar trend-alignment filter','Knowledge only — 2026 inside-bar video','Study direction-neutral inside bars within measured higher-timeframe trends; do not treat all inside bars as reversals.'],
];
export function answerQuestion(question){
 const q=(question||'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').trim();if(q.length<3)return[];
 const terms=q.split(/\s+/).filter(x=>x.length>2).slice(0,16);return lessons.map(([category,title,body],i)=>({category,title,body,score:terms.reduce((s,k)=>s+(title.toLowerCase().includes(k)?4:0)+(body.toLowerCase().includes(k)?1:0),0),i})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,5);
}


// Educational implementation of the calculation method explained at ~3:17–5:14
// in the source video. Manual anchors are not automatically detected and do not
// constitute NIFTY/SENSEX market data, backtests, or executable calls.
export function fibonacciStudy(start,end,pullback){
  if (![start,end].every(v=>typeof v==='number' && Number.isFinite(v) && v>0) || start===end) throw new Error('Use two different positive finite swing levels.');
  const direction=end>start?'upswing':'downswing';
  const dist=end-start, absolute=Math.abs(dist);
  const retracements=[0.236,0.382,0.5,0.618,0.786].map(r=>({ratio:r,level:Math.round((end-dist*r)*100)/100}));
  let extensions=null;
  if(pullback!==undefined && pullback!==null){
    if(typeof pullback!=='number' || !Number.isFinite(pullback) || pullback<=0 || !(pullback>Math.min(start,end)&&pullback<Math.max(start,end)))throw new Error('Retracement C must be a positive finite level strictly between A and B.');
    extensions=[1,1.272,1.618].map(r=>({ratio:r,level:Math.round((pullback+dist*r)*100)/100}));
  }
  return {direction,start,end,pullback:pullback??null,range:Math.round(absolute*100)/100,retracements,extensions,status:'MANUAL EDUCATIONAL LEVELS — NO LIVE MARKET CALL'};
}
