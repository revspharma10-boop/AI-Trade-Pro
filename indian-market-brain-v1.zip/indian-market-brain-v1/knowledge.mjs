export const sources=Object.freeze([
 {label:'NSE — NIFTY 50 index',url:'https://www.nseindia.com/static/products-services/indices-nifty50-index'},
 {label:'NSE — Trading session timings',url:'https://www.nseindia.com/static/market-data/market-timings'},
 {label:'NSE — Licensed real-time data',url:'https://www.nseindia.com/static/market-data/real-time-data-subscription'},
 {label:'NSE — Index data subscription',url:'https://www.nseindia.com/static/nse-indices/index-data-subscription'},
 {label:'SEBI — Derivatives risk education',url:'https://investor.sebi.gov.in/understanding_derivatives.html'},
 {label:'SEBI — Equity F&O loss study',url:'https://www.sebi.gov.in/media-and-notifications/press-releases/sep-2024/updated-sebi-study-reveals-93-of-individual-traders-incurred-losses-in-equity-fando-between-fy22-and-fy24-aggregate-losses-exceed-1-8-lakh-crores-over-three-years_86906.html'}
]);
// Deliberately curated and explicitly limited to Indian equity benchmarks.
export const lessons=[
 ['Basics','What is NIFTY 50?','The NIFTY 50 is a free-float market-capitalization-weighted Indian equity index of 50 constituent securities, maintained by NSE Indices. It is an index level, not a directly purchasable share. An ETF or derivative creates tradable exposure.'],
 ['Basics','What is SENSEX?','The BSE SENSEX is a broad Indian large-company benchmark tracking 30 constituents, with free-float-adjusted market-capitalization weighting. It reflects the performance of its basket, not the trade price of a single security.'],
 ['Basics','How index prices move','An index rises when weighted gains across its constituents outweigh weighted declines, and falls when the reverse occurs. Large-weight constituents can dominate even when most stocks move differently.'],
 ['Basics','How an index is traded','An index cannot be delivered like a share. Traders access benchmark exposure via index-tracking ETFs, futures or options. Contracts introduce basis, margin and expiry risks.'],
 ['Basics','NSE and BSE sessions','Regular equity trading is generally 09:15–15:30 IST on eligible trading days. Holidays, special sessions, auctions, and derivatives schedules require exchange-calendar verification.'],
 ['Fundamentals','RBI monetary policy','Policy rates influence borrowing costs, discount rates, bank margins, bond yields and investor risk appetite. The same announcement can affect industries differently; surprises relative to expectations matter.'],
 ['Fundamentals','Inflation, yields and valuations','Higher expected rates can reduce the present value investors assign to future earnings, but inflation effects depend on pricing power, growth and policy expectations.'],
 ['Fundamentals','Corporate earnings','Index performance is ultimately connected to profit growth, margins, guidance, and valuations among its constituents. One company can have outsized impact through index weight.'],
 ['Fundamentals','FII / DII flows','Foreign and domestic institutional buying/selling can correlate with market pressure. Aggregate flow summaries can include offsetting activity and do not mechanically predict the next index candle.'],
 ['Fundamentals','USD/INR and crude oil','Rupee depreciation affects importers and exporters differently; oil prices affect India’s import bill and many sectors. Always examine the direction and nature of the shock.'],
 ['Fundamentals','Sector rotation and breadth','A headline index rally led by just a few large stocks may have weak breadth. Advance/decline breadth requires actual constituent data, not index OHLC alone.'],
 ['Technical','Support and resistance','Past swing highs/lows and high-volume areas are candidate reference levels, not guaranteed barriers. Breakouts should be checked for participation and false-break risk.'],
 ['Technical','EMA and SMA trends','Moving averages smooth historical closes. EMA12–EMA26 momentum can describe trend direction but lags turning points and often whipsaws in sideways periods.'],
 ['Technical','RSI momentum','RSI14 tracks average up versus down closes on a 0–100 scale. Overbought is not an automatic sell and oversold is not an automatic buy.'],
 ['Technical','ATR volatility','Average True Range measures range magnitude including gaps; it is non-directional. Use volatility for stop distances and position sizing, not for price forecasts.'],
 ['Technical','VWAP trading','Volume-weighted average price is meaningful with traded instrument-level intraday volume. A benchmark index OHLC file without constituent or derivative trade volume cannot support an authentic VWAP.'],
 ['Derivatives','Futures basis','Index futures may differ from the spot index because of financing, dividends, expiry, demand and market frictions. Basis can change without spot direction reversing.'],
 ['Derivatives','Options premium','Option value reflects underlying level, strike, time to expiry, implied volatility, interest rates and dividends. A correct directional call can still lose due to premium decay.'],
 ['Derivatives','Open interest interpretation','Increasing OI means more outstanding futures/options positions, not automatically new buyers. Read alongside price, option strikes, volume and implied volatility.'],
 ['Derivatives','Put-call ratio (PCR)','PCR describes option put versus call activity or outstanding positions under a specified definition. It does not reliably indicate direction on its own.'],
 ['Derivatives','Option Greeks','Delta measures price sensitivity to the underlying, gamma delta sensitivity, theta time decay and vega implied volatility sensitivity. Risks rise around short-dated options and events.'],
 ['Derivatives','Expiry and max pain','Expiry can drive hedging and position changes. “Max pain” is a descriptive calculation, not a force pulling prices to a guaranteed settlement.'],
 ['Risk','Why index F&O is risky','Leverage, gaps, margin and rapid time decay can overwhelm an apparently correct idea. SEBI documents that most individual equity F&O traders incur losses.'],
 ['Risk','Position sizing','Decide capital at risk before entry; use distance to invalidation and the instrument’s true lot size, tick, premium, fees and margins. Do not size directly from index points.'],
 ['Risk','Backtesting pitfalls','Avoid look-ahead bias, survivorship bias, overfitting, ignoring fees, and choosing a strategy only because it performs on past samples. Use walk-forward and out-of-sample checks.'],
 ['Risk','Data provenance','Only licensed and timestamped data can be displayed as live NSE/BSE quotes. An uploaded CSV is research input. Index-level “buy/sell ratio” cannot be derived from index price movement.'],
];
export const strategies=[
 ['EMA 12/26 trend','Implemented in research analyzer','Direction based on completed candle EMA alignment; fails in ranging markets.'],
 ['20-candle moving average','Implemented in research analyzer','Trend filter from the close relative to SMA20.'],
 ['RSI 14 momentum','Implemented in research analyzer','Momentum band comparison; overbought/oversold not automatic countertrend entries.'],
 ['20-candle breakout','Implemented in research analyzer','Recent range breakout; needs volume/context confirmation.'],
 ['Latest-candle momentum','Implemented in research analyzer','Single-period move; noisy and not a standalone signal.'],
 ['ATR 14 volatility filter','Implemented in research analyzer','Non-directional realized range for risk context.'],
 ['VWAP pullback','Knowledge only — needs intraday traded instrument volume','Observe volume-weighted mean and deviations on an actual tradeable underlying.'],
 ['Opening-range breakout','Knowledge only — needs verified intraday data','Observe first trading interval and examine subsequent breakouts with session logic.'],
 ['Support/resistance retest','Knowledge only','Require a reproducible swing definition and backtest for false-break patterns.'],
 ['Gap and go / gap fade','Knowledge only','Use previous-close and today-open gaps; trading-calendar alignment matters.'],
 ['MACD confirmation','Knowledge only','Trend/momentum confirmation with lag and whipsaw risk.'],
 ['Bollinger mean reversion','Knowledge only','Needs regime filtering and real transaction costs.'],
 ['Market breadth confirmation','Knowledge only — needs constituent feed','Confirm participation with actual advancers/decliners and weights.'],
 ['FII/DII flow context','Knowledge only — needs dated official flow data','Describe participant trends, not deterministic next-day forecasts.'],
 ['OI / PCR options context','Knowledge only — needs licensed derivatives feed','Requires contract-specific expiry, strike and instrument data.'],
 ['Implied-volatility regime','Knowledge only — needs options feed','Avoid assumptions that high IV guarantees price reversal.'],
 ['Event-risk filter','Knowledge only — needs verified event calendar','RBI, budget, election, earnings and global-data events change uncertainty.'],
 ['Walk-forward strategy test','Knowledge only — needs historical research dataset','Use isolated out-of-sample periods and realistic transaction assumptions.'],
];
export function answerQuestion(question){
 const q=(question||'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').trim();if(q.length<3)return[];
 const terms=q.split(/\s+/).filter(x=>x.length>2).slice(0,16);return lessons.map(([category,title,body],i)=>({category,title,body,score:terms.reduce((s,k)=>s+(title.toLowerCase().includes(k)?4:0)+(body.toLowerCase().includes(k)?1:0),0),i})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,5);
}
