# India Market Brain — independent v4

**Scope:** Single standalone Indian index education and research brain, covering NIFTY 50 (NSE) and SENSEX (BSE). It does **not** incorporate, share data with, modify, or send requests to the existing BTC Algo Trader system.

## Implemented

- Responsive single-page dashboard with top tabs: Overview, Strategy Lab, Knowledge Brain, Risk & Sources.
- 48 curated Indian equity-index knowledge topics (including 10 video-derived charting lessons) and 28 strategy concepts; six simple quantitative indicators implemented on **user-provided historical OHLC**. Search is curated retrieval, not a trained generative AI.
- Strongly validated CSV analyzer, chart, transparent bullish/bearish research context, risk-point illustration, NSE/SEBI reference sources.
- Explicit **NO LIVE CALL** state, no broker API, no options trading, no live prices, no misleading buy/sell ratio, no cryptocurrency or BTC.
- Entire analysis runs in the web browser. CSV is **not persisted in any cloud DB** and remains in memory until refresh. No user authentication or personal information input. The live public site is for research/education only.
- Demo button generates reproducible **clearly labeled simulated historical data**, never falsely described as exchange data.

## Video source knowledge incorporated (26 October 2026)

The transcript from [Trade Achievers (2017): How to use Investing.com for Technical Chart Analysis](https://youtu.be/jwSIXMKTd9Q) has been manually reviewed and distilled into ten original, searchable Chart Tutorial lessons with relevant timestamps: choosing charts/timeframes; trendlines; horizontal support and resistance; parallel channels; Fibonacci retracements; Fibonacci three-point ABC extensions; chart annotations/rectangles; drawing mode and zoom; snapshots and saved layouts; and historical data-feed claims. The page includes clickable chapter links and a standalone manual three-anchor Fibonacci study calculator. The new five catalog concepts remain **knowledge-only**, NOT executable strategies. The tutorial does not assert or establish a profitable trading edge. Transcript is not reprinted.

## Second source video added — supply & demand (26 October 2026)

The video [Trade Achievers: What Is The Use Of Supply & Demand In Financial Markets? (2018)](https://youtu.be/-hua6K-GFZ0) was reviewed through its available machine-generated Tamil-language-caption transcript. Captions are substantially garbled; we use only clear recurring educational themes with rough timestamps, not exact old NIFTY targets or promotional trading-return claims. The 12 new searchable lessons cover demand/supply zone concepts, two-sided pivots, market structure, double bottoms, trendline breaks versus horizontal zones, break/retest, indicator limitations, patience, predefined invalidation and options premium risk. Five additional strategy descriptions are knowledge-only. A new detector shows historical candidate supply and demand zones from **user-supplied completed candles**, with two-sided confirmation, invalidation, and range highlights, in the Strategy Lab. It has no live feed, institution identification, predictive confidence or automatic order capability. Indexed source is only for NIFTY/SENSEX. Historical discoveries must not be evaluated as if available before pivot confirmation.

## Data integrity limits

NSE real-time market data is licensed; we did not use undocumented exchange scraping. SENSEX/NIFTY index levels do not themselves have an executed buy/sell trade ratio; true market breadth requires licensed constituent data. Any future verified data feed should have authorization, explicit timestamp/timezone, and stale-data safeguards before enabling live calls. NSE market-hours calculations shown are routine weekdays only and do not account for exchange holidays or special sessions.

## Local development

`python -m http.server 8000` from this folder; visit localhost:8000. `node --test tests/*.test.mjs` for tests. No build process; Render Static Site can publish this folder directly.

## Reliable references

- https://www.nseindia.com/static/products-services/indices-nifty50-index
- https://www.nseindia.com/static/market-data/market-timings
- https://www.nseindia.com/static/market-data/real-time-data-subscription
- https://www.nseindia.com/static/nse-indices/index-data-subscription
- https://investor.sebi.gov.in/understanding_derivatives.html
- https://www.sebi.gov.in/media-and-notifications/press-releases/sep-2024/updated-sebi-study-reveals-93-of-individual-traders-incurred-losses-in-equity-fando-between-fy22-and-fy24-aggregate-losses-exceed-1-8-lakh-crores-over-three-years_86906.html

## Phase 2 (not implemented)

Separate durable Neon database and protected login, authorized NSE/BSE data provider, market holidays, breadth, option chain/OI, RBI and corporate-action source ingestion, out-of-sample evaluation. Never claim any of these are connected yet.


## Third source video: price-action live-script analysis (26 October 2026)

Trade Achievers, *How To Analyse A Script In Live Markets??? (25-06-2018)*, published 26 June 2018: https://youtu.be/YJvYUOAjKWQ. The English-labeled automatic transcript largely attempts to transliterate Tamil and is severely corrupted. The updated code captures only clearly repeated concepts and their approximate timestamps, not literal quotes, profit claims or the dated examples as current index levels. Ten new **Price Action** lessons and four knowledge/research study strategies were added. The historical `detectHistoricalDoubleTops` function uses an explicit fixed pivot wing, separated peaks within tolerance, intervening trough, confirmation date and forward-only neckline break recording. It is shown in the Strategy Lab alongside the existing historical zone study; users must supply legitimate NIFTY/SENSEX OHLC CSV. No market feed or orders are connected; no live call. Tests check causal pivots, pattern confirmation, invalidation and incorrect data.
