# India Market Brain — independent v1

**Scope:** Single standalone Indian index education and research brain, covering NIFTY 50 (NSE) and SENSEX (BSE). It does **not** incorporate, share data with, modify, or send requests to the existing BTC Algo Trader system.

## Implemented

- Responsive single-page dashboard with top tabs: Overview, Strategy Lab, Knowledge Brain, Risk & Sources.
- 26 curated Indian equity-index knowledge topics and 18 strategy concepts; six simple quantitative indicators implemented on **user-provided historical OHLC**. Search is curated retrieval, not a trained generative AI.
- Strongly validated CSV analyzer, chart, transparent bullish/bearish research context, risk-point illustration, NSE/SEBI reference sources.
- Explicit **NO LIVE CALL** state, no broker API, no options trading, no live prices, no misleading buy/sell ratio, no cryptocurrency or BTC.
- Entire analysis runs in the web browser. CSV is **not persisted in any cloud DB** and remains in memory until refresh. No user authentication or personal information input. The live public site is for research/education only.
- Demo button generates reproducible **clearly labeled simulated historical data**, never falsely described as exchange data.

## Data integrity limits

NSE real-time market data is licensed; we did not use undocumented exchange scraping. SENSEX/NIFTY index levels do not themselves have an executed buy/sell trade ratio; true market breadth requires licensed constituent data. Any future verified data feed should have authorization, explicit timestamp/timezone, and stale-data safeguards before enabling live calls. NSE market-hours calculations shown are routine weekdays only and do not account for exchange holidays or special sessions.

## Local development

`python -m http.server 8000` from this folder; visit localhost:8000. `node --test tests/*.test.mjs` for tests. No build process; Render Static Site can publish this folder directly.

## Reliable references

- https://www.nseindia.com/static/products-services/indices-nifty50-index
- https://www.nseindia.com/static/market-data/market-timings
- https://www.nseindia.com/static/market-data/real-time-data-subscription
- https://www.nseindia.com/static/nse-indices/index-data-subscription
- https://investor.sebi.gov.in/understanding_derivatives.html
- https://www.sebi.gov.in/media-and-notifications/press-releases/sep-2024/updated-sebi-study-reveals-93-of-individual-traders-incurred-losses-in-equity-fando-between-fy22-and-fy24-aggregate-losses-exceed-1-8-lakh-crores-over-three-years_86906.html

## Phase 2 (not implemented)

Separate durable Neon database and protected login, authorized NSE/BSE data provider, market holidays, breadth, option chain/OI, RBI and corporate-action source ingestion, out-of-sample evaluation. Never claim any of these are connected yet.
