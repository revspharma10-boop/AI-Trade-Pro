/** Indian index research engine. No broker, no order execution, no unauthenticated "live" prices. */
export const INDICES = Object.freeze({NIFTY50:'NIFTY 50', SENSEX:'SENSEX'});
const MIN_ROWS=35, MAX_ROWS=3000;
const finite = v => Number.isFinite(v);
export const round=(v,n=2)=>Number(v.toFixed(n));
export function parseOhlc(input){
 if(typeof input !=='string'||input.length>450000) throw Error('Data must be plain CSV under 450 KB.');
 const lines=input.replace(/\r/g,'').split('\n').map(s=>s.trim()).filter(Boolean);
 if(!lines.length) throw Error('Paste time,open,high,low,close,volume CSV rows.');
 const start=/^time\s*,\s*open\s*,\s*high\s*,\s*low\s*,\s*close\s*,\s*volume$/i.test(lines[0])?1:0;
 if(lines.length-start<MIN_ROWS)throw Error(`At least ${MIN_ROWS} finished candles are required.`);
 if(lines.length-start>MAX_ROWS)throw Error(`No more than ${MAX_ROWS} candles per analysis.`);
 const rows=lines.slice(start).map((line,i)=>{
   const f=line.split(',').map(x=>x.trim());
   if(f.length!==6)throw Error(`Row ${i+1}: expected exactly six CSV columns.`);
   if(f.some(x=>x===''))throw Error(`Row ${i+1}: missing CSV field (use 0 only when actual volume is unavailable).`);
   const time=Date.parse(f[0]);
   // Reject timezone-free timestamps: otherwise user timezone silently shifts candle identity.
   if(!/(Z|[+-]\d\d:?\d\d)$/i.test(f[0])||!finite(time))throw Error(`Row ${i+1}: use timestamp with timezone, e.g. 2026-10-23T15:30:00+05:30.`);
   const [open,high,low,close,volume]=f.slice(1).map(Number);
   if([open,high,low,close,volume].some(v=>!finite(v))||![open,high,low,close].every(v=>v>0)||volume<0||high<Math.max(open,close,low)||low>Math.min(open,close,high))throw Error(`Row ${i+1}: invalid OHLC/volume figures.`);
   return {time,open,high,low,close,volume};
 });
 for(let i=1;i<rows.length;i++)if(rows[i].time<=rows[i-1].time)throw Error(`Row ${i+1}: candles must be chronological without duplicate timestamps.`);
 if(rows.at(-1).time>Date.now()+3600000)throw Error('Dataset contains a candle from the future.');
 return rows;
}
export function sma(xs,n){if(xs.length<n)return null;return xs.slice(-n).reduce((a,b)=>a+b,0)/n;}
export function ema(xs,n){if(xs.length<n)return null;let value=sma(xs.slice(0,n),n);const alpha=2/(n+1);for(let i=n;i<xs.length;i++) value=xs[i]*alpha+value*(1-alpha);return value;}
export function rsi(xs,n=14){if(xs.length<n+1)return null;let gains=0,losses=0;for(let i=1;i<=n;i++){let d=xs[i]-xs[i-1];gains+=Math.max(d,0);losses+=Math.max(-d,0)}gains/=n;losses/=n;for(let i=n+1;i<xs.length;i++){let d=xs[i]-xs[i-1];gains=(gains*(n-1)+Math.max(d,0))/n;losses=(losses*(n-1)+Math.max(-d,0))/n;}return losses===0?(gains===0?50:100):100-100/(1+gains/losses);}
export function atr(rows,n=14){if(rows.length<n+1)return null;let a=0;const tr=i=>Math.max(rows[i].high-rows[i].low,Math.abs(rows[i].high-rows[i-1].close),Math.abs(rows[i].low-rows[i-1].close));for(let i=1;i<=n;i++)a+=tr(i);a/=n;for(let i=n+1;i<rows.length;i++)a=(a*(n-1)+tr(i))/n;return a;}
export function indiaMarketSession(now=new Date()){
 const x=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);const get=k=>x.find(z=>z.type===k)?.value;const day=get('weekday'),minutes=Number(get('hour'))*60+Number(get('minute'));
 return {weekday:day,ist:`${get('hour')}:${get('minute')} IST`,regularSession:!['Sat','Sun'].includes(day)&&minutes>=555&&minutes<930,holidayCalendarConnected:false};
}
export function analyze(rows,index,now=new Date()){
 if(!Object.hasOwn(INDICES,index))throw Error('Choose NIFTY 50 or SENSEX only.');
 if(!Array.isArray(rows)||rows.length<MIN_ROWS)throw Error(`At least ${MIN_ROWS} completed rows are required.`);
 const closes=rows.map(r=>r.close),last=rows.at(-1),prev=rows.at(-2),ma20=sma(closes,20),ma50=sma(closes,50),fast=ema(closes,12),slow=ema(closes,26),osc=rsi(closes),vol=atr(rows);
 const trend=ma50==null?'INSUFFICIENT FOR SMA50':fast>slow&&last.close>ma20?'UPTREND':fast<slow&&last.close<ma20?'DOWNTREND':'MIXED';
 const high20=Math.max(...rows.slice(-21,-1).map(r=>r.high));const low20=Math.min(...rows.slice(-21,-1).map(r=>r.low));
 const strategies=[
   {name:'EMA trend',state:fast>slow?'bullish':fast<slow?'bearish':'neutral',detail:'EMA12 compared with EMA26'},
   {name:'SMA20 filter',state:last.close>ma20?'bullish':last.close<ma20?'bearish':'neutral',detail:'Last close compared with SMA20'},
   {name:'RSI14 momentum',state:osc>55&&osc<70?'bullish':osc<45&&osc>30?'bearish':'neutral',detail:'Avoid treating extreme RSI as an automatic entry'},
   {name:'20-bar breakout',state:last.close>high20?'bullish':last.close<low20?'bearish':'neutral',detail:'Last close beyond the preceding 20-candle range'},
   {name:'One-bar momentum',state:last.close>prev.close?'bullish':last.close<prev.close?'bearish':'neutral',detail:'Latest close vs previous close'},
   {name:'ATR turbulence',state:'neutral',detail:`ATR14 ${(vol/last.close*100).toFixed(2)}% of the last close; risk context, not a direction signal`}
 ];
 const bullish=strategies.filter(x=>x.state==='bullish').length,bearish=strategies.filter(x=>x.state==='bearish').length;
 const session=indiaMarketSession(now),ageHours=(now.getTime()-last.time)/3600000;
 const dataFresh=ageHours>=0&&ageHours<=96;
 const bias=trend==='UPTREND'&&bullish>=3?'BULLISH RESEARCH BIAS':trend==='DOWNTREND'&&bearish>=3?'BEARISH RESEARCH BIAS':'NO CLEAR EDGE';
 const reasons=[`Research bias: ${bias.toLowerCase()}.`,`${bullish} bullish and ${bearish} bearish observations among 5 directional methods.`,`Data supplied by user, not independently authenticated by exchange.`,session.regularSession?'Calendar holidays are not checked.':'Outside assumed NSE regular weekday session.',dataFresh?'Timestamp age is within 96 hours.':'Data older than 96 hours: not suitable for a current read.'];
 return {index:INDICES[index],price:round(last.close),previous:round(prev.close),changePct:round(100*(last.close-prev.close)/prev.close),time:new Date(last.time).toISOString(),ageHours:round(ageHours,1),rows:rows.length,sma20:round(ma20),sma50:ma50===null?null:round(ma50),ema12:round(fast),ema26:round(slow),rsi14:round(osc,1),atr14:round(vol),trend,bias,strategies,bullish,bearish,session,dataFresh,decision:'NO LIVE CALL',reasons,source:'User-provided CSV (unverified)',actualMarketFeedConnected:false};
}
export function positionRisk(capital,riskPercent,entry,stop,lotSize=1){
 const vals=[capital,riskPercent,entry,stop,lotSize];if(vals.some(v=>!finite(v)||v<=0)||riskPercent>2||entry===stop||!Number.isInteger(lotSize))throw Error('Enter valid positive values: risk 0–2%, a different stop, and integer lot size.');
 const budget=capital*riskPercent/100;const perUnit=Math.abs(entry-stop),units=Math.floor(budget/(perUnit*lotSize))*lotSize;
 return {budget:round(budget),perUnit:round(perUnit),maxUnits:units,approxRisk:round(units*perUnit),rr2:round(entry+2*(entry-stop)),side:stop<entry?'LONG STUDY':'SHORT STUDY',note:'Illustrative index-point arithmetic only; index units cannot be traded directly. Contract-specific lot sizes, costs and margin are not accounted for.'};
}


/** Historical-only, causal two-sided swing-pivot zone study. No institutional claims or live calls. */
export function detectHistoricalZones(rows,wing=2){
 if(!Array.isArray(rows)||rows.length<7||!Number.isInteger(wing)||wing<2||wing>5)
   throw new Error('A historical zone study needs seven or more completed candles and pivot wings of 2–5.');
 for(let i=0;i<rows.length;i++){
   const r=rows[i];
   if(!r||!Number.isFinite(r.time)||!['open','high','low','close'].every(k=>Number.isFinite(r[k])&&r[k]>0)||r.high<Math.max(r.open,r.close,r.low)||r.low>Math.min(r.open,r.close,r.high)||(i&&r.time<=rows[i-1].time))
     throw new Error('Invalid historical candle sequence.');
 }
 const last=rows.length-1;
 const candidates=[];
 for(let i=wing;i<=last-wing;i++){
   const r=rows[i];let lowPivot=true,highPivot=true;
   for(let offset=1;offset<=wing;offset++){
     // Requiring strictly lower/higher prices avoids duplicate flat pivot attribution.
     if(!(r.low<rows[i-offset].low&&r.low<rows[i+offset].low))lowPivot=false;
     if(!(r.high>rows[i-offset].high&&r.high>rows[i+offset].high))highPivot=false;
   }
   for(const type of ['demand','supply']){
     if(type==='demand'?!lowPivot:!highPivot)continue;
     const lower=type==='demand'?r.low:Math.max(r.open,r.close);
     const upper=type==='demand'?Math.min(r.open,r.close):r.high;
     if(upper<=lower)continue; // Zero-width body or wick is not a zone.
     // From the confirmation candle onward, test whether the closed price invalidates the zone.
     let invalidated=false,tests=0;
     for(let j=i+wing+1;j<=last;j++){
       const future=rows[j];
       if(type==='demand'&&future.close<lower || type==='supply'&&future.close>upper){invalidated=true;break;}
       if(future.low<=upper&&future.high>=lower)tests++;
     }
     candidates.push({type,low:round(lower),high:round(upper),pivotTime:new Date(r.time).toISOString(),confirmedTime:new Date(rows[i+wing].time).toISOString(),pivotIndex:i,barsSinceConfirmation:last-i-wing,tests,invalidated});
   }
 }
 const open=candidates.filter(z=>!z.invalidated).sort((a,b)=>b.pivotIndex-a.pivotIndex);
 const selected=['demand','supply'].flatMap(type=>open.filter(z=>z.type===type).slice(0,3));
 return {latestClose:round(rows[last].close),checkedCandles:rows.length,confirmationBars:wing,candidates:candidates.length,invalidated:candidates.filter(z=>z.invalidated).length,zones:selected,feed:'UNVERIFIED USER CSV',decision:'NO LIVE CALL'};
}


/** Price-action video v4: causally confirmed double-top research, never a trade recommendation.
 *  Pair two *confirmed* local swing highs within the declared tolerance. The neckline is
 *  the lowest low between peaks. Breakdowns are counted only after second-pivot confirmation;
 *  the algorithm cannot attribute an earlier breakdown to a pattern available at that time.
 */
export function detectHistoricalDoubleTops(rows,{wing=2,tolerancePct=1.5,minSeparation=4,maxSeparation=35,minPullbackPct=1}={}){
  detectHistoricalZones(rows,wing); // shared strict OHLC/timestamp and minimum-candle validation.
  if(!Number.isFinite(tolerancePct)||tolerancePct<=0||tolerancePct>5||
     !Number.isFinite(minPullbackPct)||minPullbackPct<=0||minPullbackPct>10||
     !Number.isInteger(minSeparation)||minSeparation<wing*2||
     !Number.isInteger(maxSeparation)||maxSeparation<minSeparation||maxSeparation>100)
    throw new Error('Unsupported double-top pivot configuration.');
  const peaks=[];
  for(let i=wing;i<rows.length-wing;i++){
    let confirmed=true;
    for(let n=1;n<=wing;n++)if(!(rows[i].high>rows[i-n].high&&rows[i].high>rows[i+n].high)){confirmed=false;break;}
    if(confirmed)peaks.push(i);
  }
  const patterns=[];
  // Consecutive confirmed highs only: don't search all pairs for a hindsight fit.
  for(let k=1;k<peaks.length;k++){
    const a=peaks[k-1],b=peaks[k],span=b-a;
    if(span<minSeparation||span>maxSeparation)continue;
    const ha=rows[a].high,hb=rows[b].high;
    if(100*Math.abs(ha-hb)/Math.max(ha,hb)>tolerancePct)continue;
    const trough=Math.min(...rows.slice(a+1,b).map(c=>c.low));
    if(!(trough>0)||100*(Math.min(ha,hb)-trough)/Math.min(ha,hb)<minPullbackPct)continue;
    const confirm=b+wing,neckline=trough;
    let status='AWAITING NECKLINE BREAK',eventIndex=null;
    for(let j=confirm+1;j<rows.length;j++){
      if(rows[j].close>Math.max(ha,hb)*(1+tolerancePct/100)){
        status='INVALIDATED';eventIndex=j;break;
      }
      if(rows[j].close<neckline){status='HISTORICAL BREAK CONFIRMED';eventIndex=j;break;}
    }
    patterns.push({firstPeakTime:new Date(rows[a].time).toISOString(),secondPeakTime:new Date(rows[b].time).toISOString(),confirmedTime:new Date(rows[confirm].time).toISOString(),
      firstPeak:round(ha),secondPeak:round(hb),neckline:round(neckline),firstPeakIndex:a,secondPeakIndex:b,confirmationIndex:confirm,
      status,eventTime:eventIndex===null?null:new Date(rows[eventIndex].time).toISOString(),eventIndex,peakDifferencePct:round(100*Math.abs(ha-hb)/Math.max(ha,hb))});
  }
  return {patterns:patterns.slice(-3).reverse(),candidateCount:patterns.length,confirmedPivots:peaks.length,checkedCandles:rows.length,decision:'NO LIVE CALL',source:'UNVERIFIED USER CSV',method:'Two confirmed swing highs plus neckline; not a forecast'};
}
