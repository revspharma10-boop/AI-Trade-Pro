"""BTC specialist knowledge engine: explainable, research-only, no LLM or orders.

Technical states use completed candles. On-chain observations are sourced from a
public bitcoin blockchain explorer and NEVER treated as directional price alpha.
Unavailable macro, ETF-flow, derivatives and news data are explicitly marked as
not connected, not assigned guessed values. No claimed calibrated win rate.
"""
from __future__ import annotations
from datetime import datetime, timezone
import json
import math
import time
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.parse import urlsplit
from btc_lab import TIMEFRAMES, validate_candles, _ema_series, _rsi, DataUnavailable
from btc_signals import evaluate
from btc_planner import plan
from btc_education import TOPICS as BTC_FOUNDATION_TOPICS

ONCHAIN_URL = 'https://mempool.space/api/v1/fees/recommended'
SOURCE = 'mempool.space Bitcoin network recommended fees'

KNOWLEDGE = (
  {'level':'foundation','topic':'Spot BTC/USD and candles','principle':'A close is a historical reference, not a guaranteed fill. Bitcoin trades around the clock.'},
  {'level':'foundation','topic':'Position risk','principle':'Risk comes from quantity, stop distance, fees, slippage and gaps. Never assume stop execution.'},
  {'level':'intermediate','topic':'Trend and momentum','principle':'EMA/SMA regimes, RSI, Donchian breakout and price momentum can disagree; conflict supports WAIT.'},
  {'level':'intermediate','topic':'Volatility','principle':'ATR describes past trading ranges, not a forecast or a guaranteed loss bound.'},
  {'level':'advanced','topic':'Market regime','principle':'Separate trending, sideways and elevated-volatility regimes; do not reuse one untested threshold for every regime.'},
  {'level':'advanced','topic':'Strategy validation','principle':'Use completed candles, next-bar hypothetical fills, realistic fees, slippage and an out-of-sample benchmark.'},
  {'level':'specialist','topic':'Bitcoin monetary policy','principle':'Bitcoin issuance and the halving schedule are long-term fundamentals; they do not predict the next candle.'},
  {'level':'specialist','topic':'On-chain network activity','principle':'Mempool fee rates measure transaction congestion, not directly exchange buying pressure or BTC price direction.'},
  {'level':'specialist','topic':'Macro and institutional flows','principle':'Rates, USD liquidity, regulatory news, ETF flows and funding can matter; absent verified feeds, never invent their states.'},
  {'level':'specialist','topic':'Execution and microstructure','principle':'Spread, order-book depth, venue variation, liquidation risk and API latency must be accounted for before live execution.'},
)

# Original rule-engine knowledge is extended by the curated, sourced BTC-only academy.
# This expands explanations, NOT the six active trading strategies or decision thresholds.
KNOWLEDGE = KNOWLEDGE + tuple({'level':level,'topic':title,'principle':explanation}
                              for title,level,explanation,source in BTC_FOUNDATION_TOPICS)

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_brain_reports (
 timeframe INTEGER NOT NULL, candle_time BIGINT NOT NULL,
 verdict TEXT NOT NULL, report_json TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(timeframe,candle_time));
"""
POSTGRES_SCHEMA = SQLITE_SCHEMA

class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise DataUnavailable('Unexpected Bitcoin fundamentals provider redirect')


def fetch_onchain():
    """One bounded, no-credential GET. A failed source is represented as missing."""
    request = Request(ONCHAIN_URL, headers={'Accept':'application/json','User-Agent':'AlgoTraderBTCResearch/1.0'})
    try:
        with build_opener(_NoRedirect()).open(request,timeout=5) as response:
            loc=urlsplit(response.geturl())
            if loc.scheme!='https' or loc.hostname!='mempool.space':
                raise DataUnavailable('Unexpected fundamental-data host')
            raw=response.read(2049)
        if len(raw)>2048:
            raise DataUnavailable('Fundamental data response exceeded bound')
        obj=json.loads(raw)
        if not isinstance(obj,dict):
            raise ValueError('Expected JSON object')
        rates={}
        for key in ('fastestFee','halfHourFee','hourFee','economyFee'):
            n=obj.get(key)
            if isinstance(n,bool) or not isinstance(n,(float,int)) or not math.isfinite(n) or not 0<n<100000:
                raise ValueError('Invalid fee rate')
            rates[key]=round(float(n),2)
        return {'status':'AVAILABLE','source':SOURCE,'unit':'sat/vB',
                'fetched_at_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                'rates':rates,'directional_price_signal':None,
                'note':'Network congestion/fees are NOT a BTC price prediction.'}
    except (OSError,TimeoutError,UnicodeError,ValueError,DataUnavailable) as exc:
        return {'status':'UNAVAILABLE','source':SOURCE,'unit':'sat/vB',
                'fetched_at_utc':None,'rates':None,'directional_price_signal':None,
                'note':'Bitcoin on-chain fees unavailable or unverified. No fundamental value was inferred.'}


def _utc(sec):
    return datetime.fromtimestamp(int(sec),timezone.utc).isoformat(timespec='seconds')


def analyze(candles, timeframe, account, *, onchain=None, timestamp=None):
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported BTC timeframe')
    candles=validate_candles(candles)
    now=int(time.time() if timestamp is None else timestamp)
    checked=evaluate(candles,timeframe,timestamp=now)  # incomplete and stale feed fail-closed
    pl=plan(candles,timeframe,account,timestamp=now)
    if not isinstance(onchain,dict) or onchain.get('status') not in ('AVAILABLE','UNAVAILABLE'):
        onchain={'status':'UNAVAILABLE','source':SOURCE,'rates':None,'note':'Missing fundamental data','directional_price_signal':None}
    if onchain.get('status')=='AVAILABLE':
        rs=onchain.get('rates')
        if not isinstance(rs,dict) or not all(k in rs and type(rs[k]) in (int,float) and math.isfinite(rs[k]) and rs[k]>0 for k in ('fastestFee','halfHourFee','hourFee','economyFee')):
            onchain={'status':'UNAVAILABLE','source':SOURCE,'rates':None,'note':'Invalid fundamental data','directional_price_signal':None}
    close=candles[-1]['close']
    closes=[c['close'] for c in candles]
    e12=_ema_series(closes,12)[-1];e26=_ema_series(closes,26)[-1]
    trend='UP' if e12>e26*1.001 else 'DOWN' if e12<e26*.999 else 'SIDEWAYS'
    rsi=_rsi(closes,len(closes)-1)
    atr=pl['atr_14_usd']
    atr_pct=100*atr/close
    regime='ELEVATED_VOLATILITY' if atr_pct>4.0 else 'TRENDING' if trend!='SIDEWAYS' else 'RANGE'
    bullish=sum(s['signal'] in ('BUY','HOLD_LONG') for s in checked)
    bearish=6-bullish
    open_positions=bool(account.get('positions'))
    reasons=[f'{bullish} of 6 technical strategies currently favor spot BTC exposure.',
             f'EMA12/EMA26 trend is {trend.lower()}, RSI14 is {rsi:.1f} and ATR14 is {atr_pct:.2f}% of BTC close.']
    limitations=['No verified macro interest-rate/USD liquidity feed connected.',
                 'No verified Bitcoin ETF inflows/outflows or derivatives funding feed connected.',
                 'No verified news/event sentiment feed connected.',
                 'No automated BTC paper orders or live exchange execution.']
    if onchain['status']=='AVAILABLE':
        reasons.append('Bitcoin network fee observations are available; they are not used as a bullish/bearish BTC price signal.')
    else:
        limitations.insert(0,'Bitcoin network fee data unavailable; fundamental coverage is incomplete.')
    verdict='WAIT'
    if open_positions:
        verdict='REVIEW_EXIT' if bullish<=2 and trend=='DOWN' else 'MANAGE_OPEN_POSITION'
        reasons.append('An existing paper position takes priority; do not enter a duplicate position.')
    elif pl['state']=='CONDITIONAL_LONG' and trend=='UP' and regime!='ELEVATED_VOLATILITY' and onchain['status']=='AVAILABLE':
        verdict='CONDITIONAL_BUY'
        reasons.append('Existing BTC paper risk rules permit a conditional breakout only; no market order is sent.')
    else:
        if pl['state']!='CONDITIONAL_LONG':reasons.append('No paper-risk-eligible BTC entry setup; stay flat.')
        if regime=='ELEVATED_VOLATILITY':reasons.append('ATR is elevated relative to close; reject new entries in this conservative model.')
        if trend!='UP':reasons.append('Trend confirmation for a new long is absent.')
        if onchain['status']!='AVAILABLE':reasons.append('Source completeness gate: on-chain reference unavailable, so no new buy call.')
    return {
      'pair':'BTC/USD','timeframe_minutes':timeframe,'verdict':verdict,
      'candle_time':candles[-1]['time'],'completed_candle_utc':_utc(candles[-1]['time']+60*timeframe),
      'evaluated_at_utc':_utc(now),'observed_close_usd':round(close,2),
      'technical':{'bullish_strategy_count':bullish,'bearish_or_flat_count':bearish,'strategy_states':checked,
                   'ema12':round(e12,2),'ema26':round(e26,2),'rsi14':round(rsi,2),
                   'atr14_usd':round(atr,2),'atr_pct':round(atr_pct,2),'trend':trend,'market_regime':regime},
      'fundamental':{'bitcoin_policy':'Fixed maximum issuance of 21 million BTC; halvings reduce block subsidy over time, not immediate price predictions.',
                     'network_fees':onchain,
                     'macro':'NOT_CONNECTED','etf_flows':'NOT_CONNECTED','derivatives_funding':'NOT_CONNECTED','news':'NOT_CONNECTED',
                     'coverage':'NETWORK_ONLY' if onchain['status']=='AVAILABLE' else 'NO_LIVE_FUNDAMENTALS'},
      'paper_plan':{'state':pl['state'], 'entry_trigger_usd':pl.get('entry_trigger_usd'),
                    'stop_loss_usd':pl.get('stop_loss_usd'),'target_1_usd':pl.get('target_1_usd'),
                    'target_2_usd':pl.get('target_2_usd'),'max_paper_btc_qty':pl.get('max_paper_btc_qty'),
                    'setup_expires_utc':pl.get('setup_expires_utc')},
      'reasons':reasons,'unknowns':limitations,'education_levels':['foundation','intermediate','advanced','specialist'],
      'knowledge_version':'btc-knowledge-v1','engine_kind':'EXPLAINABLE_RULE_ENGINE','llm_connected':False,
      'calibrated_probability':None,'automatic_scheduler_enabled':False,
      'paper_execution_enabled':False,'real_order_execution_enabled':False,
      'notice':'Research-only. Not a trained AI forecast, not investment advice, no automatic execution. WAIT when data or risk controls are insufficient.'}


def record(db, result):
    if result.get('engine_kind')!='EXPLAINABLE_RULE_ENGINE' or result.get('verdict') not in ('WAIT','CONDITIONAL_BUY','REVIEW_EXIT','MANAGE_OPEN_POSITION'):
        raise DataUnavailable('Invalid research report')
    serialized=json.dumps(result,sort_keys=True,allow_nan=False,separators=(',',':'))
    if len(serialized)>65536: raise DataUnavailable('Report too large')
    db.execute('BEGIN IMMEDIATE')
    try:
        db.execute('INSERT INTO btc_brain_reports (timeframe,candle_time,verdict,report_json,created_at) VALUES(?,?,?,?,?) ON CONFLICT(timeframe,candle_time) DO NOTHING',
                   (result['timeframe_minutes'],result['candle_time'],result['verdict'],serialized,result['evaluated_at_utc']))
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK');raise
    return result


def history(db, timeframe):
    if type(timeframe) is not int or timeframe not in TIMEFRAMES: raise DataUnavailable('Unsupported timeframe')
    rows=db.execute('SELECT report_json FROM btc_brain_reports WHERE timeframe=? ORDER BY candle_time DESC LIMIT 20',(timeframe,)).fetchall()
    return {'pair':'BTC/USD','timeframe_minutes':timeframe,'reports':[json.loads(row[0]) for row in rows],
            'engine_kind':'EXPLAINABLE_RULE_ENGINE','automatic_scheduler_enabled':False,
            'paper_execution_enabled':False,'real_order_execution_enabled':False}
