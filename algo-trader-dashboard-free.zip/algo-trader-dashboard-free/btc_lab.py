"""BTC/USD only. Read-only historical strategy lab; NEVER routes any order.

Uses Kraken's public spot OHLC endpoint on deliberate requests. Kraken returns
up to 720 bars, including one *uncommitted* current bar that is always dropped.
Backtest makes decisions only on closed candles and fills at the following open.
Returns research metrics, never changes the authenticated paper ledger.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.parse import urlsplit

PAIR = 'BTC/USD'
PROVIDER = 'Kraken public spot OHLC'
ENDPOINT = 'https://api.kraken.com/0/public/OHLC'
TIMEFRAMES = {5: '5m', 15: '15m', 60: '1h', 240: '4h', 1440: '1d'}
STRATEGIES = {
    'sma_cross': ('SMA 10/30', 'Trend following with 10- and 30-bar simple averages'),
    'ema_cross': ('EMA 12/26', 'Trend following with 12- and 26-bar exponential averages'),
    'rsi_revert': ('RSI(14) reversion', 'Enter below RSI 30; exit above RSI 60'),
    'bollinger': ('Bollinger 20/2', 'Enter below lower band; exit above 20-bar mean'),
    'breakout': ('Donchian 20', 'Break above previous 20-bar high; exit below previous 10-bar low'),
    'momentum': ('12-bar momentum', 'Enter if 12-bar price change exceeds 2%; exit below -0.5%'),
}
MAX_BYTES = 1_000_000
MIN_CANDLES = 55
FEE_RATE = 0.001  # illustrative 10 bps per trade side; not an exchange promise
SLIPPAGE_RATE = 0.0005  # illustrative 5 bps per side
STARTING_CASH = 5000.0

class DataUnavailable(Exception):
    pass

class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise DataUnavailable('Unexpected market-provider redirect')


def validate_candles(candles: list[dict]) -> list[dict]:
    if not isinstance(candles, list) or not (MIN_CANDLES <= len(candles) <= 719):
        raise DataUnavailable(f'Need {MIN_CANDLES}–719 completed BTC candles')
    out = []
    prev = 0
    for row in candles:
        if not isinstance(row, dict):
            raise DataUnavailable('Invalid candle')
        try:
            ts = row['time']
            if isinstance(ts, bool) or not isinstance(ts, int) or ts <= prev:
                raise DataUnavailable('Candle timestamps must be increasing')
            o, h, l, c = (float(row[k]) for k in ('open', 'high', 'low', 'close'))
        except (KeyError, TypeError, ValueError) as e:
            raise DataUnavailable('Invalid candle values') from e
        if not all(math.isfinite(n) and 0 < n < 1e9 for n in (o, h, l, c)) or h < max(o, c) or l > min(o, c):
            raise DataUnavailable('Invalid BTC OHLC prices')
        out.append({'time': ts, 'open': o, 'high': h, 'low': l, 'close': c})
        prev = ts
    return out


def parse_kraken(data: dict) -> list[dict]:
    if not isinstance(data, dict) or data.get('error'):
        raise DataUnavailable('Market provider reported an error')
    result = data.get('result')
    if not isinstance(result, dict):
        raise DataUnavailable('Invalid market provider response')
    keys = [k for k, v in result.items() if k != 'last' and isinstance(v, list)]
    if len(keys) != 1 or keys[0] not in {'XXBTZUSD', 'XBTUSD', 'BTC/USD'}:
        raise DataUnavailable('Expected BTC/USD candles only')
    rows = result[keys[0]]
    # Report the row count rather than implying an unavailable trading signal.
    # The market feed occasionally provides fewer records than our strategy warm-up
    # needs. In that case, fail closed: no fabricated historical bars or signals.
    if len(rows) < MIN_CANDLES + 1:
        raise DataUnavailable(
            f'Kraken provided {len(rows)} candle rows for BTC/USD; '
            f'at least {MIN_CANDLES + 1} are needed, including the unfinished bar. '
            'No signals were calculated. Try another timeframe after 60 seconds.'
        )
    # Always discard the current unfinished bar. Future Kraken responses may exceed
    # the former 720-bar return limit; use only the latest 719 completed records.
    if len(rows) > 720:
        rows = rows[-720:]
    candles = []
    for row in rows[:-1]:  # Kraken documents last candle as incomplete, never backtest it.
        if not isinstance(row, list) or len(row) < 7:
            raise DataUnavailable('Malformed market candle')
        candles.append({'time': row[0], 'open': row[1], 'high': row[2], 'low': row[3], 'close': row[4]})
    return validate_candles(candles)


def fetch_recent_btc(timeframe: int) -> list[dict]:
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported BTC timeframe')
    url = f'{ENDPOINT}?pair=XBTUSD&interval={timeframe}'
    request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'AlgoTraderBTCResearch/1.0'})
    try:
        with build_opener(_NoRedirect()).open(request, timeout=8) as response:
            loc = urlsplit(response.geturl())
            if loc.scheme != 'https' or loc.hostname != 'api.kraken.com':
                raise DataUnavailable('Unexpected market provider host')
            raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise DataUnavailable('Market feed response too large')
        return parse_kraken(json.loads(raw))
    except (OSError, TimeoutError, UnicodeDecodeError, ValueError, json.JSONDecodeError) as e:
        raise DataUnavailable('BTC candle feed unavailable or invalid') from e


def _sma(values, i, n):
    if i < n - 1:
        return None
    return sum(values[i - n + 1:i + 1]) / n


def _ema_series(values, n):
    alpha = 2 / (n + 1)
    ema = values[0]
    result = []
    for v in values:
        ema += alpha * (v - ema)
        result.append(ema)
    return result


def _rsi(closes, i, n=14):
    if i < n:
        return None
    changes = [closes[j] - closes[j-1] for j in range(i - n + 1, i + 1)]
    gains = sum(max(ch, 0) for ch in changes)
    losses = -sum(min(ch, 0) for ch in changes)
    if gains + losses == 0:
        return 50.0
    return 100 * gains / (gains + losses)


def _regime(candles: list[dict], strategy: str):
    """Desired spot exposure at the close of each fully observed candle."""
    closes = [c['close'] for c in candles]
    regimes = []
    ema12, ema26 = _ema_series(closes, 12), _ema_series(closes, 26)
    for i, close in enumerate(closes):
        prior = regimes[-1] if regimes else False
        if strategy == 'sma_cross':
            a, b = _sma(closes, i, 10), _sma(closes, i, 30)
            desired = prior if b is None else a > b
        elif strategy == 'ema_cross':
            desired = prior if i < 29 else ema12[i] > ema26[i]
        elif strategy == 'rsi_revert':
            r = _rsi(closes, i)
            desired = prior if r is None else (False if r > 60 else True if r < 30 else prior)
        elif strategy == 'bollinger':
            avg = _sma(closes, i, 20)
            if avg is None:
                desired = prior
            else:
                std = math.sqrt(sum((p-avg)**2 for p in closes[i-19:i+1]) / 20)
                desired = False if close > avg else True if close < avg-2*std else prior
        elif strategy == 'breakout':
            desired = prior if i < 20 else (True if close > max(c['high'] for c in candles[i-20:i]) else
                False if close < min(c['low'] for c in candles[i-10:i]) else prior)
        elif strategy == 'momentum':
            change = close / closes[i-12] - 1 if i >= 12 else 0
            desired = False if i < 12 else True if change > .02 else False if change < -.005 else prior
        else:
            raise ValueError('Unknown BTC strategy')
        regimes.append(bool(desired))
    return regimes


def backtest(candles: list[dict], strategy: str) -> dict:
    if strategy not in STRATEGIES:
        raise ValueError('Unknown BTC strategy')
    candles = validate_candles(candles)
    desired = _regime(candles, strategy)
    cash, qty, entry_cost = STARTING_CASH, 0.0, 0.0
    equity_curve, completed = [], []
    peak = cash
    max_dd = 0.0
    for i, candle in enumerate(candles):
        if i > 0:
            if desired[i - 1] and qty == 0:
                fill = candle['open'] * (1 + SLIPPAGE_RATE)
                # Purchase within available cash, including the fee. No leverage or shorting.
                spent = cash * .95
                qty = spent / (fill * (1 + FEE_RATE))
                entry_cost = spent
                cash -= spent
            elif not desired[i - 1] and qty > 0:
                fill = candle['open'] * (1 - SLIPPAGE_RATE)
                received = qty * fill * (1 - FEE_RATE)
                cash += received
                completed.append(round(received - entry_cost, 2))
                qty = entry_cost = 0.0
        eq = cash + qty * candle['close']
        peak = max(peak, eq)
        max_dd = max(max_dd, (peak - eq) / peak)
        equity_curve.append(round(eq, 2))
    final_equity = equity_curve[-1]
    baseline_price = candles[1]['open'] * (1 + SLIPPAGE_RATE)
    baseline_spend = STARTING_CASH * .95
    baseline_qty = baseline_spend / (baseline_price * (1 + FEE_RATE))
    baseline = STARTING_CASH - baseline_spend + baseline_qty * candles[-1]['close']
    wins = sum(p > 0 for p in completed)
    return {
        'strategy': strategy, 'name': STRATEGIES[strategy][0],
        'symbol': PAIR, 'candles': len(candles),
        'from_utc': datetime.fromtimestamp(candles[0]['time'], timezone.utc).isoformat(),
        'through_utc': datetime.fromtimestamp(candles[-1]['time'], timezone.utc).isoformat(),
        'starting_cash_usd': STARTING_CASH,
        'ending_equity_usd': round(final_equity, 2),
        'return_pct': round((final_equity/STARTING_CASH-1)*100, 2),
        'buy_hold_return_pct': round((baseline/STARTING_CASH-1)*100, 2),
        'max_drawdown_pct': round(max_dd*100, 2),
        'closed_trades': len(completed), 'winning_trades': wins,
        'win_rate_pct': round(100*wins/len(completed), 2) if completed else None,
        'position_open': qty > 0,
        'latest_decision': 'BUY' if desired[-1] and qty == 0 else
                           'EXIT' if not desired[-1] and qty > 0 else 'HOLD',
        'trading_costs': {'fee_per_side_pct': FEE_RATE*100, 'slippage_per_side_pct': SLIPPAGE_RATE*100},
        'equity_curve': equity_curve[-120:],
        'warning': 'Historical research only. No orders are placed. No future profit is implied.',
    }
