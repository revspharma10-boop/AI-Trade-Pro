"""Curated BTC-only fundamentals and trading strategy glossary; original summaries, not a scraped website dump.

The live engine still implements ONLY the six strategies in btc_lab.py.
Knowledge entries explain concepts and cite origin; no direct investment instructions.
"""
from btc_lab import STRATEGIES

SOURCES={
 'bitcoin':'https://bitcoin.org/en/halving',
 'blockstream':'https://help.blockstream.com/education/fundamentals/getting-started/how-does-bitcoin-work',
 'kraken-trades':'https://blog.kraken.com/crypto-education/the-markets-series-part-2-explaining-crypto-trading',
 'kraken-ohlc':'https://support.kraken.com/in/articles/360047124832-downloadable-historical-ohlcvt-open-high-low-close-volume-trades-data',
 'kraken-flow':'https://support.kraken.com/au/articles/analytics-widgets-on-kraken-pro',
 'kraken-api':'https://support.kraken.com/in/articles/360000919986-public-endpoint-examples-you-can-try-them-directly-in-a-web-browser-',
 'btc-supply':'https://help.blockstream.com/education/economics/bitcoin-economics/why-is-the-bitcoin-supply-limited',
 'technical':'https://www.fidelity.com/learning-center/trading-investing/technical-analysis',
 'rating':'https://www.tradingview.com/support/solutions/43000614331-technical-ratings/',
}
TOPICS=[
('How Bitcoin is created','foundation','Miners assemble and validate blocks using proof of work. The winning valid block creates new BTC through the coinbase subsidy, plus receives transaction fees. Mining does not mint arbitrary coins. New BTC is created by consensus rules, not by exchange trades.','blockstream'),
('Bitcoin supply and halving','foundation','Bitcoin began at 50 BTC subsidy per block in 2009. The subsidy halves every 210,000 blocks; it is 3.125 BTC after the April 2024 halving, targeting nearly 21 million BTC total. New issuance declines predictably but does not forecast any single price move.','btc-supply'),
('How BTC is bought and sold','foundation','In BTC/USD spot trading a buyer exchanges dollars for BTC and a seller does the reverse; both sides exist in every transaction. Marketable orders cross the order book while passive limit orders provide liquidity. Exchanges match buyers and sellers; they do not create new bitcoins.','kraken-trades'),
('Price discovery and order books','foundation','Prices change when aggressive orders consume available quotes. Large orders can move through thin order-book levels; the spread and liquidity determine the cost of immediate execution. A high buy trade fraction is not the fraction of investors who want to buy.','kraken-flow'),
('What makes Bitcoin rise','foundation','Demand rising relative to immediately available supply can push price higher. Possible catalysts include stronger spot inflows, adoption, optimistic macro conditions, short squeezes or liquidity shifts. One event cannot establish causation without timing and volume evidence.','blockstream'),
('What makes Bitcoin fall','foundation','Aggressive selling, risk-off moves, ETF outflows, forced liquidations, exchange stress, regulation, or reduced liquidity can drive price down. Market conditions can outweigh long-run scarcity. A price fall does not prove mining issuance increased.','blockstream'),
('Mining economics','intermediate','Miners incur equipment, electricity and funding costs. Subsidy halving reduces new coin issuance per block and can affect miner economics, but miners do not set the global BTC market price. Miner transfers are not automatically sales.','bitcoin'),
('Candlesticks and volume','foundation','OHLCV records the traded open, high, low, close and BTC volume during each interval. An unfinished candle can reverse before its close; confirmed research signals must use fully completed candles.','kraken-ohlc'),
('Market buy/sell pressure','intermediate','Kraken trade-side tags identify the aggressive taker buying or selling in a sampled set of executions. Compare BTC quantity on each side; the ratio is an exchange-specific, momentary sample, not all BTC positions.','kraken-trades'),
('Trend, momentum and ranges','intermediate','Moving averages smooth prices; momentum compares past closes; breakout rules watch earlier highs and lows. Trending systems can whipsaw in flat regimes, while mean-reversion systems can fail during persistent trends.','kraken-ohlc'),
('Volatility and liquidation dynamics','advanced','ATR and realized volatility describe historical dispersion, not future direction. Leverage magnifies losses and forced closures; unverified exchange-wide liquidations or futures funding should never be claimed as observed facts.','kraken-flow'),
('Macroeconomics and USD liquidity','specialist','Central-bank policy, Treasury yields, real rates, dollar strength and risk appetite may influence crypto demand, but relationships change. This app has no verified macro feed yet and does not score nonexistent observations.','btc-supply'),
('Institutions, ETF and regulatory news','specialist','Spot ETF creations/redemptions, company reserves, legal changes, regulation and custody events can change demand or access. News headlines need source, timestamp, relevance and confirmation. Live ETF/news feeds are not yet connected.','btc-supply'),
('Risk and position sizing','advanced','A hypothetical position size must reflect stop distance, fees, slippage, daily loss limits and cash constraints. Stops are not guaranteed executions. The dashboard is paper-only and keeps actual order execution disabled.','kraken-flow'),
('Backtesting without look-ahead','advanced','Compare each strategy against BTC buy-and-hold and a no-trade benchmark. Model decision at completed candle, execution on a later bar, trading costs, drawdown, regime differences and genuinely out-of-sample outcomes.','kraken-ohlc'),
('On-chain activity versus market flow','specialist','Wallet transfer counts, block times, mempool congestion and sat/vbyte fees reflect Bitcoin network activity; they are not directly Kraken taker flow. Without extra evidence they do not indicate tomorrow’s BTC price direction.','blockstream'),
]
CATEGORIES={
 'trend':[('SMA cross','sma_cross'),('EMA cross','ema_cross'),('Supertrend',None),('MACD histogram and cross',None),('ADX regime filter',None),('Ichimoku cloud',None),('Parabolic SAR',None),('Multi-timeframe trend alignment',None)],
 'momentum':[('RSI reversion','rsi_revert'),('Price momentum','momentum'),('Stochastic oscillator',None),('Rate of change (ROC)',None),('Relative-strength divergence',None)],
 'breakout':[('Donchian channel','breakout'),('Previous high/low breakout',None),('Opening-range breakout (session defined)',None),('ATR expansion breakout',None),('Volatility contraction breakout',None)],
 'mean reversion':[('Bollinger Bands','bollinger'),('Keltner channel reversion',None),('VWAP deviation reversion',None),('Z-score of returns',None)],
 'volume & order flow':[('Volume-confirmed price breakout',None),('VWAP volume profile',None),('Taker buy/sell volume imbalance',None),('Order-book depth imbalance',None),('Cumulative volume delta',None),('Liquidity sweep analysis',None)],
 'market structure':[('Support/resistance retest',None),('Swing high/low structure',None),('Moving support/resistance',None),('Trendline pullback',None)],
 'bitcoin fundamentals':[('BTC halving/issuance context',None),('Miner revenue and hash-rate context',None),('On-chain fee and mempool context',None),('Spot ETF flow regime (feed needed)',None),('Funding and open interest (feed needed)',None),('Macro rates/liquidity context (feed needed)',None)],
 'portfolio & validation':[('Volatility position sizing',None),('ATR trailing stop',None),('Risk reward and expected value',None),('Maximum drawdown control',None),('Walk-forward validation',None),('Ensemble strategy agreement',None)],
}

def knowledge_catalog():
    topics=[{'title':t,'level':level,'explanation':explanation,'source_url':SOURCES[src]} for t,level,explanation,src in TOPICS]
    strategies=[]
    for category,items in CATEGORIES.items():
        for name,code in items:
            is_live=code in STRATEGIES
            strategies.append({'category':category,'name':name,'implementation_status':'BACKTESTED_RULE' if is_live else 'KNOWLEDGE_ONLY',
                               'method_key':code,'warning':'Educational concept; not connected to live prediction, not validated for profits.' if not is_live else 'Implemented as a historical test; accuracy is not established.',
                               'source_url':SOURCES['technical'] if category not in ('bitcoin fundamentals','volume & order flow') else SOURCES['bitcoin' if category=='bitcoin fundamentals' else 'kraken-flow']})
    return {'scope':'BITCOIN_ONLY','asset':'BTC/USD','topics':topics,'strategies':strategies,
            'implemented_strategy_count':len(STRATEGIES),'total_catalogued_strategies':len(strategies),
            'sources':SOURCES,'llm_connected':False,'not_connected':['ETF flows','funding rate','open interest','macro rates','verified live news'],
            'disclaimer':'Curated concepts with links to source material, not every strategy on the Internet. Only strategies explicitly marked BACKTESTED_RULE run in the engine. No guaranteed calls or orders.'}
