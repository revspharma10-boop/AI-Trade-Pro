"""BTC/USD educational, conditional entry/exit planner. NO orders or guarantees.

All market levels derive exclusively from recent FINISHED spot candles. Candidates
are contingent on future price action, never represented as actual fill prices.
The planner does not alter either paper ledger and does not schedule itself.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
import time

from btc_lab import TIMEFRAMES, validate_candles, DataUnavailable, FEE_RATE, SLIPPAGE_RATE
from btc_signals import evaluate
from btc_paper import SATOSHI, _plan, PaperRuleError


def _utc(seconds: int) -> str:
    return datetime.fromtimestamp(seconds, timezone.utc).isoformat(timespec='seconds')


def _p(value: float) -> float:
    return round(value, 4)


def _wait(reason: str, *, signals: list, candle_time: int, timeframe: int,
          price: float, atr: float, now: int, account: dict) -> dict:
    return {
        'pair': 'BTC/USD', 'state': 'WAIT', 'reason': reason,
        'timeframe_minutes': timeframe, 'latest_completed_candle_utc': _utc(candle_time),
        'observed_close_usd': _p(price), 'atr_14_usd': _p(atr),
        'bullish_strategies': sum(x['signal'] in ('BUY','HOLD_LONG') for x in signals),
        'strategies_checked': len(signals), 'signals': signals,
        'entry_trigger_usd': None, 'stop_loss_usd': None,
        'target_1_usd': None, 'target_2_usd': None, 'max_paper_btc_qty': None,
        'estimated_notional_usd': None, 'estimated_stop_risk_usd': None,
        'max_risk_budget_usd': None,
        'setup_expires_utc': _utc(candle_time + 2*timeframe*60),
        'calculated_at_utc': _utc(now), 'paper_execution_enabled': False,
        'real_order_execution_enabled': False, 'certainty_pct': None,
        'source': 'Kraken completed BTC/USD spot OHLC',
        'warning': 'WAIT means no eligible long setup. Calculations are educational, not a future-price forecast. Fees, slippage and price gaps can exceed risk estimates. Stops and targets are not executed.',
    }


def plan(candles: list[dict], timeframe: int, paper_account: dict, *, timestamp: int | None = None) -> dict:
    """Make one conditional long-only setup; never inspect an incomplete candle."""
    candles = validate_candles(candles)
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported timeframe')
    now = int(time.time() if timestamp is None else timestamp)
    if isinstance(paper_account, dict) is False:
        raise DataUnavailable('BTC paper account unavailable')
    seconds = timeframe * 60
    stamp = candles[-1]['time']
    if stamp + seconds > now or now > stamp + 2*seconds + 120:
        raise DataUnavailable('Market candle unfinished or stale; no entry/exit plan')
    # The same finished-candle signal evaluator as the audited signal monitor.
    signals = evaluate(candles, timeframe, timestamp=now)
    close = candles[-1]['close']
    trs = []
    for i in range(len(candles)-14, len(candles)):
        c, prev = candles[i], candles[i-1]
        trs.append(max(c['high']-c['low'], abs(c['high']-prev['close']), abs(c['low']-prev['close'])))
    atr = sum(trs) / len(trs)
    if not 0 < atr < close:
        raise DataUnavailable('Invalid BTC volatility estimate')
    bullish = sum(x['signal'] in ('BUY','HOLD_LONG') for x in signals)
    def wait(reason):
        return _wait(reason, signals=signals,candle_time=stamp,timeframe=timeframe,
                     price=close,atr=atr,now=now,account=paper_account)
    if paper_account.get('positions'):
        return wait('BTC paper position already open. Follow its existing recorded stop/target and close manually; no second entry.')
    if int(paper_account.get('entries_today',0)) >= 3:
        return wait('Daily entry limit reached (3 entries per UTC day).')
    if bullish < 4:
        return wait('Fewer than four of six strategies favor a long position; no new BTC entry proposed.')
    # Last completed close is a reference, never an execution price.
    trigger = max(close + .10*atr, max(c['high'] for c in candles[-4:]))
    trigger = _p(trigger + .0001)  # must break the prior completed high
    stop = _p(min(min(c['low'] for c in candles[-5:]), trigger-1.5*atr))
    dist = trigger - stop
    if stop <= 0 or dist <= 0 or dist/trigger > .08:
        return wait('Required stop distance exceeds the maximum 8% setup band; do not chase volatility.')
    t1 = _p(trigger + 2*dist)
    t2 = _p(trigger + 3*dist)
    cash = float(paper_account['cash'])
    equity = float(paper_account['equity'])
    daily = 150.0 - float(paper_account.get('loss_today',0)) - float(paper_account.get('planned_open_risk',0))
    budget = min(50, .01*equity, daily)
    if budget < .02:
        return wait('Daily or account risk budget exhausted.')
    max_notional = min(2500, .5*equity, max(0, (cash-.1*equity)/(1+FEE_RATE)))
    per_btc_stop_risk = dist + FEE_RATE*(trigger+stop)
    if per_btc_stop_risk <= 0:
        raise DataUnavailable('Invalid BTC stop-risk estimate')
    qty = min(max_notional/trigger, budget/per_btc_stop_risk)*.995  # rounding buffer
    qty_d = Decimal(str(qty)).quantize(SATOSHI, rounding=ROUND_DOWN)
    if qty_d <= 0:
        return wait('Calculated BTC quantity smaller than one satoshi.')
    try:
        class Req: pass
        req=Req();req.qty=str(qty_d);req.entry_price=trigger;req.stop_price=stop;req.target_price=t1
        q,e,s,t,notional,fee,risk = _plan(req)
    except PaperRuleError:
        return wait('Setup cannot meet the BTC paper-ledger minimum or risk rules.')
    if float(risk)>budget or float(notional)>max_notional or float(notional)<10:
        return wait('Setup fails current notional or risk budget; stand aside.')
    out = _wait('Only a conditional breakout setup; wait for trigger and recalculate with a fresh candle.',
                signals=signals,candle_time=stamp,timeframe=timeframe,
                price=close,atr=atr,now=now,account=paper_account)
    out.update({
        'state':'CONDITIONAL_LONG',
        'entry_trigger_usd':trigger, 'stop_loss_usd':stop,
        'target_1_usd':t1, 'target_2_usd':t2,
        'reward_risk_target_1':round((t1-trigger)/dist,2),
        'reward_risk_target_2':round((t2-trigger)/dist,2),
        'max_paper_btc_qty':float(q),
        'estimated_notional_usd':float(notional),
        'estimated_stop_risk_usd':float(risk),
        'max_risk_budget_usd':round(budget,2),
        'fee_assumption_per_side_pct':FEE_RATE*100,
        'slippage_assumption_per_side_pct':SLIPPAGE_RATE*100,
        'entry_condition':'Only consider a manual paper long if price subsequently breaks the trigger before the setup expiry. No orders are placed.',
        'stop_condition':'If a simulated position is opened, the stop is an educational manual exit level; gaps can cause larger losses.',
        'target_condition':'Targets are 2R and 3R illustration levels, not predicted prices or automatic exits.',
        'warning':'Condition-based hypothetical BTC/USD paper setup only. Observed close is not a tradable quote; no price or probability forecast. Entry and stops are NOT automatic.',
    })
    return out
