"""Optional, read-only end-of-day CSV data from Stooq.

This is not exchange-grade market data. It NEVER prices or executes simulated
trades automatically. Caller must check errors and display the actual bar date.
"""
from __future__ import annotations

import csv
from datetime import date, timedelta
from io import StringIO
import math
import re
from urllib.request import Request, build_opener, HTTPRedirectHandler

PROVIDER = "Stooq"
_SYMBOL = re.compile(r"^[A-Z]{1,5}(?:\.[A-Z])?$")
ENDPOINT = "https://stooq.com/q/d/l/"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise DataUnavailable("Market provider attempted a redirect")


class DataUnavailable(Exception):
    pass


def read_eod(symbol: str, today: date | None = None) -> dict:
    """Fetch a daily *historical* closing bar; treat as delayed and non-actionable.

    Only fixed-host URLs constructed from validated US equity tickers are used.
    No arbitrary URLs, redirects to insecure origins, or large responses.
    """
    if not _SYMBOL.fullmatch(symbol):
        raise DataUnavailable("Unsupported US symbol")
    today = today or date.today()
    start = today - timedelta(days=21)
    ticker = symbol.lower().replace('.', '-') + '.us'
    url = f"{ENDPOINT}?s={ticker}&i=d&d1={start:%Y%m%d}&d2={today:%Y%m%d}"
    req = Request(url, headers={"User-Agent": "AlgoTraderPaperDashboard/2.0 (personal EOD research)",
                                "Accept": "text/csv"})
    try:
        with build_opener(NoRedirect()).open(req, timeout=8) as response:
            from urllib.parse import urlsplit
            final = urlsplit(response.geturl())
            if final.scheme != "https" or final.hostname != "stooq.com":
                raise DataUnavailable("Market feed redirected to an unexpected host")
            raw = response.read(64_001)
    except (OSError, TimeoutError, ValueError) as e:
        raise DataUnavailable("Market data endpoint unavailable") from e
    if len(raw) > 64_000:
        raise DataUnavailable("Market feed response too large")
    try:
        content = raw.decode('utf-8-sig')
        reader = csv.DictReader(StringIO(content))
        if not reader.fieldnames or not {'Date', 'Close'}.issubset(reader.fieldnames):
            raise DataUnavailable("No valid daily bars for symbol")
        rows = []
        for row in reader:
            asof = date.fromisoformat(row['Date'])
            price = float(row['Close'])
            if not math.isfinite(price) or not (0 < price < 1_000_000_000):
                continue
            if asof <= today:
                rows.append((asof, price))
        if not rows:
            raise DataUnavailable("No valid daily bars for symbol")
        bar_date, price = max(rows, key=lambda r: r[0])
        return {"symbol": symbol, "close": round(price, 4), "bar_date": bar_date.isoformat(), "provider": PROVIDER}
    except (ValueError, KeyError, TypeError, csv.Error) as e:
        raise DataUnavailable("Invalid historical market data format") from e
