# Algo Trader Dashboard — Free Version (paper trading only)

This is a self-contained web app for simulated long-only trades, manual scenario prices, watchlists, a paper ledger and risk-limit validation. It has **no broker integration and cannot submit orders**.

## Two free ways to run

### A. On your own computer — recommended if your data matters

Requires Python 3.10+ (Windows users: run commands in PowerShell with `py` where available):

```bash
python3 -m pip install -r requirements.txt
python3 app.py init --username admin
python3 app.py run
```

Open `http://127.0.0.1:8000`. Choose the password yourself when `init` prompts. Data is saved in local `data/algo.sqlite3` until you deliberately delete it. Make private backups: `python3 app.py backup --out /safe/path/backup.sqlite3`. Keep this app on your own machine, not exposed publicly without security review.

### B. Render Free — internet-accessible *temporary demo*

`render.yaml` explicitly requests `plan: free` and **no persistent disk**. Render Free spins down after inactivity. Its filesystem is ephemeral, so all saved users, passwords, positions, trades and watchlist data may disappear following sleep/restarts/redeploys. **Do not use this as a reliable trade journal.** Each fresh database will recreate the bootstrap admin specified in Render's secret setting.

1. Create a **new, separate private GitHub repository** for these files. Do not modify the original day-trader-skill repo or your other trading repos. The optional script `publish_to_github.sh` requires `git` and an authenticated `gh` CLI.
2. In Render, go to **New > Blueprint**, select that private repo and `My Workspace`; the included `render.yaml` requests a Free Python web service in Singapore. Confirm the compute plan says **Free** and there is **no disk** or other paid add-on before clicking Deploy.
3. In the Blueprint flow, supply a unique 12+ character `ALGO_BOOTSTRAP_PASSWORD` as a private secret. Username is `admin`. Do **not** put the password into code, git, or chat.
4. After deployment, open `https://YOUR-SERVICE.onrender.com/health` and then the site root to sign in. A prominent banner warns about data loss. Use `bash verify_deployment.sh https://YOUR-SERVICE.onrender.com` if desired.
5. Market data is **off** by default for the free cloud demo. It can be enabled only after checking third-party terms and rate-limit behavior. No price feeds or market data will automatically place/fill a trade.

Check Render's latest Free limits and your billing settings. The Free service may be suspended for excessive usage; bandwidth/build overages may incur charges in workspaces with billing enabled. **This ZIP does not deploy or create a Render service on its own.**

## Safety and scope

- Fictional starting balance: $5,000 USD. No real balances or trades.
- Session authentication and CSRF checks, secure cookies in the cloud, no hardcoded login password.
- Risk controls are simulated and not exchange-grade. Planned stop prices do not guarantee any executed stop, and fills are entirely manual.
- Free local mode is **persistent** with SQLite on your local drive; Free Render online mode is **ephemeral**.
- Offline scanner replay requires a separate local `day-trader-skill` checkout referenced by `ALGO_SKILLS_PATH`; it is not wired to the Render demo.
- Backtest/research feed results are not trading advice.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

## Deployment distinction

The prior **paid v2** package has a Starter + 1 GB disk blueprint. This **free version replaces that blueprint** with `plan: free` and no disk. Do not use the old paid `render.yaml` if you want the Free option.
