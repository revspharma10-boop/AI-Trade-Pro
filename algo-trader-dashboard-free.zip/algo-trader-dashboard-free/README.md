# Algo Trader Dashboard v2 — Cloud-ready paper-trading lab

Standalone dashboard, separate from the public day-trader-skill repository. **Paper simulation only**. There is NO broker integration and no live order execution. Built for private use and demonstration, not production use without independent security assessment.

## What's added in v2

- Render deployment Blueprint (`render.yaml`) using a **paid starter web service** and persistent SQLite disk (`/var/data/algo.sqlite3`). The disk is essential: free Render web services erase SQLite on restarts/redeploys.
- Public-deploy fail-closed admin bootstrap. A 12+ character `ALGO_BOOTSTRAP_PASSWORD` is required on first start unless a user already exists. Existing passwords are never overwritten by a new environment value.
- HTTPS-only secure session cookies in Render, security headers, CSRF check for mutations, sign-in throttling, authenticated endpoints, and a `/health` probe.
- Optional **read-only historical daily close** feed from Stooq for up to ten watchlist US stock symbols. Each quote shows the actual bar date and time fetched. The feed is OFF by default locally, ON by default in the Render Blueprint, cached for 30 minutes per symbol, and may be delayed, denied or unavailable. Only a fixed HTTPS endpoint is contacted; redirects are blocked. Third-party terms/availability should be checked before depending on it.
- Quote data is stored in separate `market_quotes` tables. It **cannot automatically affect portfolio marks, buying/selling, risk checks, account equity, or P/L.** All fills remain entirely manual simulations.
- Back up SQLite consistently with `python app.py backup --out /safe/path/backup.sqlite3` (the backup contains confidential hashes, session records and trading data).
- 17 automated offline tests cover both v1 logic and new admin/bootstrap, persisted restart state, read-only feed isolation, fetch throttling, errors, and origin/CSRF restrictions.

## Local start (Python 3.10+)

```sh
python3 -m pip install -r requirements.txt
python3 app.py init --username admin
python3 app.py run
```

Open <http://127.0.0.1:8000>, then sign in with the password you chose. There are no preset credentials. For read-only historical daily closes, explicitly enable `ALGO_MARKET_DATA_ENABLED=1` before starting the app. The dashboard starts with $5,000 **fictitious** USD cash; it never sends orders to a broker.

Tests:

```sh
python3 -m unittest discover -s tests -v
```

## Render deployment (requires approval of charges + workspace selection)

1. Create a **new separate GitHub repository** for these files. The original day-trader-skill repository has strict tests requiring its exact top-level folder list and this dashboard must NOT be added to its root. `data/`, `.env`, and SQLite files are gitignored. Do not upload real credentials or the SQLite database.
2. Commit and push this folder as the root of the new repo.
3. In Render, choose **New > Blueprint**, connect the new GitHub repo containing `render.yaml`, select your approved workspace, and review costs. The Blueprint requests a paid Starter web service plus a 1-GB persistent disk. **Do not accept paid services unless you approve the recurring fees.**
4. Supply **`ALGO_BOOTSTRAP_PASSWORD`** as a private Render environment variable when prompted (minimum 12 characters; use a unique strong password). Username defaults to `admin`. No secrets are checked into `render.yaml`.
5. When deployment succeeds, visit `https://YOUR-SERVICE.onrender.com/health` and check that `ok` is true. Then visit the service root and sign in. This is an internet-exposed app; consider external authentication/IP restrictions if sharing it.
6. Add a watchlist ticker, refresh the optional dated daily feed, and verify that scenario equity does not change automatically. Make a tiny fictional trade, then redeploy/restart, sign in again, and check it persisted. The code's own persistence test simulates the same sequence with temporary SQLite.
7. Configure off-platform **encrypted database backups**. A backup on the same persistent disk is not a disaster-recovery copy. To use a custom domain, set `ALGO_PUBLIC_ORIGIN=https://your-domain.example` (no trailing slash) to enforce allowed mutation origins.

**Before any real-money application:** do a separate professional security review, implement user management/2FA, replace the informal EOD feed with licensed exchange-grade data, model execution costs/slippage, and require broker-specific approval and strict order permissions. None of those activities happen in v2.

### Local reproduction of a deployment-mode startup

```sh
export ALGO_DB_PATH="$PWD/data/algo.sqlite3"
export ALGO_REQUIRE_ADMIN=1
export ALGO_BOOTSTRAP_USERNAME=admin
# Set ALGO_BOOTSTRAP_PASSWORD safely in your own environment, not in code or chat.
export ALGO_MARKET_DATA_ENABLED=0
python3 -m uvicorn app:app --host 127.0.0.1 --port 8000
```

Public deployment adds `ALGO_SECURE_COOKIES=1` and a Render-provided hostname; if testing HTTPS locally with an HTTPS proxy, set the cookie option there too. Do not set `ALGO_SECURE_COOKIES=1` and expect normal login over plain HTTP.

### Security and accounting boundaries

- This prototype's password hashes are scrypt with a random salt; tokens live only as SHA-256 hashes in SQLite. A compromise of a deployed web service or disk can expose sensitive data. Change/remove the bootstrap secret in Render once the persistent admin account is confirmed, and keep backups private.
- Render's persistent disk cannot be used with free Render web services and costs money; pricing may change.
- The feed shows historical **daily close bars**, not guaranteed latest ticks. The data provider may rate-limit, block, change its format, or have licensing terms. A failed request displays an error; it does not provide invented prices. During packaging, external-provider connectivity could not be verified from the build environment; feed behavior was tested with mocked CSV responses.
- Trading risk caps assume a manually entered stop is filled at that price. There is no live stop execution, exchange-session rule engine, automatic liquidation, slippage, or transaction fee modeling. Daily caps still use UTC days.
- If you have the separate day-trader-skill checkout, set `ALGO_SKILLS_PATH` to enable the historical offline scanner replay; the Render Blueprint intentionally does not execute code from that other repo.

## Quick cloud handoff

For the approved `My Workspace` Render Blueprint with a Starter service and 1 GB persistent disk, see `CLOUD_STAGE_REPORT.md`. The connected Render API cannot attach disks or start Blueprints, so an API-only deployment was intentionally **not** attempted.

From a computer with GitHub CLI installed and authenticated, run `bash publish_to_github.sh` to create a separate **private** GitHub repo. Then use [Render Blueprints](https://dashboard.render.com/blueprints) to deploy `render.yaml`, supplying `ALGO_BOOTSTRAP_PASSWORD` privately when Render asks. No real trading orders are possible with this dashboard.

## Password management (v3)

- **Change password:** sign in, select **Account & password**, enter the existing password and a new one (12+ characters). All current sessions are revoked.
- **Forgot / reset password:** on the login screen choose **Forgot password?**, then enter your username, the administrator recovery key and your new password. Configure the 32+ character recovery secret with Render environment variable `ALGO_RECOVERY_KEY`; it must be kept private. There is **no automated email reset link** on the free demo. Invalid recovery attempts are limited.
- **Free Render limitation:** its disk is ephemeral. After the next restart the configured bootstrap password can be restored, even if the user changed it in the dashboard. For a persistent login password, change `ALGO_BOOTSTRAP_PASSWORD` in Render settings as well, or move to persistent database hosting. This is a temporary demonstration account, not production-grade persistent identity storage.


## Backup & restore (v4, free cloud continuity)

The left navigation now includes **Backup & restore**:

1. While signed in, select **Download backup (.json)**. Save the downloaded file on your own device. It includes all paper trades (open and closed), watchlist tickers, scenario marks, and reconciled cash. It intentionally excludes user passwords, password hashes, recovery keys, and sessions.
2. To recover after a Render free-server restart, sign in and use **Backup & restore → Recover paper records**. Select your prior JSON backup, read two confirmations, then restore. The app verifies the format, size (max 2 MB), checksum, trade integrity and account-cash reconciliation before transactionally replacing the current paper ledger.
3. **Restore replaces** the current simulated ledger, watchlist, marks and historical-quote cache. Download a fresh backup before a restore. Existing login and sessions are left unchanged.

Backups are **manual**, not automatically saved and not durable cloud storage. Records added after your last download cannot be recovered when Render erases its local SQLite database. A SHA-256 checksum detects accidental tampering but is **not a digital signature** and cannot establish that a backup came from a trusted party. Only import backups you created yourself. The JSON is readable and may reveal confidential watchlist and trading data; store it securely. This demo does not encrypt exported files.

The original 25 tests plus six backup/restore tests run with `python -m unittest discover -s tests -v`.
