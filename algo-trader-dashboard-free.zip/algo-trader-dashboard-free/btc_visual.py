"""Kraken BTC/USD visualization feeds. No brokerage access; do not infer total market buys from trades."""
from __future__ import annotations
from datetime import datetime, timezone
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.parse import urlsplit
import json
import math
import time

ALLOWED_TIMEFRAMES={5,15,60,240,1440}
HOST='api.kraken.com'
PAIR_KEYS={'XXBTZUSD','XBTUSD','BTC/USD'}
MAX_CANDLES_BYTES=700_000
MAX_TRADES_BYTES=1_500_000

class FeedUnavailable(Exception):
    pass
class _RejectRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise FeedUnavailable('Market feed redirected unexpectedly')

def _get_json(resource, max_bytes):
    if resource not in ('OHLC','Trades','Ticker'):
        raise FeedUnavailable('Unsupported market channel')
    # Whitelisted host, HTTPS, bounded response, no redirects. Never accept user URLs.
    url=f'https://{HOST}/0/public/{resource}?pair=XBTUSD'
    if resource=='OHLC':
        raise FeedUnavailable('OHLC needs timeframe')
    req=Request(url,headers={'Accept':'application/json','User-Agent':'AlgoTraderBitcoinVisual/1.0'})
    try:
        with build_opener(_RejectRedirect()).open(req,timeout=8) as response:
            p=urlsplit(response.geturl())
            if p.scheme!='https' or p.hostname!=HOST:raise FeedUnavailable('Unexpected exchange host')
            content=response.read(max_bytes+1)
        if len(content)>max_bytes:raise FeedUnavailable('Exchange response exceeds limit')
        return json.loads(content)
    except (OSError,TimeoutError,ValueError,UnicodeError) as e:
        raise FeedUnavailable('Kraken '+resource+' unavailable') from e

def _get_ohlc(timeframe):
    if type(timeframe) is not int or timeframe not in ALLOWED_TIMEFRAMES:
        raise FeedUnavailable('Unsupported BTC chart timeframe')
    url=f'https://{HOST}/0/public/OHLC?pair=XBTUSD&interval={timeframe}'
    req=Request(url,headers={'Accept':'application/json','User-Agent':'AlgoTraderBitcoinVisual/1.0'})
    try:
        with build_opener(_RejectRedirect()).open(req,timeout=8) as response:
            p=urlsplit(response.geturl())
            if p.scheme!='https' or p.hostname!=HOST:raise FeedUnavailable('Unexpected exchange host')
            content=response.read(MAX_CANDLES_BYTES+1)
        if len(content)>MAX_CANDLES_BYTES:raise FeedUnavailable('Exchange candle response too large')
        return json.loads(content)
    except (OSError,TimeoutError,ValueError,UnicodeError) as e:
        raise FeedUnavailable('Kraken candles unavailable') from e

def _entries(data):
    if not isinstance(data,dict) or data.get('error'):
        raise FeedUnavailable('Kraken returned a feed error')
    result=data.get('result')
    if not isinstance(result,dict):raise FeedUnavailable('Invalid Kraken result')
    keys=[k for k,v in result.items() if k!='last' and isinstance(v,list)]
    if len(keys)!=1 or keys[0] not in PAIR_KEYS:
        raise FeedUnavailable('Exchange response was not BTC/USD')
    return result[keys[0]]

def _number(value, *, positive=True, upper=1e9):
    if isinstance(value,bool):raise FeedUnavailable('Invalid market number')
    try:x=float(value)
    except (ValueError,TypeError):raise FeedUnavailable('Invalid market number')
    if not math.isfinite(x) or (positive and not 0<x<upper) or (not positive and not 0<=x<upper):
        raise FeedUnavailable('Invalid market number')
    return x

def parse_chart(data, timeframe, *, clock=None):
    if type(timeframe) is not int or timeframe not in ALLOWED_TIMEFRAMES:
        raise FeedUnavailable('Unsupported BTC chart timeframe')
    rows=_entries(data)
    if len(rows)<3:raise FeedUnavailable('Not enough completed BTC price candles')
    if len(rows)>720:rows=rows[-720:]
    bars=[]
    last_time=0
    # Last Kraken OHLC bar is currently forming, never label it completed.
    for row in rows[:-1]:
        if not isinstance(row,list) or len(row)<8:raise FeedUnavailable('Malformed BTC candle')
        t=int(_number(row[0],upper=100_000_000_000))
        if t<=last_time:raise FeedUnavailable('Out-of-order BTC candles')
        o,h,l,c=(_number(row[j]) for j in (1,2,3,4))
        vol=_number(row[6],positive=False)
        if h<max(o,c,l) or l>min(o,c,h):raise FeedUnavailable('Inconsistent BTC OHLC')
        bars.append({'time':t,'open':o,'high':h,'low':l,'close':c,'volume_btc':round(vol,8)})
        last_time=t
    # Chart latest 100 for legibility but source sample is honest.
    bars=bars[-100:]
    ts=int(time.time() if clock is None else clock)
    age=ts-(bars[-1]['time']+timeframe*60)
    if age < -(timeframe*60):raise FeedUnavailable('BTC candle timestamp is in future')
    stale=age>timeframe*60*2+120
    return {'source':'Kraken public BTC/USD OHLC','timeframe_minutes':timeframe,
            'bars':bars,'latest_completed_close':bars[-1]['close'],
            'completed_close_change_pct':round((bars[-1]['close']/bars[-2]['close']-1)*100,3),
            'last_complete_time':bars[-1]['time'], 'last_complete_age_seconds':max(0,age),
            'stale':stale,'note':'Only completed candles; the unfinished Kraken candle is excluded.'}

def parse_trades(data, *, clock=None):
    rows=_entries(data)
    if not rows:raise FeedUnavailable('No BTC trades in exchange sample')
    if len(rows)>1000:rows=rows[-1000:]
    trades=[]
    for row in rows:
        if not isinstance(row,list) or len(row)<5 or row[3] not in ('b','s'):
            raise FeedUnavailable('Invalid Kraken trade direction')
        price=_number(row[0]);quantity=_number(row[1]);stamp=_number(row[2],positive=False,upper=100_000_000_000)
        trades.append((price,quantity,stamp,row[3]))
    ts=float(time.time() if clock is None else clock)
    if any(x[2]>ts+120 for x in trades):raise FeedUnavailable('Future-dated BTC trade')
    buy=sum(q for p,q,t,side in trades if side=='b')
    sell=sum(q for p,q,t,side in trades if side=='s')
    total=buy+sell
    first=min(t for p,q,t,side in trades);last=max(t for p,q,t,side in trades)
    return {'source':'Kraken BTC/USD recent trades','sample_count':len(trades),
            'first_trade_time':first,'last_trade_time':last,'age_seconds':round(max(0,ts-last)),
            'sample_duration_seconds':round(last-first),
            'buy_taker_volume_btc':round(buy,8),'sell_taker_volume_btc':round(sell,8),
            'buy_pct':round(100*buy/total,2),'sell_pct':round(100*sell/total,2),
            'buy_sell_ratio':round(buy/sell,3) if sell else None,
            'trade_count_buy':sum(v[3]=='b' for v in trades),
            'trade_count_sell':sum(v[3]=='s' for v in trades),
            'note':'Sample of latest Kraken BTC/USD trades, grouped by taker side and weighted by BTC size. Every executed trade has both a buyer and seller. Not market-wide sentiment or order-book liquidity.'}

def parse_ticker(data):
    if not isinstance(data,dict) or data.get('error'):raise FeedUnavailable('Ticker exchange error')
    v=data.get('result')
    if not isinstance(v,dict):raise FeedUnavailable('Invalid ticker payload')
    keys=[x for x in v if x in PAIR_KEYS]
    if len(keys)!=1 or not isinstance(v[keys[0]],dict):raise FeedUnavailable('Unexpected ticker market')
    r=v[keys[0]]
    try:
        last=_number(r['c'][0]);open_= _number(r['o'])
        vol=_number(r['v'][-1],positive=False)
    except (KeyError,IndexError,TypeError) as exc:raise FeedUnavailable('Incomplete ticker') from exc
    return {'source':'Kraken BTC/USD public ticker','last_trade_price_usd':last,
            'daily_reference_open_usd':open_,'open_change_pct':round(100*(last/open_-1),3),
            'volume_24h_btc':round(vol,5),'note':'Last reported trade and exchange daily open are not predictive. Last trade timestamp is unavailable in Kraken ticker.'}

def market_snapshot(timeframe, *, timestamp=None):
    """Independent channels allow partial display; no fabricated or silent zero data."""
    now=int(time.time() if timestamp is None else timestamp)
    result={'symbol':'BTC/USD','venue':'Kraken','fetched_at_utc':datetime.fromtimestamp(now,timezone.utc).isoformat(),
            'channels':{},'errors':{},'paper_only':True}
    for name,getter,reader in (
        ('candles',lambda:_get_ohlc(timeframe),lambda d:parse_chart(d,timeframe,clock=now)),
        ('trades',lambda:_get_json('Trades',MAX_TRADES_BYTES),lambda d:parse_trades(d,clock=now)),
        ('ticker',lambda:_get_json('Ticker',50_000),parse_ticker)):
        try:result['channels'][name]=reader(getter())
        except (FeedUnavailable,ValueError,TypeError) as e:result['errors'][name]=str(e)
    result['has_data']=bool(result['channels'])
    return result
