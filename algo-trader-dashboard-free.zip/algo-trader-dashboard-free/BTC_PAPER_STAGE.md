# Algo Trader — BTC-only paper-ledger stage

BTC/USD spot **simulated** trades, not a real exchange account. Each BTC paper account begins with a separate $5,000 virtual balance; older stock-demo account, trades, PIN, and sessions are not migrated or overwritten. Always state this distinction.

## Implemented
- Eight-decimal BTC fractional quantities, long-only manually entered hypothetical entry/stop/target; independent BTC positions and cash persisted in Neon PostgreSQL (or local SQLite in test mode).
- Simulated 0.10% entry and exit fees counted in balance and net P/L; user-defined hypothetical prices only; stops/targets **do not automatically execute**.
- Limits: at most one open BTC position, 3 new entries per UTC day, $2,500 and 50% of equity notional caps, 10% equity cash buffer, max $50/1% of equity planned stop risk including estimated fees, $150/day combined realized losses plus open planned risk, minimum 1.5R target, $10 minimum notional. No real orders, leverage, API keys, wallets or bot jobs.
- User-controlled BTC scenario mark (not a live quote).
- Compare all six research strategies on the **same recent completed** BTC/USD candles with consistent 0.10% fee + 0.05% simulated slippage assumptions, historical return, drawdown, trade count, and win rate. Only one Kraken fetch per comparison, cooldown shared with individual strategy runs (60 sec).
- Authenticated endpoints with session cookie and CSRF safeguards; BTC paper data is intentionally separate from legacy stock ledger, and **not included in the legacy stock export/restore**.
- Default landing page is the BTC paper ledger. Existing legacy tabs retained to prevent losing or hiding old records. No continuous 24x7 worker on Render Free.

## Verification
Local Python test suite: **60 passing** (original 51 + 9 BTC fractional/fee/risk/persistence/security/comparison tests). Browser JS syntax: `node --check static/app.js` passes. Cloud Neon app startup and real-user testing are further acceptance gates; do not claim live execution.

## Important limitations
The trade ledger is **manual scenario trading**, not automated paper fills. Backtests are recent-window only, results are not a profitability guarantee. Live service may run intermittently on Render Free. Automated online backups, scheduled strategies, cloud-only legacy-to-BTC migrations, and risk monitoring remain future work. Neon Free does not have automatic scheduled snapshots.
