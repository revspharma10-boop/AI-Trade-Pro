"""Causally evaluated BTC/USD research predictions from verified Kraken candles.

The record stores the *last completed candle's* prediction, then later checks the
close 3 completed candles afterward. No live orders or simulated executions.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
import time
from btc_lab import TIMEFRAMES, validate_candles, DataUnavailable
from btc_signals import evaluate
from btc_planner import plan

SOURCE = "Kraken public BTC/USD OHLC"
HORIZON = 3
SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_market_candles (
    source TEXT NOT NULL, timeframe INTEGER NOT NULL, candle_time BIGINT NOT NULL,
    open_price REAL NOT NULL, high_price REAL NOT NULL,
    low_price REAL NOT NULL, close_price REAL NOT NULL,
    fetched_at TEXT NOT NULL, PRIMARY KEY(source,timeframe,candle_time));
CREATE TABLE IF NOT EXISTS btc_predictions (
    timeframe INTEGER NOT NULL, candle_time BIGINT NOT NULL,
    bias TEXT NOT NULL, bullish_count INTEGER NOT NULL,
    reference_close REAL NOT NULL, atr_14 REAL NOT NULL,
    volatility_low REAL NOT NULL, volatility_high REAL NOT NULL,
    entry_trigger REAL, stop_loss REAL, target_1 REAL, target_2 REAL,
    outcome_due_candle_time BIGINT NOT NULL,
    realized_close REAL, realized_move_pct REAL, bias_correct INTEGER,
    created_at TEXT NOT NULL,
    PRIMARY KEY(timeframe,candle_time));
"""
POSTGRES_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_market_candles (
    source TEXT NOT NULL, timeframe INTEGER NOT NULL, candle_time BIGINT NOT NULL,
    open_price NUMERIC(20,4) NOT NULL, high_price NUMERIC(20,4) NOT NULL,
    low_price NUMERIC(20,4) NOT NULL, close_price NUMERIC(20,4) NOT NULL,
    fetched_at TEXT NOT NULL, PRIMARY KEY(source,timeframe,candle_time));
CREATE TABLE IF NOT EXISTS btc_predictions (
    timeframe INTEGER NOT NULL, candle_time BIGINT NOT NULL,
    bias TEXT NOT NULL, bullish_count INTEGER NOT NULL,
    reference_close NUMERIC(20,4) NOT NULL, atr_14 NUMERIC(20,4) NOT NULL,
    volatility_low NUMERIC(20,4) NOT NULL, volatility_high NUMERIC(20,4) NOT NULL,
    entry_trigger NUMERIC(20,4), stop_loss NUMERIC(20,4),
    target_1 NUMERIC(20,4), target_2 NUMERIC(20,4),
    outcome_due_candle_time BIGINT NOT NULL,
    realized_close NUMERIC(20,4), realized_move_pct NUMERIC(20,4),
    bias_correct INTEGER, created_at TEXT NOT NULL,
    PRIMARY KEY(timeframe,candle_time));
"""


def _utc(t):
    return datetime.fromtimestamp(t, timezone.utc).isoformat(timespec="seconds")


def _pct(value):
    return round(float(value), 4)


def _atr(candles):
    trs = []
    for i in range(len(candles)-14, len(candles)):
        c, prior = candles[i], candles[i-1]
        trs.append(max(c['high']-c['low'], abs(c['high']-prior['close']), abs(c['low']-prior['close'])))
    return sum(trs) / 14


def calculate(candles, timeframe, account, *, timestamp=None):
    """Build one prediction with strictly causal finished bars."""
    candles = validate_candles(candles)
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable("Unsupported BTC timeframe")
    now = int(time.time() if timestamp is None else timestamp)
    signals = evaluate(candles, timeframe, timestamp=now)
    base = candles[-1]
    price = base['close']
    atr = _atr(candles)
    if not 0 < atr < price:
        raise DataUnavailable("Invalid BTC volatility")
    bullish = sum(x['signal'] in ('BUY','HOLD_LONG') for x in signals)
    bias = 'UP_BIAS' if bullish >= 4 else 'DOWN_BIAS' if bullish <= 2 else 'NO_EDGE'
    # A descriptive volatility scenario, deliberately NOT a statistically calibrated confidence interval.
    band = 1.25 * atr * math.sqrt(HORIZON)
    planner = plan(candles, timeframe, account, timestamp=now)
    candle_time = base['time']
    return {
        'pair': 'BTC/USD', 'source': SOURCE,
        'timeframe_minutes': timeframe, 'candle_time': candle_time,
        'candle_completed_utc': _utc(candle_time + timeframe*60),
        'prediction_horizon_candles': HORIZON,
        'prediction_due_utc': _utc(candle_time + (HORIZON+1)*timeframe*60),
        'reference_close_usd': round(price,4), 'atr_14_usd':round(atr,4),
        'volatility_low_usd': round(max(.0001, price-band),4),
        'volatility_high_usd': round(price+band,4),
        'bias': bias, 'bullish_strategies': bullish,
        'entry_state': planner['state'],
        'entry_trigger_usd': planner['entry_trigger_usd'],
        'stop_loss_usd': planner['stop_loss_usd'],
        'target_1_usd': planner['target_1_usd'],
        'target_2_usd': planner['target_2_usd'],
        'max_paper_btc_qty': planner['max_paper_btc_qty'],
        'created_at_utc': _utc(now),
        'realized_close_usd': None, 'realized_move_pct': None,
        'bias_correct': None, 'status':'PENDING',
        'paper_execution_enabled':False,'real_order_execution_enabled':False,
        'warning': 'Research-only directional bias and illustrative ATR band, NOT calibrated price or probability forecasts. A plan may say WAIT. Predictions require future completed bars before scoring; no trade is executed.'
    }


def persist_and_score(db, candles, prediction, *, timestamp=None):
    """Append-only source candles and one prediction per completed bar; score only matured prior calls."""
    candles = validate_candles(candles)
    tf = prediction['timeframe_minutes']
    latest = candles[-1]['time']
    if latest != prediction['candle_time'] or tf not in TIMEFRAMES:
        raise DataUnavailable('Mismatched BTC candles and prediction')
    now = int(time.time() if timestamp is None else timestamp)
    fetched = _utc(now)
    db.execute('BEGIN IMMEDIATE')
    try:
        for candle in candles[-120:]:
            db.execute('''INSERT INTO btc_market_candles
                (source,timeframe,candle_time,open_price,high_price,low_price,close_price,fetched_at)
                VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,timeframe,candle_time) DO NOTHING''',
                (SOURCE,tf,candle['time'],candle['open'],candle['high'],candle['low'],candle['close'],fetched))
        db.execute('''INSERT INTO btc_predictions
            (timeframe,candle_time,bias,bullish_count,reference_close,atr_14,
             volatility_low,volatility_high,entry_trigger,stop_loss,target_1,target_2,
             outcome_due_candle_time,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(timeframe,candle_time) DO NOTHING''',
            (tf,latest,prediction['bias'],prediction['bullish_strategies'],prediction['reference_close_usd'],
             prediction['atr_14_usd'],prediction['volatility_low_usd'],prediction['volatility_high_usd'],
             prediction['entry_trigger_usd'],prediction['stop_loss_usd'],prediction['target_1_usd'],
             prediction['target_2_usd'],latest+tf*HORIZON*60,fetched))
        by_stamp = {c['time']:c['close'] for c in candles}
        old = db.execute('''SELECT candle_time,outcome_due_candle_time,reference_close,bias
              FROM btc_predictions WHERE timeframe=? AND realized_close IS NULL
              AND outcome_due_candle_time<=? ORDER BY candle_time DESC LIMIT 150''',(tf,latest)).fetchall()
        for row in old:
            expected = int(row['outcome_due_candle_time'])
            if expected not in by_stamp:
                continue  # Data gaps cannot be invented or filled using latest price.
            close = by_stamp[expected]
            ref = float(row['reference_close'])
            pct = 100 * (close / ref - 1)
            bias = row['bias']
            correct = None if bias == 'NO_EDGE' or abs(close-ref)<.00000001 else int((pct>0) == (bias=='UP_BIAS'))
            db.execute('''UPDATE btc_predictions SET realized_close=?,realized_move_pct=?,bias_correct=?
                       WHERE timeframe=? AND candle_time=? AND realized_close IS NULL''',
                       (close,round(pct,4),correct,tf,row['candle_time']))
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK')
        raise
    return history(db,tf)


def history(db, timeframe=60):
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported BTC timeframe')
    rows = [dict(x) for x in db.execute('''SELECT timeframe,candle_time,bias,bullish_count,
            reference_close,atr_14,volatility_low,volatility_high,entry_trigger,
            stop_loss,target_1,target_2,outcome_due_candle_time,realized_close,
            realized_move_pct,bias_correct,created_at FROM btc_predictions
            WHERE timeframe=? ORDER BY candle_time DESC LIMIT 40''',(timeframe,)).fetchall()]
    for row in rows:
        for k in ('reference_close','atr_14','volatility_low','volatility_high','entry_trigger','stop_loss','target_1','target_2','realized_close','realized_move_pct'):
            if row[k] is not None: row[k] = float(row[k])
        row['status'] = 'SCORED' if row['realized_close'] is not None else 'PENDING'
        row['bias_correct'] = None if row['bias_correct'] is None else bool(row['bias_correct'])
        row['due_utc'] = _utc(int(row['outcome_due_candle_time']) + timeframe * 60)
    saved = db.execute('SELECT COUNT(*) FROM btc_market_candles WHERE timeframe=?',(timeframe,)).fetchone()[0]
    scored = [x for x in rows if x['status']=='SCORED' and x['bias_correct'] is not None]
    return {'pair':'BTC/USD','timeframe_minutes':timeframe,'source':SOURCE,'predictions':rows,
            'stored_completed_candles':int(saved), 'scored_directional_predictions':len(scored),
            'direction_accuracy_pct':round(100*sum(x['bias_correct'] for x in scored)/len(scored),2) if scored else None,
            'paper_execution_enabled':False,'real_order_execution_enabled':False,
            'notice':'Research-only. Accuracy excludes NO_EDGE and exactly-flat outcomes, and is based on at most 40 recent records, not a validated predictive probability.'}
