# BTC AI Brain v7 — four knowledge levels, paper research only

The browser-based expert rules engine covers **foundation**, **intermediate**, **advanced**, and **specialist** Bitcoin trading concepts. It does **not** use an LLM/model, is **not** a learned predictive model, and has **no calibrated win probability**.

## Sources actually integrated

- **Technical**: Kraken public BTC/USD completed OHLC (price candles). Six research strategy states, EMA 12/26 trend, RSI(14), ATR(14), breakout entry and paper-risk limits.
- **Network fundamentals**: the public Bitcoin fee estimates API from mempool.space. On-chain transaction fee rates are **not directional price signals**; availability is a source-completeness gate only. Data fetched on deliberate button presses, time/source/status shown.
- **Bitcoin fundamentals knowledge**: supply and halvings, trade execution costs, Bitcoin network congestion, macro & institutional context.
- **Not yet connected**: live interest rates, USD liquidity, ETF flows, derivatives funding, order book liquidity and verified news. The UI explicitly says NOT_CONNECTED, never invents figures.

## Outputs and controls

- Verified completed bar required. Stale, missing and invalid bars cause HTTP 503 and no report; no fallback to invented prices.
- Transparent verdict: WAIT, CONDITIONAL_BUY (a **future** breakout conditional on confirmed technical and paper risk), REVIEW_EXIT, or MANAGE_OPEN_POSITION. No actual BUY/SELL orders and no auto-paper execution.
- Source state, strategy agreement, ATR/RSI, entry/stop/two targets, size limits and reasons appear in the browser.
- A single report per timeframe+completed candle is saved on Neon in new `btc_brain_reports` table. Report reads are authenticated. New report generation requires login+CSRF and a durable 60-second throttle per timeframe.
- Original stock tables, PIN, cash balance and BTC paper positions are untouched by migration.
- Historical outcomes remain uncalibrated. Neither accurate forecasting nor 24/7 availability is claimed.

## Next gates

1. Confirm Kraken reliably yields enough completed candles; the previous preview returned HTTP 503 on insufficient rows. UI must fail closed if this persists.
2. Validate actual on-chain response schema and Render outbound connectivity; if unavailable, expected verdict is WAIT.
3. Add verified macro/ETF/news provider feeds separately, with explicit timestamps and missing-data states. No credentials committed to GitHub.
4. Establish a reliable free/paid external scheduling architecture before promising continuous 24/7 monitoring; Render Free spins down when idle. No real-money execution.

Sources: https://docs.kraken.com/api-reference/market-data/get-ohlc-data ; https://mempool.space/docs/api/rest ; https://render.com/docs/free
