# BTC-only conditional entry and exit planner (v4)

A **research and manual-paper-trading tool**, not a probabilistic price forecast, trading recommendation, AI oracle, or real exchange bot.

## New dashboard tab
- **BTC entry / exit plan** → choose 5m, 15m, 1h, 4h, 1d → Calculate entry/exit levels.
- Uses Kraken public BTC/USD spot OHLC, **only completed candles**; stale feed means no plan. Minimum 55 completed candles, maximum 719.
- All six existing research strategy positions are evaluated on the latest completed bar. Fewer than 4/6 positive positions means **WAIT**.
- A valid long-only setup requires a breakout trigger above the recent 4-bar high plus an ATR(14)-based increment. A stop is based on prior lows and 1.5x ATR; setups needing a stop wider than 8% of entry are refused.
- Profit targets are 2R and 3R hypothetical levels. These are *mathematical reward/risk scenarios*, not forecasts of where BTC will go.
- Max quantity is rounded to **eight BTC decimals** and restricted by the existing BTC paper-ledger budget: 1% / $50 stop risk after fees, $2,500 max notional, 50% equity concentration, 10% cash buffer, three entries a day and $150 daily loss/risk cap.
- Checks any existing BTC position and rejects new entries until it is closed. The preview account has a separate simulated $5,000 starting balance, never connected to a wallet.
- The optional “Fill BTC paper form with this scenario” copies numbers into inputs **without submitting**. User must inspect and separately manually confirm a simulated trade.
- Plan expires with the next candle; it is not an ongoing ticker, scheduled forecast, automatic stop, or notification.
- Market-provider calls are authenticated, CSRF-protected and durably rate-limited to 1 per 60 seconds per timeframe. No new migration tables, permissions or account changes.

## Reliability and limits
- 77 local unit/API tests pass, including preexisting login, PIN, Neon integration compatibility, old research, BTC ledger, signals, and nine new planner tests. `node --check static/app.js` passes.
- The plan uses a closed historical candle, not a live tradable bid/ask; overnight, fast-market gaps, slippage, fees, or feed delays can make actual paper prices different.
- Signal agreement is *not* a calibrated win probability. There is **no claimed predictive accuracy or future return** without forward-testing; any claim to 70% confidence is unsupported.
- Render Free may sleep; does not guarantee scanning 24 hours a day. No real exchange routes are connected.
- Future: paper-trade forward-validation, calibration by timeframe, and automated monitoring with proper hosting only after tests.

Source: https://docs.kraken.com/api-reference/market-data/get-ohlc-data
