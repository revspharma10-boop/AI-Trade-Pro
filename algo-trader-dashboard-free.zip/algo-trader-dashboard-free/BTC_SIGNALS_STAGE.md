# BTC-only signal monitor v3 — Paper-only candidate

This feature does not place trades, neither real nor simulated. It checks all six strategies against Kraken's recently **completed** BTC/USD spot candles. A decision is attributed only to the most recently finished bar. Incomplete and stale market data is rejected. The same strategy+timeframe+bar may be recorded at most once in the Postgres/SQLite audit table `btc_signal_checks`. An authenticated dashboard shows BUY, EXIT, HOLD_LONG and HOLD_FLAT observations and saved audit history.

- Authenticated `POST /api/btc/signals/check` with session, origin and CSRF validation. **Globally rate-limited to one fetch per interval per 60 seconds**.
- Authenticated `GET /api/btc/signals/history` displays the cloud audit log.
- Optional `POST /api/btc/signals/job` is configured for a **future** cloud scheduler. It returns HTTP 404 unless an administrator sets `ALGO_BTC_SCAN_JOB_ENABLED=1`, a distinct, strong private `ALGO_BTC_SCAN_JOB_KEY` of at least 32 characters in Render, and the app is connected to Neon PostgreSQL. Machine callers must supply the key in `X-BTC-Scan-Key`. This endpoint also **never executes** a trade. It is NOT enabled or scheduled in this release.
- Paper trades remain manually confirmed, with the previously enforced single-position, per-day, risk, daily-loss, fee and cash-buffer controls.
- Existing Neon login, PIN and BTC paper-trade accounts are preserved by additive schema migration.
- 68 local unit/API tests pass; static JS syntax passes. Production deployment and database checks are separate gates.

**Important operational limits:** Render Free services sleep after 15 minutes idle and cannot guarantee nonstop BTC monitoring, even with a third-party scheduler. No scheduler is configured for this preview. No real exchange credentials or orders. A historical candle decision is NOT a fill price or instruction to buy. Future stages: cloud scheduler, missed-candle monitoring/alerts, auto-paper safety approval and execution realism, independent cloud backup, production switch.

Free Render reference: https://render.com/docs/free
Kraken OHLC reference: https://docs.kraken.com/api-reference/market-data/get-ohlc-data
