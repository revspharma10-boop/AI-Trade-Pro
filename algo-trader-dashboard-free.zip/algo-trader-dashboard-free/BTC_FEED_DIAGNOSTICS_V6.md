# BTC feed diagnostic patch v6

This patch narrows the meaning of "Insufficient recent completed market candles". It does **not** imply a bearish forecast and does not manufacture missing candles.

- The public Kraken feed is expected to supply at least 56 rows (55 finished strategy warmup candles plus its unfinished latest candle). If it returns fewer, the API now gives the actual count and explains the safe retry.
- If Kraken returns more than 720 rows in the future, keep the most recent 720, discard the unfinished one, and validate the latest 719 completed rows.
- The monitor still rejects stale data and preserves its one-request-per-timeframe-per-minute quota.
- Signals and predictions remain paper-only and are never executed automatically.
- The patch does **not** fix genuine upstream feed shortages; do not claim the stream works until a successful live candle pull has been observed.
- Source database, PIN authentication and old paper ledger are unchanged.
