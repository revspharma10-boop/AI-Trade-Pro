# Algo Trader BTC AI Brain — top navigation layout (v8)

The former left-side workspace navigation is now a horizontal **top navigation** above the breadcrumb and analysis results. On desktop, tabs wrap across the top; on mobile, the menu scrolls sideways and the Sign out control remains accessible. The BTC AI Brain results and knowledge catalog remain below the top menu.

Scope: HTML semantics and CSS only; no changes to login/PIN, saved accounts, Neon tables, market feeds, BTC strategies, risk rules or automated execution. The existing live dashboard is not changed: this version is for the isolated Neon preview.

Testing: Python regression suite, Node JavaScript syntax, static DOM/CSS structure, and desktop/mobile browser screenshots.
