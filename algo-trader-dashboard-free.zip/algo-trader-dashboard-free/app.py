#!/usr/bin/env python3
"""Algo Trader Dashboard v2: authenticated, cloud-ready, paper-only ledger.

Optional delayed historical EOD research data; NEVER broker/order submission.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import getpass
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import subprocess
import sys
import time

from market_data import read_eod, DataUnavailable
from btc_lab import (PAIR as BTC_PAIR, TIMEFRAMES as BTC_TIMEFRAMES, STRATEGIES as BTC_STRATEGIES,
                     backtest as btc_backtest, fetch_recent_btc, DataUnavailable as BTCDataUnavailable)
from database import connect, init_schema as initialize_storage, storage_mode
import btc_paper
import btc_signals
import btc_planner
import btc_prediction
import btc_brain
import btc_visual
import btc_education

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, Field, field_validator

ROOT = Path(__file__).resolve().parent
DEFAULT_DB = ROOT / "data" / "algo.sqlite3"
SYMBOL = re.compile(r"^[A-Z]{1,5}(?:\.[A-Z])?$")
SESSION_SECONDS = 8 * 3600
BACKUP_FORMAT = "algo-trader-paper-ledger"
BACKUP_VERSION = 1
BACKUP_LIMIT_BYTES = 2_000_000
DEFAULT_LIMITS = {
    "starting_cash": 5000.0,
    "max_loss_per_trade": 50.0,
    "max_daily_loss": 150.0,
    "max_trades_per_day": 3,
    "max_position_pct": 75.0,
    "max_order_usd": 4000.0,
    "cash_buffer_pct": 10.0,
    "min_reward_risk": 1.0,
}


def now():
    return datetime.now(timezone.utc)


def stamp():
    return now().isoformat(timespec="seconds")


def cash_round(x: float) -> float:
    return round(x + 1e-10, 2)


def _hash_password(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)


def bootstrap_user(db_path: Path, username: str, password: str):
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", username):
        raise ValueError("Username must be 3-40 characters: letters, digits, underscore, dot, hyphen")
    if len(password) < 12:
        raise ValueError("Password must be at least 12 characters")
    salt = secrets.token_bytes(16)
    derived = _hash_password(password, salt)
    with connect(db_path) as db:
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            raise ValueError("An administrator already exists; credentials were not changed")
        db.execute("INSERT INTO users (username, salt, pw_hash) VALUES (?, ?, ?)",
                   (username, salt.hex(), derived.hex()))


def init_schema(path: Path):
    initialize_storage(path, """        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
            salt TEXT NOT NULL, pw_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL,
            csrf TEXT NOT NULL, expires_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS failed_logins (
            id INTEGER PRIMARY KEY, identity TEXT NOT NULL, attempted_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS account (
            id INTEGER PRIMARY KEY CHECK (id = 1), cash REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,
            qty INTEGER NOT NULL, entry_price REAL NOT NULL,
            stop_price REAL NOT NULL, target_price REAL NOT NULL,
            opened_at TEXT NOT NULL, status TEXT NOT NULL CHECK (status IN ('OPEN','CLOSED')),
            closed_at TEXT, exit_price REAL, pnl REAL);
        CREATE TABLE IF NOT EXISTS watchlist (
            symbol TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS marks (
            symbol TEXT PRIMARY KEY, price REAL NOT NULL, recorded_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS market_quotes (
            symbol TEXT PRIMARY KEY, price REAL NOT NULL, bar_date TEXT NOT NULL,
            provider TEXT NOT NULL, fetched_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS market_fetches (
            symbol TEXT PRIMARY KEY, attempted_at INTEGER NOT NULL);
        INSERT OR IGNORE INTO account (id, cash) VALUES (1, 5000.0);
""")
    with connect(path) as db:
        db.executescript(btc_paper.POSTGRES_SCHEMA if storage_mode() == "postgresql" else btc_paper.SQLITE_SCHEMA)
        db.executescript(btc_signals.POSTGRES_SCHEMA if storage_mode() == "postgresql" else btc_signals.SQLITE_SCHEMA)
        db.executescript(btc_prediction.POSTGRES_SCHEMA if storage_mode() == "postgresql" else btc_prediction.SQLITE_SCHEMA)
        db.executescript(btc_brain.POSTGRES_SCHEMA if storage_mode() == "postgresql" else btc_brain.SQLITE_SCHEMA)


class Login(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=512)


# PINs are enabled only for this PAPER-TRADING dashboard. A PIN has just 10,000
# possibilities, so persistent per-account guess throttling is mandatory.
COMMON_PINS = {"0000", "1111", "1234", "4321", "1212", "2222", "3333",
               "4444", "5555", "6666", "7777", "8888", "9999", "0123",
               "1230", "2580", "0001"}


def valid_new_secret(value: str) -> str:
    if re.fullmatch(r"[0-9]{4}", value):
        if value in COMMON_PINS:
            raise ValueError("Choose a less predictable 4-digit PIN")
        return value
    if len(value) >= 12:
        return value
    raise ValueError("Use exactly 4 numeric digits or a password of at least 12 characters")


class ChangePassword(BaseModel):
    current_password: str = Field(min_length=1, max_length=512)
    new_password: str = Field(min_length=4, max_length=512)

    @field_validator("new_password")
    @classmethod
    def check_secret(cls, value: str) -> str:
        return valid_new_secret(value)


class ResetPassword(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    recovery_key: str = Field(min_length=1, max_length=512)
    new_password: str = Field(min_length=4, max_length=512)

    @field_validator("new_password")
    @classmethod
    def check_secret(cls, value: str) -> str:
        return valid_new_secret(value)


class BTCResearchRequest(BaseModel):
    strategy: str = Field(min_length=1, max_length=30)
    timeframe: int = 60

    @field_validator("strategy")
    @classmethod
    def strategy_supported(cls, value):
        if value not in BTC_STRATEGIES:
            raise ValueError("Unknown BTC research strategy")
        return value

    @field_validator("timeframe")
    @classmethod
    def timeframe_supported(cls, value):
        if value not in BTC_TIMEFRAMES:
            raise ValueError("Unsupported BTC timeframe")
        return value


class BTCPaperOpen(BaseModel):
    qty: float
    entry_price: float
    stop_price: float
    target_price: float

class BTCPaperMark(BaseModel):
    price: float

class BTCCompareRequest(BaseModel):
    timeframe: int = 60

    @field_validator("timeframe")
    @classmethod
    def timeframe_supported(cls, value):
        if value not in BTC_TIMEFRAMES:
            raise ValueError("Unsupported BTC timeframe")
        return value


class SymbolInput(BaseModel):
    symbol: str = Field(min_length=1, max_length=16)


class MarkInput(SymbolInput):
    price: float


class OpenTrade(SymbolInput):
    qty: int
    entry_price: float
    stop_price: float
    target_price: float


class CloseTrade(BaseModel):
    exit_price: float


def clean_symbol(value: str) -> str:
    symbol = value.strip().upper()
    if not SYMBOL.fullmatch(symbol):
        raise HTTPException(status_code=422, detail="Use a simple US ticker such as AAPL or BRK.B")
    return symbol


def finite_positive(value, field: str):
    if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise HTTPException(status_code=422, detail=f"{field} must be finite and positive")
    if value > 1_000_000_000:
        raise HTTPException(status_code=422, detail=f"{field} is too large")
    return round(float(value), 4)


def portfolio(db):
    cash = float(db.execute("SELECT cash FROM account WHERE id=1").fetchone()[0])
    open_rows = db.execute("""
        SELECT t.*, m.price AS mark_price, m.recorded_at AS mark_time
        FROM trades t LEFT JOIN marks m ON t.symbol=m.symbol
        WHERE t.status='OPEN' ORDER BY t.opened_at DESC, t.id DESC""").fetchall()
    positions = []
    open_risk = 0.0
    for row in open_rows:
        r = dict(row)
        mark = float(r["mark_price"]) if r["mark_price"] is not None else float(r["entry_price"])
        r["mark_price"] = mark
        r["mark_source"] = "user scenario" if r["mark_time"] else "entry cost"
        r["market_value"] = cash_round(r["qty"] * mark)
        r["unrealized_pnl"] = cash_round(r["qty"] * (mark - r["entry_price"]))
        open_risk += r["qty"] * (r["entry_price"] - r["stop_price"])
        positions.append(r)
    equity = cash + sum(p["market_value"] for p in positions)
    today = now().date().isoformat()
    realized_today = float(db.execute("""
        SELECT COALESCE(SUM(pnl),0) FROM trades
        WHERE status='CLOSED' AND substr(closed_at,1,10)=?""", (today,)).fetchone()[0])
    loss_today = float(db.execute("""
        SELECT COALESCE(SUM(-pnl),0) FROM trades
        WHERE status='CLOSED' AND substr(closed_at,1,10)=? AND pnl < 0""", (today,)).fetchone()[0])
    entries_today = db.execute("SELECT COUNT(*) FROM trades WHERE substr(opened_at,1,10)=?", (today,)).fetchone()[0]
    closed = [dict(r) for r in db.execute("SELECT * FROM trades WHERE status='CLOSED' ORDER BY id DESC LIMIT 30").fetchall()]
    return {
        "cash": cash_round(cash), "equity": cash_round(equity),
        "positions": positions, "closed_trades": closed,
        "open_risk": cash_round(open_risk),
        "realized_today": cash_round(realized_today), "loss_today": cash_round(loss_today),
        "entries_today": entries_today,
        "watchlist": [r[0] for r in db.execute("SELECT symbol FROM watchlist ORDER BY symbol")],
        "marks": [dict(r) for r in db.execute("SELECT * FROM marks ORDER BY recorded_at DESC, symbol")],
        "limits": DEFAULT_LIMITS, "mode": "PAPER_SIMULATION",
        "price_notice": "All prices are manually entered scenarios, not live market quotes.",
        "date_basis": "UTC day; not exchange-session accounting",
    }



def backup_canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def export_ledger(db):
    """Export only fictitious trading records: NEVER account passwords or sessions."""
    core = {
        "format": BACKUP_FORMAT,
        "version": BACKUP_VERSION,
        "created_at": stamp(),
        "currency": "USD",
        "starting_cash": DEFAULT_LIMITS["starting_cash"],
        "account_cash": cash_round(db.execute("SELECT cash FROM account WHERE id=1").fetchone()[0]),
        "trades": [dict(r) for r in db.execute("SELECT * FROM trades ORDER BY id")],
        "watchlist": [r[0] for r in db.execute("SELECT symbol FROM watchlist ORDER BY symbol")],
        "marks": [dict(r) for r in db.execute("SELECT * FROM marks ORDER BY symbol")],
    }
    # SHA-256 is for accidental corruption detection, NOT proof of authenticity.
    return {**core, "sha256": hashlib.sha256(backup_canonical(core)).hexdigest()}


def invalid_backup(detail="Backup file is invalid or inconsistent"):
    raise HTTPException(status_code=422, detail=detail)


def valid_date(value):
    if not isinstance(value, str) or len(value) > 40:
        invalid_backup()
    try:
        ts = datetime.fromisoformat(value)
    except ValueError:
        invalid_backup()
    if ts.tzinfo is None or ts.utcoffset() is None:
        invalid_backup()
    return ts


def backup_positive(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        invalid_backup()
    if not math.isfinite(value) or not 0 < value <= 1_000_000_000:
        invalid_backup()
    return float(value)


def validate_backup(obj):
    if not isinstance(obj, dict) or set(obj) != {
        "format", "version", "created_at", "currency", "starting_cash", "account_cash",
        "trades", "watchlist", "marks", "sha256"
    }:
        invalid_backup()
    if obj["format"] != BACKUP_FORMAT or type(obj["version"]) is not int or obj["version"] != BACKUP_VERSION:
        invalid_backup("Unsupported backup format or version")
    if obj["currency"] != "USD":
        invalid_backup()
    valid_date(obj["created_at"])
    if not isinstance(obj["sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", obj["sha256"]):
        invalid_backup("Backup checksum missing")
    core = {k:v for k,v in obj.items() if k != "sha256"}
    try:
        digest = hashlib.sha256(backup_canonical(core)).hexdigest()
    except (TypeError, ValueError, OverflowError):
        invalid_backup()
    if not hmac.compare_digest(obj["sha256"], digest):
        invalid_backup("Backup checksum mismatch")
    if type(obj["starting_cash"]) not in (float, int) or obj["starting_cash"] != DEFAULT_LIMITS["starting_cash"]:
        invalid_backup("Starting balance differs from this demo")
    if type(obj["account_cash"]) not in (float, int) or not math.isfinite(obj["account_cash"]):
        invalid_backup()
    trades, watchlist, marks = obj["trades"], obj["watchlist"], obj["marks"]
    if not isinstance(trades, list) or len(trades) > 10000:
        invalid_backup("Too many trades in backup")
    if not isinstance(watchlist, list) or len(watchlist) > 1000:
        invalid_backup("Too many watchlist entries")
    if not isinstance(marks, list) or len(marks) > 1000:
        invalid_backup("Too many scenario marks")
    if len(watchlist) != len(set(str(x) for x in watchlist)):
        invalid_backup("Duplicate watchlist symbol")
    for symbol in watchlist:
        if not isinstance(symbol, str) or not SYMBOL.fullmatch(symbol):
            invalid_backup()
    ids, open_symbols = set(), set()
    cash = DEFAULT_LIMITS["starting_cash"]
    for t in trades:
        if not isinstance(t, dict) or set(t) != {
            "id", "symbol", "qty", "entry_price", "stop_price", "target_price",
            "opened_at", "status", "closed_at", "exit_price", "pnl"
        }:
            invalid_backup()
        if type(t["id"]) is not int or t["id"] < 1 or t["id"] in ids:
            invalid_backup("Invalid trade identifier")
        ids.add(t["id"])
        if not isinstance(t["symbol"], str) or not SYMBOL.fullmatch(t["symbol"]):
            invalid_backup()
        if type(t["qty"]) is not int or not 1 <= t["qty"] <= 100000:
            invalid_backup()
        entry = backup_positive(t["entry_price"])
        stop = backup_positive(t["stop_price"])
        target = backup_positive(t["target_price"])
        if not stop < entry < target:
            invalid_backup("Invalid entry, stop or target")
        opened = valid_date(t["opened_at"])
        if t["status"] == "OPEN":
            if t["closed_at"] is not None or t["exit_price"] is not None or t["pnl"] is not None:
                invalid_backup()
            if t["symbol"] in open_symbols:
                invalid_backup("Duplicate open position")
            open_symbols.add(t["symbol"])
        elif t["status"] == "CLOSED":
            if valid_date(t["closed_at"]) < opened:
                invalid_backup("Close time is before entry")
            exit_price = backup_positive(t["exit_price"])
            expected_pnl = cash_round(t["qty"] * (exit_price - entry))
            if type(t["pnl"]) not in (int, float) or not math.isfinite(t["pnl"]) or abs(t["pnl"] - expected_pnl) > 0.015:
                invalid_backup("Trade P/L does not reconcile")
            cash += cash_round(t["qty"] * exit_price)
        else:
            invalid_backup("Invalid trade status")
        cash -= cash_round(t["qty"] * entry)
    if not -1e-7 <= cash <= 1_000_000_000 or abs(cash_round(cash) - obj["account_cash"]) > 0.035:
        invalid_backup("Account cash does not reconcile with trade ledger")
    seen_marks = set()
    for m in marks:
        if not isinstance(m, dict) or set(m) != {"symbol", "price", "recorded_at"}:
            invalid_backup()
        sym = m["symbol"]
        if not isinstance(sym, str) or not SYMBOL.fullmatch(sym) or sym in seen_marks:
            invalid_backup()
        seen_marks.add(sym)
        backup_positive(m["price"])
        valid_date(m["recorded_at"])
    return trades, watchlist, marks

def ensure_production_admin(db_path: Path):
    """One-time environment bootstrap; existing login credentials never reset."""
    with connect(db_path) as db:
        has_admin = db.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0
    if has_admin:
        return
    password = os.getenv("ALGO_BOOTSTRAP_PASSWORD")
    if password:
        bootstrap_user(db_path, os.getenv("ALGO_BOOTSTRAP_USERNAME", "admin"), password)
    elif os.getenv("ALGO_REQUIRE_ADMIN", "0") == "1":
        raise RuntimeError("No administrator configured. Set ALGO_BOOTSTRAP_PASSWORD (12+ characters) or initialize locally.")


def expected_origin(request: Request) -> str:
    public = os.getenv("ALGO_PUBLIC_ORIGIN", "").rstrip("/")
    if public:
        return public
    host = os.getenv("RENDER_EXTERNAL_HOSTNAME", "")
    if host:
        return "https://" + host
    return f"{request.url.scheme}://{request.headers.get('host', '')}"


def create_app(db_path: str | Path | None = None) -> FastAPI:
    db_path = Path(db_path or os.getenv("ALGO_DB_PATH", str(DEFAULT_DB))).resolve()
    init_schema(db_path)
    ensure_production_admin(db_path)
    app = FastAPI(title="Algo Trader Paper Dashboard", docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        if os.getenv("ALGO_SECURE_COOKIES", "0") == "1":
            response.headers["Strict-Transport-Security"] = "max-age=31536000"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; form-action 'self'; "
            "frame-ancestors 'none'; base-uri 'none'")
        return response

    def current_session(request: Request):
        token = request.cookies.get("algo_session", "")
        if len(token) != 64:
            raise HTTPException(status_code=401, detail="Sign in required")
        key = hashlib.sha256(token.encode("utf-8")).hexdigest()
        with connect(db_path) as db:
            row = db.execute("""
                SELECT sessions.csrf, sessions.expires_at, users.username, users.id AS user_id
                FROM sessions JOIN users ON sessions.user_id=users.id
                WHERE sessions.token_hash=?""", (key,)).fetchone()
        if not row or row["expires_at"] < int(time.time()):
            raise HTTPException(status_code=401, detail="Session expired; sign in again")
        return dict(row)

    def signed_in(request: Request):
        return current_session(request)

    def mutation_auth(request: Request):
        session = current_session(request)
        supplied = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(supplied, session["csrf"]):
            raise HTTPException(status_code=403, detail="Invalid CSRF token")
        origin = request.headers.get("origin")
        if origin:
            expected = expected_origin(request)
            if origin != expected:
                raise HTTPException(status_code=403, detail="Origin mismatch")
        return session

    @app.get('/api/btc/education/library')
    def btc_education_library(session=Depends(signed_in)):
        return btc_education.knowledge_catalog()

    @app.get('/api/btc/visual')
    def btc_visual_snapshot(timeframe: int=60, session=Depends(signed_in)):
        if os.getenv('ALGO_BTC_RESEARCH_ENABLED','1')!='1':
            raise HTTPException(503,'BTC market data is disabled')
        if timeframe not in btc_visual.ALLOWED_TIMEFRAMES:
            raise HTTPException(422,'Unsupported BTC visual timeframe')
        now_ts=int(time.time());key=f'BTC_VISUAL_{timeframe}'
        # A shared, durable 60-second throttle to protect public exchange data.
        with connect(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                previous=db.execute('SELECT attempted_at FROM market_fetches WHERE symbol=?',(key,)).fetchone()
                if previous and now_ts-int(previous[0])<60:
                    db.execute('COMMIT')
                    raise HTTPException(429,'Wait 60 seconds before refreshing BTC visual data')
                db.execute('INSERT INTO market_fetches(symbol,attempted_at) VALUES(?,?) ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at',(key,now_ts))
                db.execute('COMMIT')
            except HTTPException:
                raise
            except BaseException:
                db.execute('ROLLBACK')
                raise
        snap=btc_visual.market_snapshot(timeframe,timestamp=now_ts)
        if not snap['has_data']:
            raise HTTPException(503,'BTC public data currently unavailable: '+ '; '.join(f'{k}: {v}' for k,v in snap['errors'].items()))
        return snap

    @app.get("/api/deployment")
    def deployment_mode():
        """Public non-sensitive hint for displaying the ephemeral-data warning."""
        return {"free_demo": os.getenv("ALGO_FREE_DEMO", "0") == "1", "paper_only": True,
                "storage": "remote_postgresql" if storage_mode() == "postgresql" else "local_sqlite",
                "durable_storage": storage_mode() == "postgresql"}

    @app.get("/health")
    def health():
        with connect(db_path) as db:
            db.execute("SELECT 1 FROM users LIMIT 1").fetchone()
        return {"ok": True, "service": "algo-trader-paper"}

    @app.get("/")
    def home():
        return FileResponse(ROOT / "static" / "index.html")

    @app.get("/static/{asset}")
    def static(asset: str):
        if asset not in {"app.js", "style.css"}:
            raise HTTPException(status_code=404)
        return FileResponse(ROOT / "static" / asset)

    @app.post("/api/auth/login")
    def login(payload: Login, request: Request):
        ip = request.client.host if request.client else "unknown"
        # Two independent buckets: per-account counters defeat rotating IPs;
        # per-IP counters limit distributed username probing. Store on Neon.
        account_key = "signin:user:" + payload.username.casefold()
        ip_key = "signin:ip:" + ip
        tick = int(time.time())
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM failed_logins WHERE attempted_at<?", (tick - 86400,))
            account_window = db.execute("SELECT COUNT(*) FROM failed_logins WHERE identity=? AND attempted_at>=?",
                                        (account_key, tick - 900)).fetchone()[0]
            account_day = db.execute("SELECT COUNT(*) FROM failed_logins WHERE identity=?",
                                     (account_key,)).fetchone()[0]
            ip_window = db.execute("SELECT COUNT(*) FROM failed_logins WHERE identity=? AND attempted_at>=?",
                                   (ip_key, tick - 900)).fetchone()[0]
            if account_window >= 3 or account_day >= 12 or ip_window >= 15:
                db.execute("COMMIT")
                raise HTTPException(status_code=429, detail="Too many attempts. Try later or use the recovery key")
            user = db.execute("SELECT * FROM users WHERE username=?", (payload.username,)).fetchone()
            dummy_salt = b"0123456789abcdef"
            salt = bytes.fromhex(user["salt"]) if user else dummy_salt
            computed = _hash_password(payload.password, salt)
            stored = bytes.fromhex(user["pw_hash"]) if user else b"\x00" * 32
            if not hmac.compare_digest(computed, stored):
                db.execute("INSERT INTO failed_logins(identity,attempted_at) VALUES (?,?),(?,?)",
                           (account_key, tick, ip_key, tick))
                db.execute("COMMIT")
                raise HTTPException(status_code=401, detail="Invalid username or PIN/password")
            db.execute("DELETE FROM failed_logins WHERE identity=?", (account_key,))
            token = secrets.token_hex(32)
            csrf = secrets.token_hex(32)
            db.execute("INSERT INTO sessions (token_hash,user_id,csrf,expires_at) VALUES (?,?,?,?)",
                       (hashlib.sha256(token.encode()).hexdigest(), user["id"], csrf, tick + SESSION_SECONDS))
            db.execute("COMMIT")
        response = JSONResponse({"username": user["username"], "csrf": csrf, "mode": "PAPER_SIMULATION"})
        response.set_cookie("algo_session", token, httponly=True, samesite="lax", secure=os.getenv("ALGO_SECURE_COOKIES", "0") == "1", max_age=SESSION_SECONDS, path="/")
        return response

    @app.get("/api/auth/me")
    def me(session=Depends(signed_in)):
        return {"username": session["username"], "csrf": session["csrf"], "mode": "PAPER_SIMULATION"}

    @app.post("/api/auth/logout")
    def logout(request: Request, session=Depends(mutation_auth)):
        token = request.cookies.get("algo_session", "")
        with connect(db_path) as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (hashlib.sha256(token.encode()).hexdigest(),))
        response = JSONResponse({"ok": True})
        response.delete_cookie("algo_session", path="/")
        return response

    def verify_password(password: str, row) -> bool:
        computed = _hash_password(password, bytes.fromhex(row["salt"]))
        return hmac.compare_digest(computed, bytes.fromhex(row["pw_hash"]))

    def rotate_password(db, user_id: int, new_password: str):
        salt = secrets.token_bytes(16)
        db.execute("UPDATE users SET salt=?, pw_hash=? WHERE id=?",
                   (salt.hex(), _hash_password(new_password, salt).hex(), user_id))
        db.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        db.execute("DELETE FROM failed_logins")

    @app.post("/api/auth/change-password")
    def change_password(payload: ChangePassword, session=Depends(mutation_auth)):
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
            if not user or not verify_password(payload.current_password, user):
                raise HTTPException(status_code=401, detail="Current password is incorrect")
            if hmac.compare_digest(payload.current_password, payload.new_password):
                raise HTTPException(status_code=422, detail="New password must be different")
            rotate_password(db, session["user_id"], payload.new_password)
            db.execute("COMMIT")
        response = JSONResponse({"ok": True, "message": "PIN/password changed. Please sign in again."})
        response.delete_cookie("algo_session", path="/")
        return response

    @app.post("/api/auth/reset-password")
    def reset_password(payload: ResetPassword, request: Request):
        origin = request.headers.get("origin")
        if origin and origin != expected_origin(request):
            raise HTTPException(status_code=403, detail="Origin mismatch")
        ip = request.client.host if request.client else "unknown"
        # Limit both IP-based and username-based guesses; include unknown usernames.
        ip_key = "reset:ip:" + ip
        user_key = "reset:user:" + payload.username.casefold()
        tick = int(time.time())
        recovery_key = os.getenv("ALGO_RECOVERY_KEY", "")
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM failed_logins WHERE attempted_at<?", (tick - 900,))
            attempts = db.execute("SELECT COUNT(*) FROM failed_logins WHERE identity IN (?,?)",
                                  (ip_key, user_key)).fetchone()[0]
            if attempts >= 10:  # 5 invalid requests (2 rows per request)
                raise HTTPException(status_code=429, detail="Too many recovery attempts. Try again later")
            user = db.execute("SELECT id FROM users WHERE username=?", (payload.username,)).fetchone()
            configured = len(recovery_key) >= 32
            # Perform a constant-time comparison even when the account or key is absent.
            supplied_hash = hashlib.sha256(payload.recovery_key.encode("utf-8")).digest()
            expected_hash = hashlib.sha256((recovery_key if configured else "invalid-recovery-key").encode("utf-8")).digest()
            valid = hmac.compare_digest(supplied_hash, expected_hash)
            if not (user and configured and valid):
                db.execute("INSERT INTO failed_logins(identity,attempted_at) VALUES (?,?),(?,?)",
                           (ip_key, tick, user_key, tick))
                db.execute("COMMIT")
                raise HTTPException(status_code=401, detail="Invalid username or recovery key")
            rotate_password(db, user["id"], payload.new_password)
            db.execute("COMMIT")
        response = JSONResponse({"ok": True, "message": "PIN/password reset. Sign in with your new PIN."})
        response.delete_cookie("algo_session", path="/")
        return response

    @app.get("/api/overview")
    def overview(session=Depends(signed_in)):
        with connect(db_path) as db:
            return portfolio(db)

    @app.get("/api/backup/export")
    def download_backup(session=Depends(signed_in)):
        with connect(db_path) as db:
            doc = export_ledger(db)
        payload = json.dumps(doc, indent=2, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(payload) > BACKUP_LIMIT_BYTES:
            raise HTTPException(status_code=413, detail="Backup exceeds the size limit")
        return Response(content=payload, media_type="application/json", headers={
            "Content-Disposition": f'attachment; filename="algo-trader-paper-{now().date().isoformat()}.json"',
            "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"
        })

    @app.post("/api/backup/restore")
    async def restore_backup(request: Request, session=Depends(mutation_auth)):
        if request.headers.get("x-restore-confirm") != "REPLACE":
            raise HTTPException(status_code=400, detail="Explicit restore confirmation missing")
        if request.headers.get("content-type", "").split(";")[0].strip().lower() != "application/json":
            raise HTTPException(status_code=415, detail="Upload a JSON backup file")
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > BACKUP_LIMIT_BYTES:
                raise HTTPException(status_code=413, detail="Backup is too large (2 MB limit)")
        try:
            doc = json.loads(bytes(body))
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError):
            invalid_backup("Invalid JSON backup")
        trades, watchlist, marks = validate_backup(doc)
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                # Replace paper data atomically. Never replace user credentials or sessions.
                for table in ("trades", "watchlist", "marks", "market_quotes", "market_fetches"):
                    db.execute("DELETE FROM " + table)
                for t in trades:
                    db.execute("""INSERT INTO trades
                        (id,symbol,qty,entry_price,stop_price,target_price,opened_at,status,closed_at,exit_price,pnl)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                        tuple(t[key] for key in ("id","symbol","qty","entry_price","stop_price","target_price",
                            "opened_at","status","closed_at","exit_price","pnl")))
                for symbol in watchlist:
                    db.execute("INSERT INTO watchlist(symbol) VALUES (?)", (symbol,))
                for m in marks:
                    db.execute("INSERT INTO marks(symbol,price,recorded_at) VALUES (?,?,?)",
                               (m["symbol"],m["price"],m["recorded_at"]))
                # Ensure subsequent inserts receive IDs above restored explicit trade IDs.
                if storage_mode() == "postgresql":
                    db.execute("SELECT setval(pg_get_serial_sequence('trades','id'), "
                               "COALESCE((SELECT MAX(id) FROM trades), 1), "
                               "EXISTS(SELECT 1 FROM trades))")
                db.execute("UPDATE account SET cash=? WHERE id=1", (cash_round(doc["account_cash"]),))
                db.execute("COMMIT")
            except Exception:
                db.execute("ROLLBACK")
                raise
        return {"ok": True, "simulated": True, "trades": len(trades), "watchlist": len(watchlist),
                "marks": len(marks), "notice": "Paper records restored; login credentials unchanged."}

    @app.post("/api/watchlist")
    def add_watch(payload: SymbolInput, session=Depends(mutation_auth)):
        symbol = clean_symbol(payload.symbol)
        with connect(db_path) as db:
            db.execute("INSERT OR IGNORE INTO watchlist(symbol) VALUES (?)", (symbol,))
        return {"ok": True, "symbol": symbol}

    @app.delete("/api/watchlist/{ticker}")
    def delete_watch(ticker: str, session=Depends(mutation_auth)):
        symbol = clean_symbol(ticker)
        with connect(db_path) as db:
            db.execute("DELETE FROM watchlist WHERE symbol=?", (symbol,))
        return {"ok": True}

    @app.post("/api/marks")
    def update_mark(payload: MarkInput, session=Depends(mutation_auth)):
        symbol = clean_symbol(payload.symbol)
        price = finite_positive(payload.price, "Scenario price")
        with connect(db_path) as db:
            db.execute("INSERT INTO marks(symbol, price, recorded_at) VALUES (?,?,?) "
                       "ON CONFLICT(symbol) DO UPDATE SET price=excluded.price, recorded_at=excluded.recorded_at",
                       (symbol, price, stamp()))
        return {"ok": True, "symbol": symbol, "price": price}

    @app.post("/api/trades/open")
    def open_trade(payload: OpenTrade, session=Depends(mutation_auth)):
        sym = clean_symbol(payload.symbol)
        qty = payload.qty
        if qty < 1 or qty > 100000:
            raise HTTPException(status_code=422, detail="Quantity must be 1–100,000 whole shares")
        entry = finite_positive(payload.entry_price, "Entry")
        stop = finite_positive(payload.stop_price, "Stop")
        target = finite_positive(payload.target_price, "Target")
        if not (stop < entry < target):
            raise HTTPException(status_code=422, detail="Long only: stop < entry < target")
        risk = cash_round((entry - stop) * qty)
        notional = cash_round(entry * qty)
        if risk <= 0:
            raise HTTPException(status_code=422, detail="Stop distance must be nonzero")
        rr = (target - entry) / (entry - stop)
        if rr + 1e-8 < DEFAULT_LIMITS["min_reward_risk"]:
            raise HTTPException(status_code=422, detail="Reward/risk must be at least 1.0")
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            data = portfolio(db)
            errors = []
            if any(p["symbol"] == sym for p in data["positions"]):
                errors.append("An open position in this ticker already exists")
            if data["entries_today"] >= DEFAULT_LIMITS["max_trades_per_day"]:
                errors.append("Daily entry limit reached (UTC day)")
            if notional > DEFAULT_LIMITS["max_order_usd"] + 1e-8:
                errors.append("Order exceeds the $4,000 paper limit")
            if notional > data["equity"] * DEFAULT_LIMITS["max_position_pct"] / 100 + 1e-8:
                errors.append("Position exceeds 75% of scenario equity")
            if risk > min(DEFAULT_LIMITS["max_loss_per_trade"], data["equity"] * 0.01) + 1e-8:
                errors.append("Risk exceeds $50 or 1% of scenario equity")
            if data["loss_today"] + data["open_risk"] + risk > DEFAULT_LIMITS["max_daily_loss"] + 1e-8:
                errors.append("Realized losses plus planned open risk exceed $150 daily cap")
            if data["cash"] - notional < max(0, data["equity"] * DEFAULT_LIMITS["cash_buffer_pct"] / 100) - 1e-8:
                errors.append("Insufficient paper cash after 10% equity buffer")
            if errors:
                db.execute("ROLLBACK")
                raise HTTPException(status_code=422, detail="; ".join(errors))
            cursor = db.execute("""INSERT INTO trades
                (symbol,qty,entry_price,stop_price,target_price,opened_at,status)
                VALUES (?,?,?,?,?,?,'OPEN')""", (sym, qty, entry, stop, target, stamp()))
            db.execute("UPDATE account SET cash=? WHERE id=1", (cash_round(data["cash"]-notional),))
            db.execute("INSERT OR IGNORE INTO watchlist(symbol) VALUES (?)", (sym,))
            db.execute("COMMIT")
        return {"ok": True, "trade_id": cursor.lastrowid, "simulated": True, "risk": risk, "notional": notional}

    @app.post("/api/trades/{trade_id}/close")
    def close_trade(trade_id: int, payload: CloseTrade, session=Depends(mutation_auth)):
        price = finite_positive(payload.exit_price, "Exit")
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            trade = db.execute("SELECT * FROM trades WHERE id=? AND status='OPEN'", (trade_id,)).fetchone()
            if not trade:
                db.execute("ROLLBACK")
                raise HTTPException(status_code=404, detail="Open trade not found")
            proceeds = cash_round(trade["qty"] * price)
            pnl = cash_round(trade["qty"] * (price - trade["entry_price"]))
            db.execute("UPDATE trades SET status='CLOSED',exit_price=?,closed_at=?,pnl=? WHERE id=?",
                       (price, stamp(), pnl, trade_id))
            db.execute("UPDATE account SET cash=cash+? WHERE id=1", (proceeds,))
            db.execute("COMMIT")
        return {"ok": True, "simulated": True, "pnl": pnl}

    @app.get("/api/btc/paper/portfolio")
    def btc_paper_portfolio(session=Depends(signed_in)):
        with connect(db_path) as db:
            return btc_paper.portfolio(db)

    @app.post("/api/btc/paper/open")
    def btc_paper_open(payload: BTCPaperOpen, session=Depends(mutation_auth)):
        try:
            with connect(db_path) as db:
                return btc_paper.open_trade(db,payload)
        except btc_paper.PaperRuleError as exc:
            raise HTTPException(422,str(exc)) from exc

    @app.post("/api/btc/paper/{trade_id}/close")
    def btc_paper_close(trade_id: int, payload: CloseTrade, session=Depends(mutation_auth)):
        try:
            with connect(db_path) as db:
                return btc_paper.close_trade(db,trade_id,payload.exit_price)
        except btc_paper.PaperRuleError as exc:
            raise HTTPException(422,str(exc)) from exc

    @app.post("/api/btc/paper/mark")
    def btc_paper_mark(payload: BTCPaperMark, session=Depends(mutation_auth)):
        try:
            with connect(db_path) as db:
                return btc_paper.mark_trade(db,payload.price)
        except btc_paper.PaperRuleError as exc:
            raise HTTPException(422,str(exc)) from exc

    def _btc_signal_scan(timeframe):
        if os.getenv("ALGO_BTC_RESEARCH_ENABLED", "1") != "1":
            raise HTTPException(503, "BTC candle feed disabled")
        if timeframe not in BTC_TIMEFRAMES:
            raise HTTPException(422, "Unsupported timeframe")
        tick = int(time.time())
        key = f"BTC_SIGNAL_SCAN_{timeframe}"
        # Apply a durable, account-wide throttle even when a provider call fails.
        with connect(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                prior = db.execute('SELECT attempted_at FROM market_fetches WHERE symbol=?',(key,)).fetchone()
                if prior and tick-int(prior[0]) < 60:
                    db.execute('COMMIT')
                    raise HTTPException(429, "Wait 60 seconds between BTC signal checks")
                db.execute('INSERT INTO market_fetches(symbol,attempted_at) VALUES(?,?) '
                           'ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at',(key,tick))
                db.execute('COMMIT')
            except HTTPException:
                raise
            except BaseException:
                db.execute('ROLLBACK')
                raise
        try:
            candles = fetch_recent_btc(timeframe)
            with connect(db_path) as db:
                return btc_signals.record(db, candles, timeframe, timestamp=int(time.time()))
        except BTCDataUnavailable as exc:
            raise HTTPException(503,str(exc)) from exc

    @app.post('/api/btc/plan')
    def btc_entry_exit_plan(payload: BTCCompareRequest, session=Depends(mutation_auth)):
        if os.getenv('ALGO_BTC_RESEARCH_ENABLED','1') != '1':
            raise HTTPException(503,'BTC candle feed disabled')
        tick=int(time.time())
        # Durable shared one-minute quota; do not spam public Kraken.
        key=f'BTC_ENTRY_PLAN_{payload.timeframe}'
        with connect(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                row=db.execute('SELECT attempted_at FROM market_fetches WHERE symbol=?',(key,)).fetchone()
                if row and tick-int(row[0])<60:
                    db.execute('COMMIT')
                    raise HTTPException(429,'Wait 60 seconds between BTC planning requests')
                db.execute('INSERT INTO market_fetches(symbol,attempted_at) VALUES(?,?) '
                           'ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at',(key,tick))
                db.execute('COMMIT')
            except HTTPException:
                raise
            except BaseException:
                db.execute('ROLLBACK')
                raise
        try:
            candles=fetch_recent_btc(payload.timeframe)
            with connect(db_path) as db:
                account=btc_paper.portfolio(db)
            return btc_planner.plan(candles,payload.timeframe,account,timestamp=int(time.time()))
        except BTCDataUnavailable as exc:
            raise HTTPException(503,str(exc)) from exc

    @app.get('/api/btc/brain/knowledge')
    def btc_brain_knowledge(session=Depends(signed_in)):
        return {'engine_kind':'EXPLAINABLE_RULE_ENGINE','llm_connected':False,
                'knowledge':list(btc_brain.KNOWLEDGE),'strategy_catalog_size':len(btc_education.knowledge_catalog()['strategies']), 'active_backtested_strategies':len(BTC_STRATEGIES),'sources':{
                    'technical':'Kraken completed BTC/USD spot OHLC',
                    'network_fees':'mempool.space public Bitcoin fee recommendations'},
                'missing_sources':['macro','BTC ETF flows','derivatives funding','verified BTC news'],
                'paper_only':True}

    @app.get('/api/btc/brain/history')
    def btc_brain_history(timeframe: int=60, session=Depends(signed_in)):
        try:
            with connect(db_path) as db:
                return btc_brain.history(db,timeframe)
        except BTCDataUnavailable as exc:
            raise HTTPException(422,str(exc)) from exc

    @app.post('/api/btc/brain/analyze')
    def btc_brain_analyze(payload: BTCCompareRequest, session=Depends(mutation_auth)):
        if os.getenv('ALGO_BTC_RESEARCH_ENABLED','1')!='1':
            raise HTTPException(503,'BTC data feed is disabled')
        if payload.timeframe not in BTC_TIMEFRAMES:
            raise HTTPException(422,'Unsupported BTC timeframe')
        tick=int(time.time())
        key=f'BTC_BRAIN_ANALYSIS_{payload.timeframe}'
        # Persist a per-timeframe throttle before external calls; failure still counts.
        with connect(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                old=db.execute('SELECT attempted_at FROM market_fetches WHERE symbol=?',(key,)).fetchone()
                if old and tick-int(old[0])<60:
                    db.execute('COMMIT')
                    raise HTTPException(429,'Wait 60 seconds before refreshing the BTC AI Brain')
                db.execute('INSERT INTO market_fetches(symbol,attempted_at) VALUES(?,?) '
                           'ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at',(key,tick))
                db.execute('COMMIT')
            except HTTPException:raise
            except BaseException:
                db.execute('ROLLBACK');raise
        try:
            candles=fetch_recent_btc(payload.timeframe)
            onchain=btc_brain.fetch_onchain()
            with connect(db_path) as db:
                account=btc_paper.portfolio(db)
                report=btc_brain.analyze(candles,payload.timeframe,account,onchain=onchain,timestamp=int(time.time()))
                btc_brain.record(db,report)
            return report
        except BTCDataUnavailable as exc:
            raise HTTPException(503,str(exc)) from exc

    @app.post('/api/btc/predictions/pull')
    def btc_prediction_pull(payload: BTCCompareRequest, session=Depends(mutation_auth)):
        # A human initiates a fetch. No auto trader or background worker is installed.
        if os.getenv('ALGO_BTC_RESEARCH_ENABLED','1') != '1':
            raise HTTPException(503,'BTC candle feed disabled')
        tick=int(time.time())
        key=f'BTC_PREDICTION_PULL_{payload.timeframe}'
        with connect(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                previous=db.execute('SELECT attempted_at FROM market_fetches WHERE symbol=?',(key,)).fetchone()
                if previous and tick-int(previous[0]) < 60:
                    db.execute('COMMIT')
                    raise HTTPException(429,'Wait 60 seconds between BTC data-pull requests')
                db.execute('INSERT INTO market_fetches(symbol,attempted_at) VALUES(?,?) '
                           'ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at',(key,tick))
                db.execute('COMMIT')
            except HTTPException:
                raise
            except BaseException:
                db.execute('ROLLBACK')
                raise
        try:
            candles=fetch_recent_btc(payload.timeframe)
            with connect(db_path) as db:
                account=btc_paper.portfolio(db)
                result=btc_prediction.calculate(candles,payload.timeframe,account,timestamp=int(time.time()))
                data=btc_prediction.persist_and_score(db,candles,result,timestamp=int(time.time()))
            result['stored_completed_candles']=data['stored_completed_candles']
            result['newest_prediction_scored']=bool(data['predictions'] and data['predictions'][0]['status']=='SCORED')
            return result
        except BTCDataUnavailable as exc:
            raise HTTPException(503,str(exc)) from exc

    @app.get('/api/btc/predictions/history')
    def btc_prediction_history(timeframe: int=60, session=Depends(signed_in)):
        try:
            with connect(db_path) as db:
                return btc_prediction.history(db,timeframe)
        except BTCDataUnavailable as exc:
            raise HTTPException(422,str(exc)) from exc

    @app.get('/api/btc/signals/history')
    def btc_signal_history(timeframe: int = 60, session=Depends(signed_in)):
        try:
            with connect(db_path) as db:
                return btc_signals.history(db, timeframe)
        except BTCDataUnavailable as exc:
            raise HTTPException(422,str(exc)) from exc

    @app.post('/api/btc/signals/check')
    def btc_signal_manual(payload: BTCCompareRequest, session=Depends(mutation_auth)):
        return _btc_signal_scan(payload.timeframe)

    @app.post('/api/btc/signals/job')
    def btc_signal_job(request: Request):
        # Scheduler-ready but intentionally disabled unless host explicitly opts in.
        # Never accept cookies or a 4-digit PIN as machine credentials.
        secret = os.environ.get('ALGO_BTC_SCAN_JOB_KEY','')
        if (os.environ.get('ALGO_BTC_SCAN_JOB_ENABLED') != '1' or len(secret)<32
            or storage_mode() != 'postgresql'):
            raise HTTPException(404,'Scheduled signal checks are disabled')
        provided = request.headers.get('X-BTC-Scan-Key','')
        if not hmac.compare_digest(secret,provided):
            raise HTTPException(401,'Scheduler authentication required')
        timeframe = int(os.environ.get('ALGO_BTC_SCAN_TIMEFRAME','60'))
        if timeframe not in BTC_TIMEFRAMES:
            raise HTTPException(503,'Invalid scheduled BTC timeframe')
        return _btc_signal_scan(timeframe)

    @app.post("/api/btc/strategies/compare")
    def btc_compare(payload: BTCCompareRequest, session=Depends(mutation_auth)):
        if os.getenv("ALGO_BTC_RESEARCH_ENABLED", "1") != "1":
            raise HTTPException(503,"BTC research feed is disabled")
        tick = int(time.time())
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT attempted_at FROM market_fetches WHERE symbol=?",("BTC_LAB_RESEARCH",)).fetchone()
            if row and tick - row[0] < 60:
                db.execute("COMMIT")
                raise HTTPException(429,"Wait 60 seconds between BTC research requests")
            db.execute("INSERT INTO market_fetches(symbol,attempted_at) VALUES (?,?) "
                       "ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at",("BTC_LAB_RESEARCH",tick))
            db.execute("COMMIT")
        try:
            candles=fetch_recent_btc(payload.timeframe)
            reports=[btc_backtest(candles,key) for key in BTC_STRATEGIES]
        except BTCDataUnavailable as exc:
            raise HTTPException(503,str(exc)) from exc
        return {"pair":BTC_PAIR,"timeframe_minutes":payload.timeframe,
                "candles":len(candles),"from_utc":reports[0]["from_utc"],
                "through_utc":reports[0]["through_utc"],
                "execution_enabled":False,"provider":"Kraken public spot OHLC",
                "comparison": [{k:v for k,v in report.items() if k != "equity_curve"} for report in reports],
                "notice":"Same historical window, costs, and assumptions across all strategies; selection bias applies."}

    @app.get("/api/btc/strategies")
    def btc_catalog(session=Depends(signed_in)):
        return {"pair": BTC_PAIR, "timeframes": BTC_TIMEFRAMES,
                "strategies": [{"id": k, "name": n, "description": d}
                               for k, (n, d) in BTC_STRATEGIES.items()],
                "mode": "HISTORICAL_RESEARCH_ONLY", "execution_enabled": False}

    @app.post("/api/btc/strategies/run")
    def btc_research(payload: BTCResearchRequest, session=Depends(mutation_auth)):
        if os.getenv("ALGO_BTC_RESEARCH_ENABLED", "1") != "1":
            raise HTTPException(503, "BTC research feed is disabled")
        tick = int(time.time())
        # Globally rate-limited manual historical research, never a background bot.
        with connect(db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            key = "BTC_LAB_RESEARCH"
            row = db.execute("SELECT attempted_at FROM market_fetches WHERE symbol=?", (key,)).fetchone()
            if row and tick - row[0] < 60:
                db.execute("COMMIT")
                raise HTTPException(429, "Wait 60 seconds between BTC research requests")
            db.execute("INSERT INTO market_fetches(symbol,attempted_at) VALUES (?,?) "
                       "ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at", (key, tick))
            db.execute("COMMIT")
        try:
            candles = fetch_recent_btc(payload.timeframe)
            report = btc_backtest(candles, payload.strategy)
        except BTCDataUnavailable as e:
            raise HTTPException(503, str(e)) from e
        report.update({"timeframe_minutes": payload.timeframe,
                       "provider": "Kraken public spot OHLC", "feed_type": "COMPLETED_HISTORICAL_CANDLES",
                       "execution_enabled": False})
        return report

    @app.get("/api/market/status")
    def market_status(session=Depends(signed_in)):
        enabled = os.getenv("ALGO_MARKET_DATA_ENABLED", "0") == "1"
        with connect(db_path) as db:
            quotes = [dict(r) for r in db.execute("""SELECT symbol, price, bar_date,
                provider, fetched_at FROM market_quotes ORDER BY symbol""").fetchall()]
        return {"enabled": enabled, "provider": "Stooq", "quotes": quotes,
                "classification": "DELAYED_HISTORICAL_DAILY_BARS",
                "notice": "Fetched daily closes are historical research data, not realtime quotes. "
                          "They do not update scenario P/L or trigger trades. Verify independently."}

    @app.post("/api/market/refresh")
    def market_refresh(session=Depends(mutation_auth)):
        if os.getenv("ALGO_MARKET_DATA_ENABLED", "0") != "1":
            raise HTTPException(status_code=503, detail="Optional research feed is disabled")
        now_tick = int(time.time())
        with connect(db_path) as db:
            symbols = [r[0] for r in db.execute(
                "SELECT symbol FROM watchlist ORDER BY symbol LIMIT 10").fetchall()]
        if not symbols:
            return {"updated": [], "cached": [], "errors": [], "notice": "Add a watchlist symbol first."}
        updated, cached, errors = [], [], []
        for symbol in symbols:
            with connect(db_path) as db:
                db.execute("BEGIN IMMEDIATE")
                last = db.execute("SELECT attempted_at FROM market_fetches WHERE symbol=?", (symbol,)).fetchone()
                if last and now_tick - last[0] < 30 * 60:
                    cached.append(symbol)
                    db.execute("COMMIT")
                    continue
                db.execute("INSERT INTO market_fetches(symbol,attempted_at) VALUES (?,?) "
                           "ON CONFLICT(symbol) DO UPDATE SET attempted_at=excluded.attempted_at",
                           (symbol, now_tick))
                db.execute("COMMIT")
            try:
                data = read_eod(symbol)
            except DataUnavailable as ex:
                errors.append({"symbol": symbol, "reason": str(ex)})
                continue
            with connect(db_path) as db:
                db.execute("INSERT INTO market_quotes(symbol,price,bar_date,provider,fetched_at) "
                           "VALUES (?,?,?,?,?) ON CONFLICT(symbol) DO UPDATE SET "
                           "price=excluded.price,bar_date=excluded.bar_date,"
                           "provider=excluded.provider,fetched_at=excluded.fetched_at",
                           (symbol, data["close"], data["bar_date"], data["provider"], now_tick))
            updated.append(symbol)
        return {"updated": updated, "cached": cached, "errors": errors,
                "notice": "Read-only historical daily bars. Never used for execution or simulation fills."}

    @app.get("/api/scanner/status")
    def scanner_status(session=Depends(signed_in)):
        skills = os.getenv("ALGO_SKILLS_PATH", "")
        repo = Path(skills).expanduser().resolve() if skills else None
        ready = bool(repo and (repo / "trader-scanner" / "scan.py").is_file()
                     and (repo / "tests" / "fixtures" / "trader-scanner" / "wall5m-2026-10-19.json.gz").is_file())
        return {"ready": ready, "mode": "OFFLINE_REPLAY_ONLY", "skills_path": str(repo) if ready else None,
                "message": "Set ALGO_SKILLS_PATH to your trusted local day-trader-skill checkout." if not ready else "Offline historical fixture available."}

    @app.post("/api/scanner/replay")
    def scanner_replay(session=Depends(mutation_auth)):
        skills = os.getenv("ALGO_SKILLS_PATH", "")
        repo = Path(skills).expanduser().resolve() if skills else None
        if not repo:
            raise HTTPException(status_code=503, detail="Set ALGO_SKILLS_PATH before replay")
        script = repo / "trader-scanner" / "scan.py"
        fixture = repo / "tests" / "fixtures" / "trader-scanner" / "wall5m-2026-10-19.json.gz"
        if not script.is_file() or not fixture.is_file():
            raise HTTPException(status_code=503, detail="Offline scanner fixture or script missing")
        try:
            proc = subprocess.run([
                sys.executable, str(script), "orb", "--offline", str(fixture),
                "--now", "2026-10-19 10:15", "--min-price", "0", "--no-write", "--json"],
                cwd=str(repo), capture_output=True, text=True, timeout=45, check=False)
        except (OSError, subprocess.TimeoutExpired):
            raise HTTPException(status_code=503, detail="Offline scanner could not complete")
        return {"mode": "OFFLINE_REPLAY_ONLY", "fixture_date": "2026-10-19",
                "exit_code": proc.returncode,
                "output": proc.stdout[-35000:], "error": proc.stderr[-2000:],
                "notice": "Historical replay only. No live market data or trading orders."}

    return app


app = create_app()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Algo Trader, paper-only trading dashboard")
    sub = parser.add_subparsers(dest="command", required=True)
    setup = sub.add_parser("init", help="initialize one administrator password")
    setup.add_argument("--username", default="admin")
    backup = sub.add_parser("backup", help="make a consistent SQLite backup")
    backup.add_argument("--out", required=True, help="destination .sqlite3 file (keep private)")
    run = sub.add_parser("run", help="launch local web UI")
    run.add_argument("--host", default="127.0.0.1")
    run.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if args.command == "init":
        pwd = getpass.getpass("New password (at least 12 characters): ")
        confirm = getpass.getpass("Repeat password: ")
        if pwd != confirm:
            raise SystemExit("Passwords do not match")
        try:
            bootstrap_user(Path(os.getenv("ALGO_DB_PATH", str(DEFAULT_DB))), args.username, pwd)
        except ValueError as ex:
            raise SystemExit(str(ex))
        print("Administrator created. Keep your password private; it is not printed or stored in plaintext.")
    elif args.command == "backup":
        source_path = Path(os.getenv("ALGO_DB_PATH", str(DEFAULT_DB)))
        dest = Path(args.out).resolve()
        if source_path.resolve() == dest:
            raise SystemExit("Backup target must differ from source")
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            raise SystemExit("Refusing to overwrite an existing backup")
        if storage_mode() == "postgresql":
            raise SystemExit("Physical .sqlite3 backups are local-only. Use signed-in /api/backup/export for PostgreSQL.")
        with connect(source_path) as src:
            with sqlite3.connect(dest) as tgt:
                src.backup(tgt)
        try:
            os.chmod(dest, 0o600)
        except OSError:
            pass
        print("SQLite backup created. Keep the file private; it contains password hashes and sessions.")
    elif args.command == "run":
        import uvicorn
        uvicorn.run(app, host=args.host, port=args.port)
