"""BTC fractional paper-only checks. No public network and no Neon mutations."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from test_btc_lab import sample_candles
from app import create_app, bootstrap_user


class BTCFractionalPaperTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)/'btc.sqlite3'
        self.app=create_app(self.path)
        bootstrap_user(self.path,'admin','test-password-over-12')
        self.client=TestClient(self.app)
        login=self.client.post('/api/auth/login',json={'username':'admin','password':'test-password-over-12'})
        self.assertEqual(login.status_code,200,login.text)
        self.csrf={'X-CSRF-Token':login.json()['csrf']}
        self.payload={'qty':0.005,'entry_price':70000,'stop_price':68000,'target_price':75000}

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def post(self,url,data):
        return self.client.post(url,json=data,headers=self.csrf)

    def test_portfolio_is_separate_and_fractional(self):
        original=self.client.get('/api/overview').json()
        btc=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(btc['cash'],5000)
        self.assertTrue(btc['separate_cash_from_legacy'])
        self.assertFalse(btc['execution_enabled'])
        opening=self.post('/api/btc/paper/open',self.payload)
        self.assertEqual(opening.status_code,200,opening.text)
        self.assertEqual(opening.json()['qty'],.005)
        self.assertEqual(opening.json()['entry_fee'],.35)
        paper=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(paper['cash'],4649.65)
        self.assertEqual(paper['positions'][0]['qty'],.005)
        after=self.client.get('/api/overview').json()
        for name in ('cash','equity','positions','closed_trades','watchlist'):
            self.assertEqual(original[name],after[name],name)

    def test_close_uses_net_fees_and_cannot_close_twice(self):
        opening=self.post('/api/btc/paper/open',self.payload)
        trade_id=opening.json()['trade_id']
        close=self.post(f'/api/btc/paper/{trade_id}/close',{'exit_price':72000})
        self.assertEqual(close.status_code,200,close.text)
        self.assertEqual(close.json()['exit_fee'],.36)
        self.assertEqual(close.json()['pnl_after_fees'],9.29)
        self.assertEqual(self.client.get('/api/btc/paper/portfolio').json()['cash'],5009.29)
        self.assertEqual(self.post(f'/api/btc/paper/{trade_id}/close',{'exit_price':72000}).status_code,422)

    def test_stop_risk_rejections(self):
        bad=[
            {'stop_price':70000}, {'target_price':69000}, {'target_price':71000},
            {'qty':0}, {'qty':0.000000001}, {'qty':0.000001}, {'qty':1},
            {'qty':.04,'stop_price':67000}, {'qty':.1},
            {'entry_price':70000.00001}, {'qty':0.000005123},
        ]
        for fields in bad:
            with self.subTest(fields=fields):
                response=self.post('/api/btc/paper/open',dict(self.payload,**fields))
                self.assertIn(response.status_code,(400,422),response.text)
        self.assertEqual(self.client.get('/api/btc/paper/portfolio').json()['cash'],5000)

    def test_one_open_position_and_utc_daily_entries_limit(self):
        for i in range(3):
            opened=self.post('/api/btc/paper/open',self.payload)
            self.assertEqual(opened.status_code,200,opened.text)
            self.assertEqual(self.post('/api/btc/paper/open',self.payload).status_code,422)
            closed=self.post('/api/btc/paper/'+str(opened.json()['trade_id'])+'/close',{'exit_price':70000})
            self.assertEqual(closed.status_code,200,closed.text)
        self.assertEqual(self.post('/api/btc/paper/open',self.payload).status_code,422)
        self.assertEqual(self.client.get('/api/btc/paper/portfolio').json()['entries_today'],3)

    def test_session_and_csrf_protections(self):
        with TestClient(create_app(Path(self.tmp.name)/'other.sqlite3')) as client:
            self.assertEqual(client.get('/api/btc/paper/portfolio').status_code,401)
        self.assertEqual(self.client.post('/api/btc/paper/open',json=self.payload).status_code,403)
        self.assertEqual(self.client.post('/api/btc/paper/mark',json={'price':71000}).status_code,403)
        self.assertEqual(self.client.post('/api/btc/strategies/compare',json={'timeframe':60}).status_code,403)

    def test_manual_mark_and_restart_preserve_account(self):
        self.assertEqual(self.post('/api/btc/paper/open',self.payload).status_code,200)
        self.assertEqual(self.post('/api/btc/paper/mark',{'price':72000}).status_code,200)
        before=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(before['positions'][0]['mark_source'],'manual BTC scenario')
        self.assertAlmostEqual(before['positions'][0]['unrealized_pnl_after_fees'],9.29)
        self.client.close()
        self.client=TestClient(create_app(self.path))
        relogin=self.client.post('/api/auth/login',json={'username':'admin','password':'test-password-over-12'})
        self.assertEqual(relogin.status_code,200)
        after=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(before['cash'],after['cash'])
        self.assertEqual(before['positions'],after['positions'])

    def test_comparison_fetch_once_and_no_ledger_changes(self):
        before=self.client.get('/api/btc/paper/portfolio').json()
        with patch('app.fetch_recent_btc',return_value=sample_candles()) as fetch:
            r=self.post('/api/btc/strategies/compare',{'timeframe':60})
            self.assertEqual(r.status_code,200,r.text)
            x=r.json()
            self.assertEqual(len(x['comparison']),6)
            self.assertTrue(all('equity_curve' not in a for a in x['comparison']))
            self.assertFalse(x['execution_enabled'])
            fetch.assert_called_once_with(60)
            self.assertEqual(self.post('/api/btc/strategies/compare',{'timeframe':60}).status_code,429)
        after=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(before,after)

    def test_reopening_after_app_restart_does_not_reset_cash(self):
        o=self.post('/api/btc/paper/open',self.payload)
        self.assertEqual(o.status_code,200)
        self.client.close()
        self.client=TestClient(create_app(self.path))
        relogin=self.client.post('/api/auth/login',json={'username':'admin','password':'test-password-over-12'})
        self.assertEqual(relogin.status_code,200)
        after=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(after['cash'],4649.65)
        self.assertEqual(len(after['positions']),1)

    def test_no_exchange_order_api_or_secrets(self):
        names={route.path for route in self.app.routes}
        self.assertNotIn('/api/btc/orders/live',names)
        self.assertTrue(all('exchange' not in n and 'broker' not in n for n in names if n.startswith('/api/btc/')))
        from btc_paper import PAIR
        self.assertEqual(PAIR,'BTC/USD')

if __name__=='__main__':unittest.main()
