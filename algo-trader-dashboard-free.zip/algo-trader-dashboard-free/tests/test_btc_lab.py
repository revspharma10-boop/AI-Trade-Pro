"""BTC strategy research offline tests: no provider calls or broker orders."""
import os
import tempfile
from pathlib import Path
from unittest import TestCase, mock
from fastapi.testclient import TestClient

# Ensure import of app never touches real user's database.
_tmp_import = tempfile.TemporaryDirectory()
os.environ['ALGO_DB_PATH'] = str(Path(_tmp_import.name)/'import.sqlite3')
from app import create_app, bootstrap_user
from btc_lab import (DataUnavailable, STRATEGIES, parse_kraken, validate_candles,
                     backtest, fetch_recent_btc)


def sample_candles(n=150):
    p=35000.0
    result=[]
    for i in range(n):
        old=p
        p *= (1.003 if i%50<34 else .996)
        result.append({'time':1_760_000_000+i*3600,'open':old,
                       'high':max(old,p)*1.001,'low':min(old,p)*.999,'close':p})
    return result

class BtcResearchTests(TestCase):
    def test_six_strategies_return_finite_metrics(self):
        candles=sample_candles()
        self.assertEqual(len(STRATEGIES),6)
        for strategy in STRATEGIES:
            with self.subTest(strategy=strategy):
                r=backtest(candles,strategy)
                self.assertEqual(r['symbol'],'BTC/USD')
                self.assertTrue(0<r['ending_equity_usd']<100000)
                self.assertTrue(0<=r['max_drawdown_pct']<=100)
                self.assertLessEqual(len(r['equity_curve']),120)
                self.assertIn(r['latest_decision'],{'BUY','EXIT','HOLD'})

    def test_input_validation_refuses_invalid_candles_and_strategies(self):
        good=sample_candles()
        for invalid in [good[:4],good+[good[-1]],good[:28]+[dict(good[28],close=float('nan'))]+good[29:],
                        good[:28]+[dict(good[28],low=1e9)]+good[29:],good[:28]+[dict(good[28],time=good[27]['time'])]+good[29:]]:
            with self.assertRaises(DataUnavailable):validate_candles(invalid)
        with self.assertRaises(ValueError):backtest(good,'DROP TABLE users')
        with self.assertRaises(DataUnavailable):fetch_recent_btc(7)

    def test_incomplete_last_bar_is_discarded(self):
        candles=sample_candles(95)
        rows=[[c['time'],str(c['open']),str(c['high']),str(c['low']),str(c['close']),'0','1.2',10]
              for c in candles]
        got=parse_kraken({'error':[],'result':{'XXBTZUSD':rows,'last':0}})
        self.assertEqual(len(got),94)
        self.assertEqual(got[-1]['time'],candles[-2]['time'])
        with self.assertRaises(DataUnavailable):parse_kraken({'error':['Rate limit'], 'result':{'XXBTZUSD':rows}})
        with self.assertRaises(DataUnavailable):parse_kraken({'error':[], 'result':{'ETHUSD':rows}})

    def test_no_future_candle_leakage_into_old_equity(self):
        c=sample_candles()
        old=backtest(c,'ema_cross')['equity_curve']
        future=sample_candles(170)
        for j in range(len(c),len(future)):
            future[j]['open']*=5
            future[j]['high']*=5
            future[j]['low']*=5
            future[j]['close']*=5
        new=backtest(future,'ema_cross')['equity_curve']
        self.assertEqual(old[20:],new[:-20])

    def test_auth_csrf_cooldown_and_no_ledger_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'research.sqlite3'
            app=create_app(db)
            bootstrap_user(db,'admin','example-long-password')
            with TestClient(app) as c:
                self.assertEqual(c.get('/api/btc/strategies').status_code,401)
                login=c.post('/api/auth/login',json={'username':'admin','password':'example-long-password'})
                self.assertEqual(login.status_code,200)
                csrf=login.json()['csrf']
                catalog=c.get('/api/btc/strategies')
                self.assertEqual(len(catalog.json()['strategies']),6)
                payload={'strategy':'ema_cross','timeframe':60}
                self.assertEqual(c.post('/api/btc/strategies/run',json=payload).status_code,403)
                self.assertEqual(c.post('/api/btc/strategies/run',json={'strategy':'unknown','timeframe':60},headers={'X-CSRF-Token':csrf}).status_code,422)
                initial=c.get('/api/overview').json()
                with mock.patch('app.fetch_recent_btc', return_value=sample_candles()) as stub:
                    response=c.post('/api/btc/strategies/run',json=payload,headers={'X-CSRF-Token':csrf})
                    self.assertEqual(response.status_code,200,response.text)
                    self.assertFalse(response.json()['execution_enabled'])
                    self.assertEqual(response.json()['provider'],'Kraken public spot OHLC')
                    self.assertEqual(c.post('/api/btc/strategies/run',json=payload,headers={'X-CSRF-Token':csrf}).status_code,429)
                    stub.assert_called_once_with(60)
                final=c.get('/api/overview').json()
                for k in ['cash','equity','positions','closed_trades','watchlist']:
                    self.assertEqual(initial[k],final[k],k)
