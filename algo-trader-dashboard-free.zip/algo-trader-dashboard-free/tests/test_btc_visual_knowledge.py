import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from app import create_app, bootstrap_user
from database import connect
from btc_education import knowledge_catalog
from btc_visual import FeedUnavailable,parse_chart,parse_trades,parse_ticker,market_snapshot

NOW=1792940000

def bars(now=NOW,amount=80,step=3600):
    end=(now//step)*step
    rows=[]
    for i in range(amount):
        ts=end-(amount-1-i)*step
        v=70000+i
        rows.append([ts,str(v),str(v+20),str(v-30),str(v+1),str(v+2),'5.125',100])
    return {'error':[],'result':{'XXBTZUSD':rows,'last':'x'}}

def trades(now=NOW):
    return {'error':[],'result':{'XXBTZUSD':[
        ['70000','1.5',now-8,'b','l',''],['70001','0.5',now-5,'s','l',''],
        ['70002','0.5',now-2,'b','l','']], 'last':'0'}}

def ticker():
    return {'error':[],'result':{'XXBTZUSD':{'c':['70002','1'],'o':'69000','v':['500','1000']}}}

class ChartParseTests(unittest.TestCase):
    def test_chart_drop_current_bar(self):
        data=bars();result=parse_chart(data,60,clock=NOW)
        self.assertEqual(len(result['bars']),79)
        self.assertEqual(result['latest_completed_close'],70079)
        self.assertEqual(result['bars'][-1]['time'],data['result']['XXBTZUSD'][-2][0])
        self.assertFalse(result['stale'])
        self.assertGreater(result['completed_close_change_pct'],0)

    def test_partial_candles_fail_closed(self):
        data=bars(amount=2)
        with self.assertRaises(FeedUnavailable):parse_chart(data,60,clock=NOW)
        with self.assertRaises(FeedUnavailable):parse_chart(bars(),120,clock=NOW)

    def test_future_and_unexpected_pair_rejected(self):
        data=bars()
        data['result']['XXBTZUSD'][20][0]=NOW+40000
        with self.assertRaises(FeedUnavailable):parse_chart(data,60,clock=NOW)
        other=bars();other['result']={'ETHUSD':other['result']['XXBTZUSD']}
        with self.assertRaises(FeedUnavailable):parse_chart(other,60,clock=NOW)

    def test_trade_volume_not_trade_count(self):
        d=parse_trades(trades(),clock=NOW)
        self.assertEqual(d['buy_pct'],80)
        self.assertEqual(d['sell_pct'],20)
        self.assertEqual(d['trade_count_buy'],2)
        self.assertEqual(d['sample_count'],3)
        self.assertEqual(d['buy_sell_ratio'],4)
        self.assertIn('both a buyer and seller',d['note'])

    def test_trade_bad_data_and_missing(self):
        with self.assertRaises(FeedUnavailable):parse_trades({'error':[],'result':{'XXBTZUSD':[]}},clock=NOW)
        b=trades();b['result']['XXBTZUSD'][0][3]='N/A'
        with self.assertRaises(FeedUnavailable):parse_trades(b,clock=NOW)
        b=trades();b['result']['XXBTZUSD'][0][1]='nan'
        with self.assertRaises(FeedUnavailable):parse_trades(b,clock=NOW)

    def test_ticker_validation(self):
        d=parse_ticker(ticker());self.assertEqual(d['last_trade_price_usd'],70002)
        d=ticker();d['result']['XXBTZUSD']['c'][0]='Infinity'
        with self.assertRaises(FeedUnavailable):parse_ticker(d)

    def test_partial_channel_snapshot(self):
        with patch('btc_visual._get_ohlc',return_value=bars()),patch('btc_visual._get_json',side_effect=lambda resource,maxbytes: trades() if resource=='Trades' else ticker()):
            d=market_snapshot(60,timestamp=NOW)
        self.assertTrue(d['has_data']);self.assertEqual(set(d['channels']),{'candles','trades','ticker'})
        with patch('btc_visual._get_ohlc',side_effect=FeedUnavailable('OHLC down')),patch('btc_visual._get_json',side_effect=lambda resource,maxbytes: trades() if resource=='Trades' else ticker()):
            d=market_snapshot(60,timestamp=NOW)
        self.assertNotIn('candles',d['channels']);self.assertTrue(d['has_data'])

class KnowledgeWebTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'test.sqlite3'
        self.server=create_app(self.path);bootstrap_user(self.path,'admin','very-strong-test-password')
        self.client=TestClient(self.server)
        response=self.client.post('/api/auth/login',json={'username':'admin','password':'very-strong-test-password'})
        assert response.status_code==200,response.text
    def tearDown(self):self.client.close();self.tmp.cleanup()

    def test_library_btc_only_and_active_methods_counted(self):
        cat=self.client.get('/api/btc/education/library');self.assertEqual(cat.status_code,200)
        d=cat.json();self.assertEqual(d['scope'],'BITCOIN_ONLY')
        self.assertGreaterEqual(len(d['topics']),15)
        self.assertGreaterEqual(len(d['strategies']),35)
        self.assertEqual(d['implemented_strategy_count'],6)
        self.assertFalse(d['llm_connected'])
        self.assertTrue(all(z['source_url'].startswith('https://') for z in d['topics']+d['strategies']))
        self.assertTrue(any('min' in x['title'].lower() for x in d['topics']))
        self.assertTrue(any('rise' in x['title'].lower() for x in d['topics']))
    def test_unauthenticated_endpoints_blocked(self):
        cl=TestClient(self.server)
        self.assertEqual(cl.get('/api/btc/visual').status_code,401)
        self.assertEqual(cl.get('/api/btc/education/library').status_code,401)
        cl.close()
    def test_web_visual_real_data_mock_and_durable_quota(self):
        stub={'symbol':'BTC/USD','has_data':True,'venue':'Kraken','channels':{'ticker':parse_ticker(ticker())},'errors':{},'paper_only':True}
        with patch('app.btc_visual.market_snapshot',return_value=stub) as source:
            r=self.client.get('/api/btc/visual?timeframe=60')
            self.assertEqual(r.status_code,200,r.text)
            self.assertEqual(r.json()['symbol'],'BTC/USD')
            self.assertEqual(self.client.get('/api/btc/visual?timeframe=60').status_code,429)
            source.assert_called_once()
        self.assertEqual(self.client.get('/api/btc/visual?timeframe=120').status_code,422)
        with connect(self.path) as db:self.assertEqual(db.execute("SELECT COUNT(*) FROM btc_paper_trades").fetchone()[0],0)
        with connect(self.path) as db:self.assertEqual(float(db.execute("SELECT cash FROM btc_paper_account WHERE id=1").fetchone()[0]),5000)
    def test_all_feeds_unavailable_fail_closed(self):
        with patch('app.btc_visual.market_snapshot',return_value={'has_data':False,'errors':{'candles':'offline','trades':'offline','ticker':'offline'},'channels':{}}):
            response=self.client.get('/api/btc/visual?timeframe=15')
        self.assertEqual(response.status_code,503)
        self.assertIn('unavailable',response.json()['detail'])
    def test_no_github_or_broker_calls(self):
        d=knowledge_catalog();self.assertIn('not every strategy',d['disclaimer'])
        self.assertTrue(all(x['implementation_status'] in ('KNOWLEDGE_ONLY','BACKTESTED_RULE') for x in d['strategies']))

if __name__=='__main__': unittest.main()
