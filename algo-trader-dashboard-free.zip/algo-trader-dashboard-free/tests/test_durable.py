import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import database

class FakeCursor:
    def __init__(self, values=None):
        self.description = [type('Column', (), {'name': 'id'})()]
        self._values = list(values or [])
    def fetchone(self):
        return self._values.pop(0) if self._values else None
    def fetchall(self):
        return list(self._values)

class FakePg:
    def __init__(self):
        self.executed=[]
    def execute(self, sql, params=()):
        self.executed.append((sql, params))
        if 'RETURNING id' in sql: return FakeCursor([(42,)])
        return FakeCursor([(1,)])

class DurableTests(unittest.TestCase):
    def test_pg_sql_parameter_and_on_conflict_conversion(self):
        self.assertEqual(database.pg_sql('INSERT OR IGNORE INTO watchlist(symbol) VALUES (?)'),
                         'INSERT INTO watchlist(symbol) VALUES (%s) ON CONFLICT DO NOTHING')
        self.assertEqual(database.pg_sql('SELECT * FROM users WHERE username=?'),
                         'SELECT * FROM users WHERE username=%s')

    def test_postgres_trade_insert_and_row_access(self):
        fake=FakePg()
        conn=database.PgConnection(fake)
        result=conn.execute('INSERT INTO trades(symbol) VALUES (?)',('AAPL',))
        self.assertEqual(result.lastrowid,42)
        self.assertTrue(fake.executed[0][0].endswith('RETURNING id'))
        row=conn.execute('SELECT 1').fetchone()
        self.assertEqual(row[0],1)
        self.assertEqual(row['id'],1)

    def test_immediate_begin_serializes_paper_writers(self):
        fake=FakePg()
        conn=database.PgConnection(fake)
        conn.execute('BEGIN IMMEDIATE')
        self.assertEqual([x[0] for x in fake.executed],
                         ['BEGIN','SELECT id FROM account WHERE id=1 FOR UPDATE','SELECT 1'])
        conn.execute('ROLLBACK')
        self.assertEqual(fake.executed[-1][0],'ROLLBACK')

    def test_require_durable_fails_closed_when_url_absent(self):
        with TemporaryDirectory() as d:
            path=Path(d)/'unsafe.sqlite3'
            with patch.dict(os.environ, {'ALGO_REQUIRE_DURABLE':'1','ALGO_DATABASE_URL':''}):
                with self.assertRaisesRegex(RuntimeError, 'Durable storage required'):
                    database.init_schema(path,'CREATE TABLE whatever(id INTEGER);')
            self.assertFalse(path.exists())

    def test_bad_postgres_url_does_not_create_local_db(self):
        with TemporaryDirectory() as d:
            path=Path(d)/'fallback.sqlite3'
            with patch.dict(os.environ, {'ALGO_DATABASE_URL':'http://wrong.example'}):
                with self.assertRaisesRegex(RuntimeError, 'PostgreSQL connection string'):
                    with database.connect(path): pass
            self.assertFalse(path.exists())

    def test_postgres_schema_contains_required_tables(self):
        for table in ['users','sessions','failed_logins','account','trades',
                      'watchlist','marks','market_quotes','market_fetches']:
            self.assertIn('CREATE TABLE IF NOT EXISTS '+table, database.POSTGRES_SCHEMA)

if __name__=='__main__':unittest.main()
