import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class OnlineOnlyMigrationAssets(unittest.TestCase):
    def test_transfer_controls_exist(self):
        html=(ROOT/'static/index.html').read_text()
        for element in ('cloud-copy','cloud-paste','cloud-payload','cloud-clear','cloud-message'):
            self.assertIn('id="'+element+'"',html)
        self.assertIn('No file is saved to your laptop',html)

    def test_transfer_uses_authenticated_api_and_no_disk_storage(self):
        js=(ROOT/'static/app.js').read_text()
        block=js.split('// A browser-only transfer:',1)[1].split("$('backup-download').addEventListener",1)[0]
        for term in ('/api/backup/export','/api/backup/restore',"credentials:'same-origin'",'X-CSRF-Token','X-Restore-Confirm',"navigator.clipboard.readText()","navigator.clipboard.writeText(content)","if(!confirm("):
            self.assertIn(term,block)
        for forbidden in ('window.localStorage','sessionStorage','indexedDB','new WebSocket','http://','https://'):
            self.assertNotIn(forbidden,block)

    def test_legacy_server_logic_unchanged(self):
        code=(ROOT/'app.py').read_text()
        self.assertIn('@app.get("/api/backup/export")',code)
        self.assertIn('@app.post("/api/backup/restore")',code)
        self.assertIn('validate_backup(doc)',code)
        self.assertIn('mutation_auth',code)

if __name__=='__main__': unittest.main()
