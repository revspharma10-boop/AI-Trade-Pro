"""BTC signal monitoring: exact-once audit rows; no trading side effects."""
from __future__ import annotations
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from app import create_app, bootstrap_user
from btc_lab import STRATEGIES, DataUnavailable
from btc_signals import evaluate, record, history
from database import connect
from test_btc_lab import sample_candles


def current_candles(interval=60):
    arr = sample_candles()
    seconds=interval*60
    latest = (int(time.time())//seconds-1)*seconds
    first = latest-(len(arr)-1)*seconds
    for n,c in enumerate(arr):
        c['time']=first+n*seconds
    return arr

class SignalMonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)/'signals.sqlite3'
        self.app=create_app(self.path)
        bootstrap_user(self.path,'admin','test-password-over-12')
        self.client=TestClient(self.app)
        login=self.client.post('/api/auth/login',json={'username':'admin','password':'test-password-over-12'})
        self.assertEqual(login.status_code,200,login.text)
        self.csrf={'X-CSRF-Token':login.json()['csrf']}

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def test_evaluate_uses_only_last_two_completed_candles(self):
        candles=current_candles()
        checks=evaluate(candles,60)
        self.assertEqual(len(checks),6)
        self.assertEqual({r['strategy'] for r in checks},set(STRATEGIES))
        self.assertTrue(all(r['candle_time']==candles[-1]['time'] for r in checks))
        self.assertTrue(all(r['signal'] in {'BUY','EXIT','HOLD_LONG','HOLD_FLAT'} for r in checks))

    def test_reject_incomplete_stale_and_invalid_timeframe(self):
        candles=current_candles()
        latest=candles[-1]['time']
        with self.assertRaises(DataUnavailable):evaluate(candles,60,timestamp=latest+600)
        with self.assertRaises(DataUnavailable):evaluate(candles,60,timestamp=latest+3*3600)
        with self.assertRaises(DataUnavailable):evaluate(candles,7)
        with self.assertRaises(DataUnavailable):evaluate(candles[:8],60)

    def test_idempotent_signals_persist_restart(self):
        candles=current_candles()
        with connect(self.path) as db:
            first=record(db,candles,60)
            second=record(db,candles,60)
            self.assertEqual(first['signals'],second['signals'])
            self.assertFalse(first['paper_auto_execution_enabled'])
            self.assertEqual(len(history(db,60)['checks']),6)
            count=db.execute('SELECT COUNT(*) FROM btc_signal_checks').fetchone()[0]
            self.assertEqual(count,6)
        self.client.close()
        self.client=TestClient(create_app(self.path))
        with connect(self.path) as db:
            self.assertEqual(len(history(db,60)['checks']),6)
            self.assertEqual(db.execute('SELECT cash FROM btc_paper_account WHERE id=1').fetchone()[0],5000)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)

    def test_web_auth_csrf_and_no_trade_side_effects(self):
        self.assertEqual(TestClient(self.app).get('/api/btc/signals/history').status_code,401)
        self.assertEqual(self.client.post('/api/btc/signals/check',json={'timeframe':60}).status_code,403)
        with patch('app.fetch_recent_btc',return_value=current_candles()) as fetch:
            ok=self.client.post('/api/btc/signals/check',headers=self.csrf,json={'timeframe':60})
            self.assertEqual(ok.status_code,200,ok.text)
            self.assertEqual(len(ok.json()['signals']),6)
            self.assertFalse(ok.json()['paper_auto_execution_enabled'])
            fetch.assert_called_once_with(60)
            self.assertEqual(self.client.post('/api/btc/signals/check',headers=self.csrf,json={'timeframe':60}).status_code,429)
        ledger=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(ledger['cash'],5000)
        self.assertEqual(ledger['positions'],[])
        old=self.client.get('/api/overview').json()
        self.assertEqual(old['cash'],5000)
        self.assertEqual(len(self.client.get('/api/btc/signals/history').json()['checks']),6)

    def test_stale_candle_is_never_recorded(self):
        candles=current_candles()
        for c in candles:c['time']-=3*3600
        with patch('app.fetch_recent_btc',return_value=candles):
            r=self.client.post('/api/btc/signals/check',headers=self.csrf,json={'timeframe':60})
        self.assertEqual(r.status_code,503,r.text)
        with connect(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_signal_checks').fetchone()[0],0)

    def test_scheduler_disabled_fail_closed(self):
        with patch.dict(os.environ,{'ALGO_BTC_SCAN_JOB_ENABLED':'0','ALGO_BTC_SCAN_JOB_KEY':'long-machine-key-not-usable-without-enable'},clear=False):
            r=self.client.post('/api/btc/signals/job',headers={'X-BTC-Scan-Key':'long-machine-key-not-usable-without-enable'})
        self.assertEqual(r.status_code,404)
        self.assertEqual(self.client.post('/api/btc/signals/job',headers={'X-BTC-Scan-Key':'1234'}).status_code,404)

    def test_signal_history_requires_valid_timeframe(self):
        self.assertEqual(self.client.get('/api/btc/signals/history?timeframe=13').status_code,422)

    def test_not_any_live_execution_routes(self):
        routes={r.path for r in self.app.routes}
        self.assertIn('/api/btc/signals/check',routes)
        self.assertNotIn('/api/btc/orders/live',routes)
        self.assertNotIn('/api/btc/orders/auto',routes)

if __name__=='__main__':unittest.main()
