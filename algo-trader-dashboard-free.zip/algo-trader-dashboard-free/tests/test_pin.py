"""4 digit PIN and account-wide abuse defenses on the paper-only dashboard."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('ALGO_DB_PATH',str(Path(tempfile.gettempdir())/'algo-pin-import.sqlite3'))
from fastapi.testclient import TestClient
from app import create_app

OLD = 'initial-strong-password-2026'
KEY = 'a-long-unique-paper-recovery-key-for-tests-2026'
PIN = '6804'
NEW_PIN = '9046'

class PINTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.p=patch.dict(os.environ, {'ALGO_REQUIRE_ADMIN':'1','ALGO_BOOTSTRAP_PASSWORD':OLD,
                     'ALGO_BOOTSTRAP_USERNAME':'admin','ALGO_RECOVERY_KEY':KEY})
        self.p.start()
        self.path=Path(self.t.name)/'pin.sqlite3'
        self.client=TestClient(create_app(self.path))
    def tearDown(self):
        self.client.close();self.p.stop();self.t.cleanup()
    def login(self,secret,username='admin',client=None):
        return (client or self.client).post('/api/auth/login',json={'username':username,'password':secret})
    def change(self,old,new):
        good=self.login(old)
        self.assertEqual(good.status_code,200)
        return self.client.post('/api/auth/change-password',json={'current_password':old,'new_password':new},headers={'x-csrf-token':good.json()['csrf']})
    def reset(self,pin=PIN,key=KEY):
        return self.client.post('/api/auth/reset-password',json={'username':'admin','recovery_key':key,'new_password':pin})

    def test_pin_change_login_and_logout_sessions(self):
        self.assertEqual(self.change(OLD,PIN).status_code,200)
        self.assertEqual(self.client.get('/api/auth/me').status_code,401)
        self.assertEqual(self.login(PIN).status_code,200)
        self.assertEqual(self.login(OLD).status_code,401)
        self.assertEqual(self.change(PIN,NEW_PIN).status_code,200)
        self.assertEqual(self.login(NEW_PIN).status_code,200)

    def test_forgot_password_reset_with_recovery_key_to_pin(self):
        self.assertEqual(self.reset(key='wrong-key').status_code,401)
        self.assertEqual(self.reset().status_code,200)
        self.assertEqual(self.login(PIN).status_code,200)
        self.assertEqual(self.login(OLD).status_code,401)

    def test_pin_must_be_exactly_four_digits_and_not_common(self):
        for bad in ('1234','0000','1111','abc4','123','12345','0012a','pass'):
            result=self.reset(pin=bad)
            self.assertEqual(result.status_code,422,(bad,result.text))
        self.assertEqual(self.reset(pin=PIN).status_code,200)

    def test_account_lockout_is_persistent_and_spans_ip_addresses(self):
        self.assertEqual(self.reset().status_code,200)
        c2=TestClient(create_app(self.path),client=('203.0.113.7',12345))
        try:
            for client in (self.client,c2,self.client):
                self.assertEqual(self.login('0000',client=client).status_code,401)
            self.assertEqual(self.login(PIN,client=c2).status_code,429)
            self.assertEqual(self.login(PIN).status_code,429)
        finally:c2.close()

    def test_12_char_password_still_works_and_bootstrap_pin_rejected(self):
        self.assertEqual(self.change(OLD,'long-strong-password-2026').status_code,200)
        self.assertEqual(self.login('long-strong-password-2026').status_code,200)
        with tempfile.TemporaryDirectory() as td:
            with patch.dict(os.environ,{'ALGO_REQUIRE_ADMIN':'1','ALGO_BOOTSTRAP_PASSWORD':'6804'}):
                with self.assertRaises(ValueError):create_app(Path(td)/'bad.sqlite3')

if __name__=='__main__':unittest.main()
