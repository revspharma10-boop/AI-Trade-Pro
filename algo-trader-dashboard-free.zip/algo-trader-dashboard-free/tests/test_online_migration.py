"""Exercise browser-only source-export/destination-restore APIs without local backup files."""
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import unittest
from fastapi.testclient import TestClient

os.environ.setdefault('ALGO_DB_PATH', '/tmp/cloud-migration-import.sqlite3')
from app import create_app, bootstrap_user

class CloudMigrationApiTests(unittest.TestCase):
    def test_signed_in_cloud_to_cloud_transfer_preserves_destination_pin(self):
        with TemporaryDirectory() as d:
            source_file=Path(d)/'old.sqlite3'
            dest_file=Path(d)/'new.sqlite3'
            old_app=create_app(source_file)
            new_app=create_app(dest_file)
            bootstrap_user(source_file,'admin','old-long-password-5432')
            bootstrap_user(dest_file,'admin','new-long-password-8765')
            with TestClient(old_app) as source, TestClient(new_app) as dest:
                old=source.post('/api/auth/login',json={'username':'admin','password':'old-long-password-5432'})
                new=dest.post('/api/auth/login',json={'username':'admin','password':'new-long-password-8765'})
                self.assertEqual(old.status_code,200,old.text)
                self.assertEqual(new.status_code,200,new.text)
                old_headers={'X-CSRF-Token':old.json()['csrf']}
                new_headers={'X-CSRF-Token':new.json()['csrf'],'X-Restore-Confirm':'REPLACE'}
                self.assertEqual(source.post('/api/watchlist',json={'symbol':'AAPL'},headers=old_headers).status_code,200)
                self.assertEqual(source.post('/api/trades/open',json={'symbol':'MSFT','qty':2,'entry_price':100,'stop_price':98,'target_price':105},headers=old_headers).status_code,200)
                self.assertEqual(dest.post('/api/watchlist',json={'symbol':'TSLA'},headers={'X-CSRF-Token':new.json()['csrf']}).status_code,200)
                export=source.get('/api/backup/export')
                self.assertEqual(export.status_code,200)
                self.assertIn('MSFT',export.text)
                self.assertNotIn('old-long-password-5432',export.text)
                self.assertNotIn('new-long-password-8765',export.text)
                # No local .json file ever created: transmit authenticated JSON in memory.
                unauthorized=dest.post('/api/backup/restore',content=export.content,
                    headers={'Content-Type':'application/json','X-Restore-Confirm':'REPLACE'})
                self.assertEqual(unauthorized.status_code,403)
                restored=dest.post('/api/backup/restore',content=export.content,
                    headers={**new_headers,'Content-Type':'application/json'})
                self.assertEqual(restored.status_code,200,restored.text)
                self.assertEqual(restored.json()['trades'],1)
                result=dest.get('/api/overview').json()
                self.assertEqual(result['cash'],4800)
                self.assertEqual(len(result['positions']),1)
                self.assertEqual(result['positions'][0]['symbol'],'MSFT')
                self.assertIn('AAPL',result['watchlist'])
                self.assertNotIn('TSLA',result['watchlist'])
                self.assertEqual(dest.post('/api/auth/login',json={'username':'admin','password':'old-long-password-5432'}).status_code,401)
                self.assertEqual(dest.post('/api/auth/login',json={'username':'admin','password':'new-long-password-8765'}).status_code,200)
                self.assertEqual(len(source.get('/api/overview').json()['positions']),1)
                self.assertFalse(list(Path(d).glob('*.json')))
