import unittest
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
class NavParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.tabs=[]; self.ids=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if 'data-tab' in d: self.tabs.append(d['data-tab'])
        if d.get('id'): self.ids.append(d['id'])

class TestTopNavigation(unittest.TestCase):
    def test_btc_navigation_prioritized_and_preserved(self):
        html=(ROOT/'static/index.html').read_text()
        parser=NavParser(); parser.feed(html)
        self.assertEqual(parser.tabs[0], 'btc-brain')
        self.assertEqual(len(parser.tabs), len(set(parser.tabs)))
        self.assertEqual(len(parser.tabs), 13)
        self.assertIn('btc-paper', parser.tabs)
        self.assertIn('account', parser.tabs)
        self.assertIn('btc-brain-timeframe', parser.ids)
        self.assertIn('logout', parser.ids)
    def test_menu_is_above_main_and_mobile_scrollable(self):
        html=(ROOT/'static/index.html').read_text()
        css=(ROOT/'static/style.css').read_text()
        self.assertLess(html.index('class="sidebar"'), html.index('<main>'))
        self.assertIn('.shell { display:flex; flex-direction:column;',css)
        self.assertIn('.side-nav { grid-column:1 / -1; grid-row:2; display:flex; flex-wrap:nowrap;',css)
        self.assertIn('overflow-x:auto',css)
