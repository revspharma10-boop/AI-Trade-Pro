"""BTC AI Brain: decision trace, source quality, auth, persistence, no execution."""
from __future__ import annotations
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from app import create_app, bootstrap_user
from database import connect
from btc_brain import analyze, record, history, fetch_onchain, KNOWLEDGE
from btc_lab import DataUnavailable
from test_btc_signals import current_candles


def paper():
    return {'cash':5000.0,'equity':5000.0,'positions':[], 'entries_today':0,
            'loss_today':0.0,'planned_open_risk':0.0}


def network():
    return {'status':'AVAILABLE','source':'mempool.space Bitcoin network recommended fees',
            'unit':'sat/vB','rates':{'fastestFee':12,'halfHourFee':8,'hourFee':5,'economyFee':2},
            'fetched_at_utc':'2026-10-25T10:23:00+00:00','directional_price_signal':None}

class BrainChecks(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'brain.sqlite3'
        self.app=create_app(self.path)
        bootstrap_user(self.path,'admin','long-valid-test-password')
        self.client=TestClient(self.app)
        a=self.client.post('/api/auth/login',json={'username':'admin','password':'long-valid-test-password'})
        self.assertEqual(a.status_code,200)
        self.csrf={'X-CSRF-Token':a.json()['csrf']}

    def tearDown(self):
        self.client.close();self.temp.cleanup()

    def test_knowledge_is_explicit_and_mixed_level(self):
        self.assertEqual({x['level'] for x in KNOWLEDGE},{'foundation','intermediate','advanced','specialist'})
        self.assertTrue(any(x['topic']=='On-chain network activity' for x in KNOWLEDGE))
        k=self.client.get('/api/btc/brain/knowledge')
        self.assertEqual(k.status_code,200)
        self.assertFalse(k.json()['llm_connected'])
        self.assertIn('BTC ETF flows',k.json()['missing_sources'])

    def test_missing_fundamental_fails_conservatively_without_orders(self):
        r=analyze(current_candles(60),60,paper(),onchain={'status':'UNAVAILABLE','source':'mempool.space'})
        self.assertEqual(r['verdict'],'WAIT')
        self.assertEqual(r['fundamental']['coverage'],'NO_LIVE_FUNDAMENTALS')
        self.assertEqual(r['engine_kind'],'EXPLAINABLE_RULE_ENGINE')
        self.assertIsNone(r['calibrated_probability'])
        self.assertFalse(r['paper_execution_enabled'])
        self.assertFalse(r['real_order_execution_enabled'])
        self.assertTrue(any('no verified' in s.lower() for s in r['unknowns']))

    def test_network_fees_never_become_directional_price_signal(self):
        r=analyze(current_candles(60),60,paper(),onchain=network())
        self.assertEqual(r['fundamental']['network_fees']['directional_price_signal'],None)
        self.assertIn(r['verdict'],{'WAIT','CONDITIONAL_BUY'})
        self.assertFalse(r['llm_connected'])
        self.assertEqual(len(r['technical']['strategy_states']),6)
        self.assertIsNone(r['calibrated_probability'])

    def test_invalid_or_stale_market_data_rejected(self):
        c=current_candles(60)
        with self.assertRaises(DataUnavailable):analyze(c[:-60],60,paper(),onchain=network())
        with self.assertRaises(DataUnavailable):analyze(c,120,paper(),onchain=network())
        with self.assertRaises(DataUnavailable):analyze(c,60,paper(),onchain=network(),timestamp=c[-1]['time']+60)
        with self.assertRaises(DataUnavailable):analyze(c,60,paper(),onchain=network(),timestamp=c[-1]['time']+9*3600)

    def test_existing_position_cannot_open_another(self):
        acc=paper();acc['positions']=[{'id':1,'qty':0.001}]
        r=analyze(current_candles(60),60,acc,onchain=network())
        self.assertIn(r['verdict'],{'MANAGE_OPEN_POSITION','REVIEW_EXIT'})
        self.assertNotEqual(r['verdict'],'CONDITIONAL_BUY')

    def test_invalid_network_values_marked_unavailable(self):
        n=network();n['rates']['fastestFee']=float('nan')
        r=analyze(current_candles(60),60,paper(),onchain=n)
        self.assertEqual(r['verdict'],'WAIT')
        self.assertEqual(r['fundamental']['coverage'],'NO_LIVE_FUNDAMENTALS')

    def test_save_once_reload_with_unchanged_account(self):
        r=analyze(current_candles(60),60,paper(),onchain=network())
        with connect(self.path) as db:
            record(db,r);record(db,r)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_brain_reports').fetchone()[0],1)
            self.assertEqual(history(db,60)['reports'][0]['verdict'],r['verdict'])
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)
            self.assertEqual(float(db.execute('SELECT cash FROM btc_paper_account WHERE id=1').fetchone()[0]),5000)
        again=TestClient(create_app(self.path))
        self.assertEqual(again.get('/health').status_code,200)
        again.close()
        with connect(self.path) as db:self.assertEqual(len(history(db,60)['reports']),1)

    def test_web_auth_csrf_rate_limit_and_zero_trades(self):
        self.assertEqual(TestClient(self.app).get('/api/btc/brain/knowledge').status_code,401)
        self.assertEqual(TestClient(self.app).get('/api/btc/brain/history').status_code,401)
        self.assertEqual(TestClient(self.app).post('/api/btc/brain/analyze',json={'timeframe':60}).status_code,401)
        self.assertEqual(self.client.post('/api/btc/brain/analyze',json={'timeframe':60}).status_code,403)
        with patch('app.fetch_recent_btc',return_value=current_candles(60)) as feed, patch('app.btc_brain.fetch_onchain',return_value=network()) as chain:
            rr=self.client.post('/api/btc/brain/analyze',json={'timeframe':60},headers=self.csrf)
            self.assertEqual(rr.status_code,200,rr.text)
            self.assertIn(rr.json()['verdict'],{'WAIT','CONDITIONAL_BUY'})
            self.assertEqual(self.client.post('/api/btc/brain/analyze',json={'timeframe':60},headers=self.csrf).status_code,429)
            feed.assert_called_once_with(60);chain.assert_called_once()
        h=self.client.get('/api/btc/brain/history?timeframe=60')
        self.assertEqual(h.status_code,200)
        self.assertEqual(len(h.json()['reports']),1)
        self.assertEqual(self.client.get('/api/btc/brain/history?timeframe=16').status_code,422)
        with connect(self.path) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)

    def test_failed_market_fetch_writes_no_fabricated_report(self):
        with patch('app.fetch_recent_btc',side_effect=DataUnavailable('Kraken insufficient completed candles')) as feed:
            a=self.client.post('/api/btc/brain/analyze',json={'timeframe':15},headers=self.csrf)
            self.assertEqual(a.status_code,503)
            self.assertIn('insufficient',a.json()['detail'])
        with connect(self.path) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_brain_reports').fetchone()[0],0)

    def test_web_rate_limit_is_durable_across_app_restart(self):
        with patch('app.fetch_recent_btc',return_value=current_candles(60)),patch('app.btc_brain.fetch_onchain',return_value=network()):
            self.assertEqual(self.client.post('/api/btc/brain/analyze',json={'timeframe':60},headers=self.csrf).status_code,200)
        self.client.close()
        self.client=TestClient(create_app(self.path))
        login=self.client.post('/api/auth/login',json={'username':'admin','password':'long-valid-test-password'})
        self.assertEqual(login.status_code,200)
        h={'X-CSRF-Token':login.json()['csrf']}
        self.assertEqual(self.client.post('/api/btc/brain/analyze',json={'timeframe':60},headers=h).status_code,429)

if __name__=='__main__':unittest.main()
