"""Deployment/persistence/feed tests run offline; third-party market calls are mocked."""
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from datetime import date
from io import BytesIO

os.environ.setdefault('ALGO_DB_PATH', str(Path(tempfile.gettempdir())/'algo-trader-test-import.sqlite3'))
from fastapi.testclient import TestClient
from app import create_app
from market_data import DataUnavailable, read_eod


class Stage2Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name)/'store.sqlite3'
        self.env = patch.dict(os.environ, {
            'ALGO_REQUIRE_ADMIN': '1',
            'ALGO_BOOTSTRAP_USERNAME': 'admin',
            'ALGO_BOOTSTRAP_PASSWORD': 'test-only-long-secret-2026',
            'ALGO_MARKET_DATA_ENABLED': '1',
        })
        self.env.start()
        self.client = TestClient(create_app(self.db))
        login = self.client.post('/api/auth/login', json={
            'username':'admin','password':'test-only-long-secret-2026'})
        self.assertEqual(login.status_code, 200, login.text)
        self.headers = {'X-CSRF-Token': login.json()['csrf']}

    def tearDown(self):
        self.client.close()
        self.env.stop()
        self.tmp.cleanup()

    def test_cold_start_requires_admin_and_no_default(self):
        other = Path(self.tmp.name)/'new.sqlite3'
        with patch.dict(os.environ, {'ALGO_REQUIRE_ADMIN': '1'}, clear=True):
            with self.assertRaisesRegex(RuntimeError,'No administrator configured'):
                create_app(other)

    def test_admin_and_paper_ledger_persist_across_app_restarts(self):
        self.assertEqual(self.client.post('/api/watchlist', json={'symbol':'MSFT'}, headers=self.headers).status_code,200)
        self.assertEqual(self.client.post('/api/trades/open', json={'symbol':'MSFT','qty':2,'entry_price':100,'stop_price':98,'target_price':102}, headers=self.headers).status_code,200)
        self.client.close()
        with patch.dict(os.environ, {'ALGO_BOOTSTRAP_PASSWORD':'new-but-should-not-reset-password'}):
            restarted = TestClient(create_app(self.db))
            old_login = restarted.post('/api/auth/login', json={'username':'admin','password':'test-only-long-secret-2026'})
            self.assertEqual(old_login.status_code,200)
            new_login = restarted.post('/api/auth/login', json={'username':'admin','password':'new-but-should-not-reset-password'})
            self.assertEqual(new_login.status_code,401)
            view = restarted.get('/api/overview')
            self.assertEqual(view.status_code,200)
            self.assertEqual(view.json()['positions'][0]['symbol'],'MSFT')
            self.assertEqual(view.json()['cash'],4800)
            self.assertEqual(view.json()['watchlist'],['MSFT'])
            restarted.close()
        self.client = TestClient(create_app(self.db))

    def test_market_status_protected_and_fetch_does_not_modify_scenarios(self):
        self.assertEqual(TestClient(create_app(self.db)).get('/api/market/status').status_code,401)
        self.assertEqual(self.client.post('/api/watchlist', json={'symbol':'AAPL'},headers=self.headers).status_code,200)
        self.assertEqual(self.client.post('/api/marks',json={'symbol':'AAPL','price':100},headers=self.headers).status_code,200)
        self.assertEqual(self.client.post('/api/trades/open',json={
            'symbol':'AAPL','qty':5,'entry_price':100,'stop_price':98,'target_price':103},headers=self.headers).status_code,200)
        before=self.client.get('/api/overview').json()
        with patch('app.read_eod',return_value={'symbol':'AAPL','close':120.5,'bar_date':'2026-10-23','provider':'Stooq'}) as fake:
            missing_csrf=self.client.post('/api/market/refresh',json={})
            self.assertEqual(missing_csrf.status_code,403)
            first=self.client.post('/api/market/refresh',json={},headers=self.headers)
            self.assertEqual(first.status_code,200, first.text)
            self.assertEqual(first.json()['updated'],['AAPL'])
            second=self.client.post('/api/market/refresh',json={},headers=self.headers)
            self.assertEqual(second.status_code,200)
            self.assertEqual(second.json()['cached'],['AAPL'])
            self.assertEqual(fake.call_count,1)
        status=self.client.get('/api/market/status').json()
        self.assertEqual(status['quotes'][0]['price'],120.5)
        self.assertEqual(status['quotes'][0]['bar_date'],'2026-10-23')
        after=self.client.get('/api/overview').json()
        self.assertEqual(after['cash'],before['cash'])
        self.assertEqual(after['equity'],before['equity'])
        self.assertEqual(after['positions'],before['positions'])
        self.assertEqual(after['marks'],before['marks'])

    def test_feed_error_does_not_corrupt_cache_or_paper_ledger(self):
        self.client.post('/api/watchlist',json={'symbol':'TSLA'},headers=self.headers)
        with patch('app.read_eod',side_effect=DataUnavailable('No valid daily bars for symbol')):
            r=self.client.post('/api/market/refresh',json={},headers=self.headers)
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['updated'],[])
        self.assertEqual(r.json()['errors'][0]['symbol'],'TSLA')
        self.assertEqual(self.client.get('/api/overview').json()['equity'],5000)

    def test_feed_opt_in_and_health(self):
        self.assertEqual(self.client.get('/health').status_code,200)
        with patch.dict(os.environ, {'ALGO_MARKET_DATA_ENABLED':'0'}):
            self.assertFalse(self.client.get('/api/market/status').json()['enabled'])
            self.assertEqual(self.client.post('/api/market/refresh',json={},headers=self.headers).status_code,503)

    def test_configured_public_origin_check(self):
        with patch.dict(os.environ, {'ALGO_PUBLIC_ORIGIN':'https://example.onrender.com'}):
            bad = self.client.post('/api/watchlist',json={'symbol':'TSLA'},headers={**self.headers,'Origin':'https://evil.example'})
            good=self.client.post('/api/watchlist',json={'symbol':'TSLA'},headers={**self.headers,'Origin':'https://example.onrender.com'})
            self.assertEqual(bad.status_code,403)
            self.assertEqual(good.status_code,200)


class StooqParserTests(unittest.TestCase):
    def test_date_and_highest_close_only_valid_rows(self):
        class FakeResponse:
            def __init__(self,contents):self.buf=BytesIO(contents)
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):return self.buf.read(n)
            def geturl(self):return 'https://stooq.com/q/d/l/?s=aapl.us&i=d'
        csv_data=b'Date,Open,High,Low,Close,Volume\n2026-10-22,100,105,98,104,1000\n2026-10-23,104,106,101,105.5,1000\n'
        with patch('market_data.build_opener') as opener:
            opener.return_value.open.return_value=FakeResponse(csv_data)
            res=read_eod('AAPL',today=date(2026,10,25))
        self.assertEqual(res['close'],105.5)
        self.assertEqual(res['bar_date'],'2026-10-23')
        self.assertIn('s=aapl.us',opener.return_value.open.call_args.args[0].full_url)

    def test_no_valid_quote_and_symbol_fail_closed(self):
        with self.assertRaises(DataUnavailable):
            read_eod('https://evil.example')
        class Bad:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):return b'No data'
            def geturl(self):return 'https://stooq.com/q/d/l/?s=tsla.us'
        with patch('market_data.build_opener') as opener:
            opener.return_value.open.return_value=Bad()
            with self.assertRaises(DataUnavailable):
                read_eod('TSLA',today=date(2026,10,25))

    def test_redirect_to_unexpected_host_rejected(self):
        class Redirected:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def geturl(self):return 'https://evil.example/query'
        with patch('market_data.build_opener') as opener:
            opener.return_value.open.return_value=Redirected()
            with self.assertRaisesRegex(DataUnavailable,'unexpected host'):
                read_eod('AAPL')


if __name__ == '__main__':
    unittest.main()
