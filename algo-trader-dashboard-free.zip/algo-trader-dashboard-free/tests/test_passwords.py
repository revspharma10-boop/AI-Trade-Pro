import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('ALGO_DB_PATH', str(Path(tempfile.gettempdir())/'algo-pw-import.sqlite3'))
from fastapi.testclient import TestClient
from app import create_app

RECOVERY='demonstration-recovery-key-at-least-32-characters-long'
OLD='initial-safety-password-2026'
NEW='very-new-safe-password-2026'

class PasswordTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.p=patch.dict(os.environ,{'ALGO_REQUIRE_ADMIN':'1','ALGO_BOOTSTRAP_PASSWORD':OLD,
                 'ALGO_BOOTSTRAP_USERNAME':'admin','ALGO_RECOVERY_KEY':RECOVERY})
        self.p.start()
        self.client=TestClient(create_app(Path(self.t.name)/'test.sqlite3'))
        self.login=self.client.post('/api/auth/login',json={'username':'admin','password':OLD})
        self.assertEqual(self.login.status_code,200)
        self.csrf=self.login.json()['csrf']
    def tearDown(self):
        self.client.close();self.p.stop();self.t.cleanup()
    def test_change_requires_current_and_csrf(self):
        p={'current_password':OLD,'new_password':NEW}
        self.assertEqual(self.client.post('/api/auth/change-password',json=p).status_code,403)
        self.assertEqual(self.client.post('/api/auth/change-password',json={**p,'current_password':'no'},headers={'x-csrf-token':self.csrf}).status_code,401)
        self.assertEqual(self.client.post('/api/auth/change-password',json=p,headers={'x-csrf-token':self.csrf}).status_code,200)
        self.assertEqual(self.client.get('/api/overview').status_code,401)
        self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':OLD}).status_code,401)
        self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':NEW}).status_code,200)
    def test_reset_rejects_wrong_key_then_revokes_sessions(self):
        p={'username':'admin','recovery_key':'incorrect','new_password':NEW}
        self.assertEqual(self.client.post('/api/auth/reset-password',json=p).status_code,401)
        self.assertEqual(self.client.post('/api/auth/reset-password',json={**p,'recovery_key':RECOVERY}).status_code,200)
        self.assertEqual(self.client.get('/api/overview').status_code,401)
        self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':OLD}).status_code,401)
        self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':NEW}).status_code,200)
    def test_reset_unknown_username_and_origin(self):
        p={'username':'absent','recovery_key':RECOVERY,'new_password':NEW}
        self.assertEqual(self.client.post('/api/auth/reset-password',json=p).status_code,401)
        self.assertEqual(self.client.post('/api/auth/reset-password',json={**p,'username':'admin'},headers={'Origin':'https://attacker.example'}).status_code,403)
    def test_reset_without_recovery_configuration(self):
        with patch.dict(os.environ,{'ALGO_RECOVERY_KEY':''}):
            response=self.client.post('/api/auth/reset-password',json={'username':'admin','recovery_key':RECOVERY,'new_password':NEW})
            self.assertEqual(response.status_code,401)
    def test_reset_rate_limiting(self):
        p={'username':'admin','recovery_key':'incorrect','new_password':NEW}
        for _ in range(5):
            self.assertEqual(self.client.post('/api/auth/reset-password',json=p).status_code,401)
        self.assertEqual(self.client.post('/api/auth/reset-password',json={**p,'recovery_key':RECOVERY}).status_code,429)
    def test_change_password_minimum_length(self):
        self.assertEqual(self.client.post('/api/auth/change-password',json={'current_password':OLD,'new_password':'weak'},headers={'x-csrf-token':self.csrf}).status_code,422)

if __name__=='__main__':unittest.main()
