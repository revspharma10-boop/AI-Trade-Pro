import os
from pathlib import Path
import tempfile
import unittest

# Avoid writing default app startup data to the user's regular dashboard store.
_temp_import = tempfile.TemporaryDirectory()
os.environ["ALGO_DB_PATH"] = str(Path(_temp_import.name) / "module.sqlite3")
from fastapi.testclient import TestClient
from app import bootstrap_user, create_app


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "test.sqlite3"
        self.app = create_app(self.db)
        bootstrap_user(self.db, "admin", "correct-horse-12345")
        self.client = TestClient(self.app)
        r = self.client.post("/api/auth/login", json={"username":"admin", "password":"correct-horse-12345"})
        self.assertEqual(r.status_code, 200, r.text)
        self.csrf = r.json()["csrf"]
        self.headers = {"X-CSRF-Token": self.csrf}

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def post(self, route, data):
        return self.client.post(route, json=data, headers=self.headers)

    def snapshot(self):
        response = self.client.get("/api/overview")
        self.assertEqual(response.status_code, 200)
        return response.json()

    def test_login_requires_credentials_and_csrf(self):
        other = TestClient(self.app)
        self.assertEqual(other.get("/api/overview").status_code, 401)
        self.assertEqual(other.post("/api/auth/login", json={"username":"admin", "password":"wrong"}).status_code, 401)
        self.assertEqual(self.client.post("/api/watchlist", json={"symbol":"AAPL"}).status_code,403)
        self.assertEqual(self.client.post("/api/watchlist", json={"symbol":"AAPL"},headers={**self.headers,"Origin":"https://evil.example"}).status_code,403)
        other.close()

    def test_no_default_or_duplicate_admin(self):
        with self.assertRaises(ValueError):
            bootstrap_user(self.db, "admin2", "correct-horse-12345")

    def test_paper_trade_buy_close_pnl_ledger(self):
        r=self.post("/api/trades/open", {"symbol":"aapl","qty":10,"entry_price":100,"stop_price":98,"target_price":105})
        self.assertEqual(r.status_code,200,r.text)
        trade_id = r.json()["trade_id"]
        self.assertTrue(r.json()["simulated"])
        self.assertEqual(self.snapshot()["cash"],4000)
        self.assertEqual(self.snapshot()["equity"],5000)
        r=self.post("/api/marks",{"symbol":"AAPL","price":108})
        self.assertEqual(r.status_code,200)
        self.assertEqual(self.snapshot()["equity"],5080)
        r=self.post(f"/api/trades/{trade_id}/close", {"exit_price":96})
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()["pnl"],-40)
        self.assertEqual(self.snapshot()["cash"],4960)
        self.assertEqual(self.snapshot()["loss_today"],40)
        self.assertEqual(self.snapshot()["positions"],[])
        self.assertEqual(self.post(f"/api/trades/{trade_id}/close", {"exit_price":96}).status_code,404)

    def test_invalid_trade_stop_target_risk_cash_and_duplicate(self):
        base={"symbol":"MSFT","qty":10,"entry_price":100,"stop_price":98,"target_price":102}
        for changes in [
            {"stop_price":101},
            {"target_price":99},
            {"qty":0},
            {"qty":100},
            {"entry_price": -4},
            {"stop_price": 90},
            {"target_price": 100.5},
            {"qty":50}
        ]:
            data={**base,**changes}
            result=self.post("/api/trades/open", data)
            self.assertEqual(result.status_code,422, (changes,result.text))
        r=self.post("/api/trades/open",base)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(self.post("/api/trades/open",base).status_code,422)
        self.assertEqual(self.snapshot()["entries_today"],1)

    def test_max_three_entries_per_utc_day(self):
        for symbol in ['AAA','BBB','CCC']:
            r=self.post("/api/trades/open",{"symbol":symbol,"qty":1,"entry_price":100,"stop_price":99,"target_price":101})
            self.assertEqual(r.status_code,200,r.text)
        r=self.post("/api/trades/open",{"symbol":"DDD","qty":1,"entry_price":100,"stop_price":99,"target_price":101})
        self.assertEqual(r.status_code,422,r.text)
        self.assertIn('Daily entry limit',r.text)

    def test_watchlist_validation_and_scenario_marks(self):
        self.assertEqual(self.post('/api/watchlist',{'symbol':'BRK.B'}).status_code,200)
        self.assertEqual(self.post('/api/watchlist',{'symbol':'BAD/../../'}).status_code,422)
        self.assertEqual(self.post('/api/marks',{'symbol':'BRK.B','price':225}).status_code,200)
        self.assertIn('BRK.B',self.snapshot()['watchlist'])
        self.assertEqual(self.client.delete('/api/watchlist/BRK.B',headers=self.headers).status_code,200)
        self.assertNotIn('BRK.B',self.snapshot()['watchlist'])

    def test_scanner_missing_checkout_no_external_actions(self):
        old = os.environ.pop('ALGO_SKILLS_PATH', None)
        try:
            status=self.client.get('/api/scanner/status')
            self.assertEqual(status.status_code,200)
            self.assertEqual(status.json()['mode'],'OFFLINE_REPLAY_ONLY')
            self.assertFalse(status.json()['ready'])
            self.assertEqual(self.post('/api/scanner/replay',{}).status_code,503)
        finally:
            if old is not None:os.environ['ALGO_SKILLS_PATH']=old

    def test_logout_revokes_cookie(self):
        self.assertEqual(self.post('/api/auth/logout',{}).status_code,200)
        self.assertEqual(self.client.get('/api/overview').status_code,401)


if __name__ == '__main__': unittest.main()
