"""BTC predictions must be timestamped, persistent, and never use future candles."""
from __future__ import annotations
import os, tempfile, time, unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from app import create_app, bootstrap_user
from btc_prediction import calculate, persist_and_score, history
from btc_lab import DataUnavailable
from database import connect
from test_btc_signals import current_candles


def candles_at(now=None, timeframe=60):
    bars=current_candles(timeframe)
    # Last completed candle. Clock source already near the current time.
    return bars


def account():
    return {'cash':5000.0,'equity':5000.0,'positions':[],
            'entries_today':0,'loss_today':0.0,'planned_open_risk':0.0}


class Predictions(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'prediction.sqlite3'
        self.app=create_app(self.path)
        bootstrap_user(self.path,'admin','strong-unique-test-secret')
        self.client=TestClient(self.app)
        login=self.client.post('/api/auth/login',json={'username':'admin','password':'strong-unique-test-secret'})
        self.assertEqual(login.status_code,200)
        self.csrf={'X-CSRF-Token':login.json()['csrf']}

    def tearDown(self):
        self.client.close();self.temp.cleanup()

    def test_directional_hypothesis_is_not_guaranteed_probability(self):
        c=candles_at()
        d=calculate(c,60,account())
        self.assertEqual(d['pair'],'BTC/USD')
        self.assertIn(d['bias'],{'UP_BIAS','DOWN_BIAS','NO_EDGE'})
        self.assertLess(d['volatility_low_usd'],d['reference_close_usd'])
        self.assertGreater(d['volatility_high_usd'],d['reference_close_usd'])
        self.assertEqual(d['prediction_horizon_candles'],3)
        self.assertFalse(d['paper_execution_enabled'])
        self.assertFalse(d['real_order_execution_enabled'])
        self.assertIsNone(d['realized_close_usd'])
        self.assertIn('NOT calibrated',d['warning'])

    def test_stale_future_wrong_timeframe_fail_closed(self):
        c=candles_at()
        with self.assertRaises(DataUnavailable):calculate(c,2,account())
        with self.assertRaises(DataUnavailable):calculate(c,60,account(),timestamp=c[-1]['time']+30)
        with self.assertRaises(DataUnavailable):calculate(c,60,account(),timestamp=c[-1]['time']+10*3600)
        with self.assertRaises(DataUnavailable):calculate(c[:10],60,account())

    def test_prediction_and_candles_are_cloud_ready_and_idempotent(self):
        c=candles_at();pred=calculate(c,60,account())
        with connect(self.path) as db:
            first=persist_and_score(db,c,pred)
            second=persist_and_score(db,c,pred)
            self.assertEqual(first['predictions'],second['predictions'])
            self.assertEqual(first['stored_completed_candles'],120)
            self.assertEqual(len(first['predictions']),1)
            self.assertEqual(first['predictions'][0]['status'],'PENDING')
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_market_candles').fetchone()[0],120)
        self.client.close();self.client=TestClient(create_app(self.path))
        with connect(self.path) as db:
            self.assertEqual(len(history(db,60)['predictions']),1)
            self.assertEqual(db.execute('SELECT cash FROM btc_paper_account WHERE id=1').fetchone()[0],5000)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)

    def test_only_score_when_true_future_completed_candle_arrives(self):
        c=candles_at();dt=3600
        with connect(self.path) as db:
            p=calculate(c,60,account(),timestamp=c[-1]['time']+dt+1)
            persist_and_score(db,c,p)
            self.assertIsNone(history(db,60)['predictions'][0]['realized_close'])
            # A prediction at the last candle is not scored from the newest available close.
            # Three NEW fully completed candles must be supplied in a later fetch.
            ext=list(c)
            for i in range(1,4):
                prev=ext[-1];price=prev['close']*(1+.001*i)
                ext.append({'time':prev['time']+dt,'open':prev['close'],
                    'high':price*1.005,'low':prev['close']*.995,'close':price})
            later=calculate(ext[-719:],60,account(),timestamp=ext[-1]['time']+dt+1)
            updated=persist_and_score(db,ext[-719:],later,timestamp=ext[-1]['time']+dt+1)
            old=next(x for x in updated['predictions'] if x['candle_time']==c[-1]['time'])
            self.assertEqual(old['status'],'SCORED')
            self.assertAlmostEqual(old['realized_close'],ext[-1]['close'],places=3)
            self.assertIsNotNone(old['realized_move_pct'])
            self.assertIsNone(updated['direction_accuracy_pct'] if old['bias']=='NO_EDGE' else None)

    def test_missing_exact_outcome_bar_remains_unscored(self):
        c=candles_at();now=int(time.time())
        with connect(self.path) as db:
            p=calculate(c,60,account())
            persist_and_score(db,c,p)
            # Skip the exact three-candle-outcome bar, then insert a later one.
            dt=3600;last=c[-1];new=list(c)
            for i in (1,2,4):
                new.append({'time':last['time']+i*dt,'open':last['close'],
                            'high':last['high'],'low':last['low'],'close':last['close']})
            # Do not permit an erroneously substituted newest price if outcome timestamp missing.
            newer=calculate(new,60,account(),timestamp=last['time']+5*dt+1)
            persist_and_score(db,new,newer,timestamp=last['time']+5*dt+1)
            orig=next(x for x in history(db,60)['predictions'] if x['candle_time']==last['time'])
            self.assertEqual(orig['status'],'PENDING')

    def test_web_auth_csrf_limiter_and_not_an_order(self):
        self.assertEqual(TestClient(self.app).get('/api/btc/predictions/history').status_code,401)
        self.assertEqual(TestClient(self.app).post('/api/btc/predictions/pull',json={'timeframe':60}).status_code,401)
        self.assertEqual(self.client.post('/api/btc/predictions/pull',json={'timeframe':60}).status_code,403)
        before=self.client.get('/api/btc/paper/portfolio').json()
        with patch('app.fetch_recent_btc',return_value=candles_at()) as fn:
            res=self.client.post('/api/btc/predictions/pull',json={'timeframe':60},headers=self.csrf)
            self.assertEqual(res.status_code,200,res.text)
            self.assertEqual(res.json()['stored_completed_candles'],120)
            self.assertEqual(self.client.post('/api/btc/predictions/pull',json={'timeframe':60},headers=self.csrf).status_code,429)
            fn.assert_called_once_with(60)
        hist=self.client.get('/api/btc/predictions/history?timeframe=60')
        self.assertEqual(hist.status_code,200,hist.text)
        self.assertEqual(len(hist.json()['predictions']),1)
        after=self.client.get('/api/btc/paper/portfolio').json()
        self.assertEqual(before['cash'],after['cash'])
        self.assertEqual(before['positions'],after['positions'])
        with connect(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)
        self.assertEqual(self.client.get('/api/btc/predictions/history?timeframe=7').status_code,422)

    def test_invalid_source_never_persists(self):
        c=candles_at();d=calculate(c,60,account())
        with connect(self.path) as db:
            with self.assertRaises(DataUnavailable):persist_and_score(db,c[:-1],d)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_predictions').fetchone()[0],0)

if __name__=='__main__':unittest.main()
