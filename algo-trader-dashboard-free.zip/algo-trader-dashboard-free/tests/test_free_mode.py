import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault("ALGO_DB_PATH", str(Path(tempfile.gettempdir()) / "algo-free-import-test.sqlite3"))
from fastapi.testclient import TestClient
from app import create_app

class FreeModeTests(unittest.TestCase):
    def test_demo_flag_and_paper_only(self):
        with tempfile.TemporaryDirectory() as td:
            with patch.dict(os.environ, {"ALGO_FREE_DEMO": "1"}):
                with TestClient(create_app(Path(td) / "demo.sqlite3")) as client:
                    result=client.get("/api/deployment")
                    self.assertEqual(result.status_code, 200)
                    self.assertEqual(result.json(), {"free_demo": True, "paper_only": True})
            with patch.dict(os.environ, {"ALGO_FREE_DEMO": "0"}):
                with TestClient(create_app(Path(td) / "local.sqlite3")) as client:
                    self.assertEqual(client.get("/api/deployment").json(), {"free_demo": False, "paper_only": True})

    def test_blueprint_has_no_billable_disk(self):
        manifest=(Path(__file__).resolve().parents[1] / "render.yaml").read_text()
        self.assertIn("plan: free", manifest)
        self.assertNotIn("sizeGB:", manifest)
        self.assertNotIn("plan: starter", manifest)
        self.assertIn("/tmp/algo-trader-free-demo.sqlite3", manifest)

if __name__ == "__main__":
    unittest.main()
