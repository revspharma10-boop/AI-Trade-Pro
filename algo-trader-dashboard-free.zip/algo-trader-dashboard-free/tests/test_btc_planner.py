"""No live network, no real trading: conditional BTC entry/exit research only."""
from __future__ import annotations
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from app import create_app, bootstrap_user
from btc_planner import plan
from btc_lab import DataUnavailable
from btc_paper import _plan, LIMITS, portfolio
from database import connect
from test_btc_signals import current_candles


def account():
    return {'cash':5000,'equity':5000,'positions':[],'entries_today':0,'loss_today':0,'planned_open_risk':0}


def rising_candles(interval=60):
    candles=current_candles(interval)
    p=50000.
    for candle in candles:
        old=p;p*=1.005
        candle.update(open=old,close=p,high=p*1.002,low=old*.998)
    return candles


class PlannerTests(unittest.TestCase):
    def test_conditional_setup_and_risk_limits(self):
        report=plan(rising_candles(),60,account())
        self.assertEqual(report['state'],'CONDITIONAL_LONG')
        self.assertEqual(report['strategies_checked'],6)
        self.assertGreaterEqual(report['bullish_strategies'],4)
        self.assertLess(report['stop_loss_usd'],report['entry_trigger_usd'])
        self.assertLess(report['entry_trigger_usd'],report['target_1_usd'])
        self.assertLess(report['target_1_usd'],report['target_2_usd'])
        self.assertGreaterEqual(report['reward_risk_target_1'],1.5)
        self.assertLessEqual(report['estimated_stop_risk_usd'],50)
        self.assertLessEqual(report['estimated_notional_usd'],2500)
        self.assertFalse(report['paper_execution_enabled'])
        self.assertFalse(report['real_order_execution_enabled'])
        self.assertIsNone(report['certainty_pct'])
        self.assertIn('conditional',report['state'].lower())
        from types import SimpleNamespace
        _,_,_,_,notional,_,risk=_plan(SimpleNamespace(qty=report['max_paper_btc_qty'],
              entry_price=report['entry_trigger_usd'], stop_price=report['stop_loss_usd'],target_price=report['target_1_usd']))
        self.assertEqual(float(notional),report['estimated_notional_usd'])
        self.assertEqual(float(risk),report['estimated_stop_risk_usd'])

    def test_weak_conflicting_signals_mean_wait_not_predictions(self):
        report=plan(current_candles(),60,account())
        self.assertEqual(report['state'],'WAIT')
        self.assertIsNone(report['entry_trigger_usd'])
        self.assertIsNone(report['stop_loss_usd'])
        self.assertIsNone(report['max_paper_btc_qty'])

    def test_open_position_blocks_second_proposal(self):
        a=account();a['positions']=[{'qty':.005,'entry_price':70000,'stop_price':68000,'target_price':75000}]
        r=plan(rising_candles(),60,a)
        self.assertEqual(r['state'],'WAIT')
        self.assertIn('position already open',r['reason'])

    def test_daily_entries_exhaustion(self):
        a=account();a['entries_today']=3
        self.assertEqual(plan(rising_candles(),60,a)['state'],'WAIT')

    def test_remaining_daily_budget(self):
        a=account();a['loss_today']=149.99
        self.assertEqual(plan(rising_candles(),60,a)['state'],'WAIT')

    def test_stale_and_incomplete_candles_fail_closed(self):
        c=rising_candles()
        with self.assertRaises(DataUnavailable):plan(c,60,account(),timestamp=c[-1]['time']+90)
        with self.assertRaises(DataUnavailable):plan(c,60,account(),timestamp=c[-1]['time']+3*3600)
        with self.assertRaises(DataUnavailable):plan(c,7,account())
        with self.assertRaises(DataUnavailable):plan(c[:10],60,account())

    def test_no_lookahead_sensitivity(self):
        c=rising_candles()
        report=plan(c,60,account())
        # Future candle is not supplied. Change earlier data outside the ATR and breakout windows;
        # levels should not be fabricated from the unfinished bar or future prices.
        self.assertLess(int(time.time()),int(__import__('datetime').datetime.fromisoformat(report['setup_expires_utc']).timestamp()))
        self.assertIn('Kraken completed',report['source'])

    def test_api_auth_csrf_throttle_no_orders(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'db.sqlite3'
            app=create_app(path)
            bootstrap_user(path,'admin','very-long-secret-for-tests')
            with TestClient(app) as c:
                self.assertEqual(c.post('/api/btc/plan',json={'timeframe':60}).status_code,401)
                login=c.post('/api/auth/login',json={'username':'admin','password':'very-long-secret-for-tests'})
                self.assertEqual(login.status_code,200)
                csrf={'X-CSRF-Token':login.json()['csrf']}
                self.assertEqual(c.post('/api/btc/plan',json={'timeframe':60}).status_code,403)
                self.assertEqual(c.post('/api/btc/plan',json={'timeframe':2},headers=csrf).status_code,422)
                before=c.get('/api/btc/paper/portfolio').json()
                with patch('app.fetch_recent_btc',return_value=rising_candles()) as get:
                    r=c.post('/api/btc/plan',json={'timeframe':60},headers=csrf)
                    self.assertEqual(r.status_code,200,r.text)
                    self.assertEqual(r.json()['state'],'CONDITIONAL_LONG')
                    self.assertFalse(r.json()['paper_execution_enabled'])
                    self.assertEqual(c.post('/api/btc/plan',json={'timeframe':60},headers=csrf).status_code,429)
                    get.assert_called_once_with(60)
                after=c.get('/api/btc/paper/portfolio').json()
                for key in ['cash','equity','positions','closed_trades','loss_today']:
                    self.assertEqual(before[key],after[key],key)
                with connect(path) as db:
                    self.assertEqual(db.execute('SELECT COUNT(*) FROM btc_paper_trades').fetchone()[0],0)

    def test_web_api_refuses_provider_stale_data(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'db.sqlite3'
            app=create_app(path)
            bootstrap_user(path,'admin','very-long-secret-for-tests')
            with TestClient(app) as c:
                l=c.post('/api/auth/login',json={'username':'admin','password':'very-long-secret-for-tests'}).json()
                with patch('app.fetch_recent_btc',return_value=current_candles()):
                    resp=c.post('/api/btc/plan',headers={'X-CSRF-Token':l['csrf']},json={'timeframe':240})
                self.assertEqual(resp.status_code,503)
                self.assertEqual(c.get('/api/btc/paper/portfolio').json()['cash'],5000)


if __name__=='__main__':unittest.main()
