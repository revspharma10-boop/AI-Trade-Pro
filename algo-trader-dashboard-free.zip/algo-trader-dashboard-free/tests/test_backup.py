import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('ALGO_DB_PATH', str(Path(tempfile.gettempdir())/'algo_backup_import.sqlite3'))
from app import backup_canonical, bootstrap_user, create_app
from fastapi.testclient import TestClient


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name)/'db.sqlite3'
        bootstrap_app = create_app(self.db)
        bootstrap_user(self.db,'admin','test-admin-password-5678')
        self.client = TestClient(bootstrap_app)
        login = self.client.post('/api/auth/login',json={'username':'admin','password':'test-admin-password-5678'})
        self.assertEqual(login.status_code,200,login.text)
        self.headers={'X-CSRF-Token':login.json()['csrf']}

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def post(self, route, payload):
        return self.client.post(route,headers=self.headers,json=payload)

    def restore(self,doc, headers=None):
        h={**self.headers,'X-Restore-Confirm':'REPLACE'}
        if headers:h.update(headers)
        return self.client.post('/api/backup/restore',json=doc,headers=h)

    def export(self):
        r=self.client.get('/api/backup/export')
        self.assertEqual(r.status_code,200,r.text)
        return r.json()

    def signed(self,doc):
        doc['sha256']=hashlib.sha256(backup_canonical({k:v for k,v in doc.items() if k!='sha256'})).hexdigest()
        return doc

    def test_round_trip_open_and_closed_trades(self):
        self.assertEqual(self.post('/api/watchlist', {'symbol':'NVDA'}).status_code,200)
        self.assertEqual(self.post('/api/marks', {'symbol':'AAPL','price':101}).status_code,200)
        a=self.post('/api/trades/open',{'symbol':'AAPL','qty':4,'entry_price':100,'stop_price':98,'target_price':104})
        self.assertEqual(a.status_code,200,a.text)
        b=self.post('/api/trades/open',{'symbol':'MSFT','qty':3,'entry_price':120,'stop_price':118,'target_price':125})
        self.assertEqual(b.status_code,200,b.text)
        self.assertEqual(self.post(f"/api/trades/{b.json()['trade_id']}/close",{'exit_price':123}).status_code,200)
        original=self.client.get('/api/overview').json()
        doc=self.export()
        self.assertEqual(doc['account_cash'],original['cash'])
        self.assertEqual(len(doc['trades']),2)
        self.assertNotIn('password',json.dumps(doc).lower())
        self.assertNotIn('csrf',json.dumps(doc).lower())
        self.assertNotIn('salt',json.dumps(doc).lower())
        self.assertNotIn('token_hash',json.dumps(doc).lower())
        self.assertIn('attachment;',self.client.get('/api/backup/export').headers['content-disposition'])
        self.assertEqual(self.post('/api/watchlist',{'symbol':'TSLA'}).status_code,200)
        self.assertEqual(self.post('/api/marks',{'symbol':'NVDA','price':99}).status_code,200)
        r=self.restore(doc)
        self.assertEqual(r.status_code,200,r.text)
        rebuilt=self.client.get('/api/overview').json()
        self.assertEqual(rebuilt['cash'],original['cash'])
        self.assertEqual(rebuilt['equity'],original['equity'])
        self.assertEqual(rebuilt['watchlist'],original['watchlist'])
        self.assertEqual(rebuilt['marks'],original['marks'])
        self.assertEqual(rebuilt['positions'],original['positions'])
        self.assertEqual(rebuilt['closed_trades'],original['closed_trades'])
        self.assertEqual(self.client.get('/api/auth/me').status_code,200)
        # DB survives an app restart, without requiring new credentials.
        with TestClient(create_app(self.db)) as second:
            self.assertEqual(second.post('/api/auth/login',json={'username':'admin','password':'test-admin-password-5678'}).status_code,200)
            self.assertEqual(second.get('/api/overview').json()['cash'],original['cash'])

    def test_guest_csrf_confirmation_and_origin_rejections(self):
        doc=self.export()
        guest=TestClient(self.client.app)
        self.assertEqual(guest.get('/api/backup/export').status_code,401)
        self.assertEqual(guest.post('/api/backup/restore',json=doc,headers={'X-Restore-Confirm':'REPLACE'}).status_code,401)
        guest.close()
        self.assertEqual(self.client.post('/api/backup/restore',json=doc).status_code,403)
        self.assertEqual(self.client.post('/api/backup/restore',json=doc,headers=self.headers).status_code,400)
        self.assertEqual(self.restore(doc, {'Origin':'https://evil.example'}).status_code,403)
        self.assertEqual(self.restore(doc, {'Content-Type':'text/plain'}).status_code,415)

    def test_corrupt_digest_rejected_without_data_loss(self):
        self.post('/api/watchlist',{'symbol':'AAPL'})
        doc=self.export()
        broken=copy.deepcopy(doc);broken['watchlist']=['BAD']
        response=self.restore(broken)
        self.assertEqual(response.status_code,422,response.text)
        self.assertIn('checksum',response.text)
        self.assertEqual(self.client.get('/api/overview').json()['watchlist'],['AAPL'])

    def test_reconciled_cash_and_pnl_rejected(self):
        a=self.post('/api/trades/open',{'symbol':'MSFT','qty':2,'entry_price':100,'stop_price':98,'target_price':104})
        self.post(f"/api/trades/{a.json()['trade_id']}/close",{'exit_price':101})
        doc=self.export()
        for adjustment in (
            lambda d: d.update(account_cash=50000.0),
            lambda d: d['trades'][0].update(pnl=999999.0),
            lambda d: d['trades'][0].update(entry_price=-3.0),
            lambda d: d['trades'][0].update(status='OPEN'),
            lambda d: d['trades'][0].update(symbol='INVALID.HTML'),
            lambda d: d['trades'][0].update(closed_at='2010-01-01T00:00:00+00:00'),
        ):
            broken=copy.deepcopy(doc)
            adjustment(broken)
            r=self.restore(self.signed(broken))
            self.assertEqual(r.status_code,422,r.text)
        self.assertEqual(self.client.get('/api/overview').json()['cash'],doc['account_cash'])

    def test_unsupported_and_oversized_and_malformed(self):
        doc=self.export()
        broken=copy.deepcopy(doc);broken['version']=2
        r=self.restore(self.signed(broken))
        self.assertEqual(r.status_code,422)
        r=self.client.post('/api/backup/restore',data='{'+' '*2100000,headers={**self.headers,'Content-Type':'application/json','X-Restore-Confirm':'REPLACE'})
        self.assertEqual(r.status_code,413)
        r=self.client.post('/api/backup/restore',data='garbage',headers={**self.headers,'Content-Type':'application/json','X-Restore-Confirm':'REPLACE'})
        self.assertEqual(r.status_code,422)

    def test_empty_backup_replaces_records_but_keeps_login(self):
        initial=self.export()
        self.post('/api/watchlist',{'symbol':'GOOGL'})
        self.assertEqual(self.restore(initial).status_code,200)
        self.assertEqual(self.client.get('/api/overview').json()['watchlist'],[])
        self.assertEqual(self.client.get('/api/auth/me').status_code,200)

if __name__ == '__main__':unittest.main()
