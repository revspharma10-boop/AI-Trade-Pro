#!/usr/bin/env bash
set -Eeuo pipefail

# Creates a PRIVATE, dedicated GitHub repository for this dashboard.
# Requires an authenticated GitHub CLI; never uploads credentials or SQLite files.
# Usage: bash publish_to_github.sh [repository-name]

cd "$(dirname "$0")"
REPO_NAME="${1:-algo-trader-paper-dashboard}"
if [[ ! "$REPO_NAME" =~ ^[a-zA-Z0-9][a-zA-Z0-9._-]*$ ]]; then
  echo "Invalid GitHub repository name." >&2; exit 2
fi
if ! command -v gh >/dev/null 2>&1; then
  echo "Install GitHub CLI (gh) first: https://cli.github.com/" >&2; exit 2
fi
if ! command -v git >/dev/null 2>&1; then
  echo "Git is required." >&2; exit 2
fi
if ! gh auth status -h github.com >/dev/null 2>&1; then
  echo "Run: gh auth login" >&2; exit 2
fi
if [[ -d .git ]]; then
  echo "This folder is already a Git repository. Refusing to overwrite its history." >&2; exit 2
fi
ACCOUNT="$(gh api user --jq .login)"
if gh repo view "$ACCOUNT/$REPO_NAME" >/dev/null 2>&1; then
  echo "Repository $ACCOUNT/$REPO_NAME already exists. Refusing to overwrite." >&2; exit 2
fi
python3 -m unittest discover -s tests >/dev/null
# Explicit allowlist: never upload the database, sessions, .env or passwords.
git init -b main >/dev/null
git add .gitignore app.py market_data.py render.yaml requirements.txt run.sh \
  README.md FREE_DEPLOY.md \
  publish_to_github.sh verify_deployment.sh \
  static/index.html static/app.js static/style.css \
  tests/test_app.py tests/test_stage2.py tests/test_free_mode.py
if git diff --cached --name-only | grep -E '(^data/|^\.env$|\.sqlite3|__pycache__)'; then
  echo "Forbidden file staged. Aborting." >&2; exit 3
fi
git diff --cached --check
GIT_NAME="$(git config user.name || true)"
GIT_EMAIL="$(git config user.email || true)"
if [[ -z "$GIT_NAME" ]]; then GIT_NAME="$ACCOUNT"; fi
if [[ -z "$GIT_EMAIL" ]]; then
  ID="$(gh api user --jq .id)"
  GIT_EMAIL="${ID}+${ACCOUNT}@users.noreply.github.com"
fi
git -c user.name="$GIT_NAME" -c user.email="$GIT_EMAIL" \
  commit -m "Prepare isolated FREE paper-trading dashboard demo for Render" >/dev/null
echo "Creating private repository $ACCOUNT/$REPO_NAME..."
gh repo create "$ACCOUNT/$REPO_NAME" --private --source . --remote origin --push
printf '\nGitHub source: https://github.com/%s/%s\n' "$ACCOUNT" "$REPO_NAME"
printf 'Next: https://dashboard.render.com/blueprints (New Blueprint)\n'
printf 'Select My Workspace and choose the new repository.\n'
printf 'Confirm Free plan and NO disk. Set ALGO_BOOTSTRAP_PASSWORD in Render privately.\n'
