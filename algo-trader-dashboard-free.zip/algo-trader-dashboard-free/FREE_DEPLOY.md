# Free Render deployment checklist

- [ ] Confirm *Free* service plan (not Starter) and no disk.
- [ ] Create a fresh private GitHub repository containing this free version; do not overwrite existing trading projects.
- [ ] Keep `ALGO_DB_PATH=/tmp/algo-trader-free-demo.sqlite3` and `ALGO_FREE_DEMO=1`.
- [ ] Enter the bootstrap password privately in Render, minimum 12 characters; do not commit credentials.
- [ ] Confirm all data is fictional; do not enter sensitive financial information.
- [ ] Open `/health`, then sign in as `admin`.
- [ ] Check temporary-data warning is visible on login and dashboard.
- [ ] Expect simulated trade data to reset on restarts/redeploys; use local version if you need persistence.
- [ ] Monitor workspace monthly usage and billing; Free plan does not guarantee no charges from every other resource or overage.
- [ ] No broker connections, no live orders.
