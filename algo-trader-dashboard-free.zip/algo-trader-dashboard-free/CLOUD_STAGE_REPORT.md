# Algo Trader — cloud deployment handoff (2026-10-25)

## Verified
- GitHub source repository `anushkarthik666-web/day-trader-skill` is a standalone skill pack, not this dashboard. It has read-only permissions through the linked account.
- Connected GitHub login is `revspharma10-boop`; this account can create files only in its existing authorized repositories through the connector, but the connector cannot create new GitHub repositories.
- Connected Render workspace selected by the user: `My Workspace`.
- `render.yaml` requests a paid **Starter** Python web service, Singapore region, plus a **1 GB persistent disk** mounted at `/var/data` for SQLite.
- Blueprint secrets (`ALGO_BOOTSTRAP_PASSWORD`) are requested interactively and are never included in source files.
- Automated dashboard suite: 17/17 pass locally. These are application unit tests, not a production security audit.

## Not yet done
- No new GitHub repository created or code pushed to Render's Git source.
- No new Render service/disk created; no paid changes made. The connected Render creation API does not expose disk attachment or Blueprint creation; starting a Starter web service with ephemeral SQLite would risk losing trading records.
- No public URL or external live-feed verification. Live brokerage orders remain disabled by design.

## Finish from your own GitHub/Render login
1. In this folder run `bash publish_to_github.sh`; this creates a **new private repository**, preserving the existing trading repos and their main branches. The script requires Git and GitHub CLI (`gh auth login` first). Alternatively create an empty private repo in GitHub and upload these source files without `data/` or `.env`.
2. Open https://dashboard.render.com/blueprints and select **New Blueprint**. Select the new private repo and **My Workspace**.
3. Confirm Starter, Singapore, **1 GB disk**, mount `/var/data`, and `ALGO_DB_PATH=/var/data/algo.sqlite3` before pressing Deploy.
4. Supply a new unique 12+ character `ALGO_BOOTSTRAP_PASSWORD` when prompted. Never post it in chat or commit it to GitHub. Username defaults to `admin`.
5. Once live, run `bash verify_deployment.sh https://YOUR-SERVICE.onrender.com`. Then sign in, record a small *simulated* trade, restart/redeploy, and verify it persists.
6. Establish encrypted offsite backups and restrict access to this prototype before using it for anything sensitive.

## Costs
The Render service is billable only when created by the owner. Published base pricing is ~$7/month for Starter compute and $0.25/month for 1 GB storage, plus applicable data usage/taxes. Verify the final estimate in Render before deploying.
