'use strict';
const app = { csrf: null, username: '', data: null, tab: 'overview' };
const $ = id => document.getElementById(id);
const money = v => new Intl.NumberFormat('en-US', {style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(v)||0);
const safe = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const miniDate = v => v ? new Date(v).toLocaleString() : '—';
let noticeTimer;
function notice(message, isError=false){const n=$('notification');n.textContent=message;n.classList.toggle('error',isError);n.hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>n.hidden=true,9000);}
async function api(path, method='GET', body=null){
  const headers = {'Accept':'application/json'};
  if(body !== null)headers['Content-Type']='application/json';
  if(method !== 'GET' && app.csrf)headers['X-CSRF-Token']=app.csrf;
  let resp;try{resp=await fetch(path,{method,headers,credentials:'same-origin',body:body===null?undefined:JSON.stringify(body)});}catch(e){throw Error('Cannot reach dashboard server');}
  const data=await resp.json().catch(()=>({}));
  if(!resp.ok){if(resp.status===401 && !['/api/auth/reset-password','/api/auth/change-password'].includes(path))showLogin();const detail=Array.isArray(data.detail)?data.detail.map(x=>x.msg).join('; '):data.detail;throw Error(detail||`Request failed (${resp.status})`);}
  return data;
}
function showLogin(){$('login-view').hidden=false;$('app-view').hidden=true;$('reset-form').hidden=true;$('login-form').hidden=false;app.csrf=null;}
function showApp(user){app.csrf=user.csrf;app.username=user.username;$('username-display').textContent=user.username;$('profile-avatar').textContent=user.username.charAt(0).toUpperCase();$('app-view').hidden=false;$('login-view').hidden=true;}
function table(headers,rows){if(!rows.length)return '<div class="empty">Nothing recorded yet. Enter a scenario trade to get started.</div>';return `<table><thead><tr>${headers.map(h=>`<th>${safe(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;}
function pnlClass(n){return n>0?'positive':n<0?'negative':'';}
function render(){const d=app.data;if(!d)return;
  $('stat-equity').textContent=money(d.equity);$('stat-cash').textContent=money(d.cash);$('stat-pnl').textContent=money(d.realized_today);$('stat-pnl').className=`metric-value ${pnlClass(d.realized_today)}`;$('stat-positions').textContent=d.positions.length;
  const rows=d.positions.map(p=>`<tr><td><b>${safe(p.symbol)}</b></td><td>${p.qty}</td><td>${money(p.entry_price)}</td><td>${money(p.mark_price)}</td><td class="${pnlClass(p.unrealized_pnl)}">${money(p.unrealized_pnl)}</td></tr>`);
  $('positions-overview').innerHTML=table(['TICKER','QTY','ENTRY','MARK*','UNREALIZED P/L'],rows);
  $('trade-history').innerHTML=table(['TICKER','QTY','ENTRY','EXIT','REALIZED P/L','CLOSED'],d.closed_trades.map(t=>`<tr><td><b>${safe(t.symbol)}</b></td><td>${t.qty}</td><td>${money(t.entry_price)}</td><td>${money(t.exit_price)}</td><td class="${pnlClass(t.pnl)}">${money(t.pnl)}</td><td>${safe(miniDate(t.closed_at))}</td></tr>`));
  const lines=[['open',d.open_risk,d.limits.max_daily_loss],['day',d.open_risk+d.loss_today,d.limits.max_daily_loss],['entries',d.entries_today,d.limits.max_trades_per_day]];
  for(const [id,value,max] of lines){$('risk-'+id+'-label').textContent=id==='entries'?`${value} / ${max}`:`${money(value)} / ${money(max)}`;$('risk-'+id+'-meter').style.width=Math.min(100,(value/max)*100)+'%';}
  $('positions-manage').innerHTML=d.positions.length?d.positions.map(p=>`<div class="position-item"><h3>${safe(p.symbol)} · ${p.qty} shares</h3><small>Entry ${money(p.entry_price)} · Stop ${money(p.stop_price)} · Target ${money(p.target_price)}</small><form class="close-form" data-trade-id="${p.id}"><label class="visually-hidden" for="close-${p.id}">Scenario close price</label><input id="close-${p.id}" name="exit_price" type="number" min=".0001" step="any" required placeholder="Exit price ($)"><button class="btn btn-outline" type="submit">Close paper trade</button></form></div>`).join(''):'<div class="empty">No positions open. Record a paper buy on the left.</div>';
  $('watchlist-items').innerHTML=d.watchlist.length?d.watchlist.map(s=>`<div class="watch-row"><b>${safe(s)}</b><button type="button" data-remove="${safe(s)}" aria-label="Remove ${safe(s)}">Remove</button></div>`).join(''):'<div class="empty">Your watchlist is empty.</div>';
  $('mark-list').innerHTML=d.marks.length?`<div class="eyebrow" style="margin:25px 0 8px">RECENT USER SCENARIOS</div>`+d.marks.slice(0,12).map(m=>`<div class="mark-row"><b>${safe(m.symbol)}</b><span>${money(m.price)} · ${safe(miniDate(m.recorded_at))}</span></div>`).join(''):'';
}
async function refresh(){app.data=await api('/api/overview');render();}
function chooseTab(tab){app.tab=tab;for(const button of document.querySelectorAll('[data-tab]'))button.classList.toggle('active',button.dataset.tab===tab);for(const panel of document.querySelectorAll('.tab-panel'))panel.hidden=panel.id!==`tab-${tab}`;
  const titles={overview:['Trading overview','A transparent workspace for offline paper trading and scenario analysis.'],trade:['Paper trading','Build scenarios with manual prices and strictly enforced simulated risk limits.'],watchlist:['Watchlist & scenarios','Track tickers and enter your own valuation scenarios.'],market:['Historical daily data','Read-only, delayed closing bars with visible dates and no effect on paper fills.'],scanner:['Scanner replay','Run the external skill pack only against its historical offline fixtures.'],backup:['Backup & restore','Save your paper ledger before the free server resets, or restore a saved snapshot.'],account:['Account security','Manage your login password and recovery options.']};
  $('page-title').textContent=titles[tab][0];$('page-subtitle').textContent=titles[tab][1];$('current-location').textContent=titles[tab][0].toUpperCase();if(tab==='scanner')loadScanner();if(tab==='market')loadMarket();
}
function preview(){const f=$('trade-form');const qty=Number(f.elements.qty.value),e=Number(f.elements.entry_price.value),s=Number(f.elements.stop_price.value),t=Number(f.elements.target_price.value);if(!(qty>0&&e>0&&s>0&&t>0)){ $('trade-preview').textContent='Enter a planned entry, stop, target and quantity to preview risk.';return;}
 const risk=qty*(e-s),notional=qty*e,rr=(t-e)/(e-s);$('trade-preview').textContent=`Paper notional ${money(notional)} · planned stop loss ${money(risk)} · reward/risk ${Number.isFinite(rr)?rr.toFixed(2):'—'}R. ${s>=e||t<=e?'Invalid long setup: stop must be below entry and target above.':''} Stops are not guaranteed fills or live monitored.`;
}
async function loadMarket(){
  try{
    const m=await api('/api/market/status');
    $('market-status').textContent=m.enabled?'● Optional Stooq historical feed enabled. No real-time quotes.':'○ Feed disabled by host configuration (ALGO_MARKET_DATA_ENABLED=1 to opt in).';
    $('market-refresh').disabled=!m.enabled;
    const rows=m.quotes.map(q=>`<tr><td><b>${safe(q.symbol)}</b></td><td>${money(q.price)}</td><td>${safe(q.bar_date)}</td><td>${safe(q.provider)}</td><td>${safe(new Date(q.fetched_at*1000).toLocaleString())}</td></tr>`);
    $('market-quotes').innerHTML=table(['TICKER','HISTORICAL CLOSE','BAR DATE','SOURCE','LAST FETCH'],rows);
  }catch(e){notice(e.message,true);}
}
async function loadScanner(){try{const s=await api('/api/scanner/status');$('scanner-connection').textContent=s.ready?'● Local scanner files found. Historical replay available.':'○ Not connected — '+s.message;$('replay-scanner').disabled=!s.ready;}catch(e){notice(e.message,true);}}
async function mutate(path,method,body,after){try{const response=await api(path,method,body);await refresh();notice(after||'Scenario updated successfully.');return response;}catch(e){notice(e.message,true);return null;}}
window.addEventListener('DOMContentLoaded',async()=>{
  try {
    const deployment = await api('/api/deployment');
    for (const id of ['free-login-warning', 'free-app-warning']) $(id).hidden = !(deployment.free_demo && !deployment.durable_storage);
  } catch (_) { /* local offline setup can still sign in */ }
  $('login-form').addEventListener('submit',async e=>{e.preventDefault();$('login-error').textContent='';try{const result=await api('/api/auth/login','POST',{username:$('login-username').value.trim(),password:$('login-password').value});$('login-password').value='';showApp(result);await refresh();}catch(err){$('login-error').textContent=err.message;}});
  $('forgot-toggle').addEventListener('click',()=>{$('login-form').hidden=true;$('reset-form').hidden=false;$('reset-message').textContent='';});
  $('back-to-login').addEventListener('click',()=>{$('reset-form').hidden=true;$('login-form').hidden=false;});
  $('reset-form').addEventListener('submit',async e=>{
    e.preventDefault();$('reset-message').textContent='';
    if($('reset-new').value!==$('reset-confirm').value){$('reset-message').textContent='Passwords do not match';return;}
    try {
      await api('/api/auth/reset-password','POST',{
        username:$('reset-username').value.trim(),recovery_key:$('reset-key').value,new_password:$('reset-new').value
      });
      $('reset-form').reset();$('reset-form').hidden=true;$('login-form').hidden=false;
      $('login-error').textContent='Password reset. Sign in with your new password.';
    } catch(err){$('reset-message').textContent=err.message;}
  });
  $('change-form').addEventListener('submit',async e=>{
    e.preventDefault();$('change-message').textContent='';
    if($('change-new').value!==$('change-confirm').value){$('change-message').textContent='Passwords do not match';return;}
    try {
      await api('/api/auth/change-password','POST',{
        current_password:$('change-current').value,new_password:$('change-new').value
      });
      $('change-form').reset();showLogin();
      $('login-error').textContent='Password changed. Please sign in again.';
    }catch(err){$('change-message').textContent=err.message;}
  });
  $('logout').addEventListener('click',async()=>{try{await api('/api/auth/logout','POST',{});}catch(e){}showLogin();});
  $('refresh-button').addEventListener('click',()=>refresh().then(()=>notice('Simulation ledger refreshed.')).catch(e=>notice(e.message,true)));
  for(const button of document.querySelectorAll('[data-tab]'))button.addEventListener('click',()=>chooseTab(button.dataset.tab));
  $('trade-form').addEventListener('input',preview);
  $('trade-form').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const payload={symbol:f.elements.symbol.value,qty:Number(f.elements.qty.value),entry_price:Number(f.elements.entry_price.value),stop_price:Number(f.elements.stop_price.value),target_price:Number(f.elements.target_price.value)};
    if(!confirm(`Record a SIMULATED BUY for ${payload.qty} ${payload.symbol.toUpperCase()} shares at ${money(payload.entry_price)}? No real order will be sent.`))return;
    const result=await mutate('/api/trades/open','POST',payload,'Paper buy recorded. No broker order was placed.');if(result){f.reset();preview();}
  });
  $('positions-manage').addEventListener('submit',async e=>{const f=e.target.closest('form.close-form');if(!f)return;e.preventDefault();const id=f.dataset.tradeId,exitPrice=Number(f.elements.exit_price.value);if(!confirm(`Close simulated position #${id} at scenario price ${money(exitPrice)}?`))return;await mutate(`/api/trades/${id}/close`,'POST',{exit_price:exitPrice},'Simulated close recorded. No broker order was placed.');});
  $('watchlist-form').addEventListener('submit',async e=>{e.preventDefault();const v=$('watch-symbol').value;const ok=await mutate('/api/watchlist','POST',{symbol:v},'Ticker added to watchlist.');if(ok)$('watch-symbol').value='';});
  $('watchlist-items').addEventListener('click',async e=>{const btn=e.target.closest('button[data-remove]');if(btn)await mutate('/api/watchlist/'+encodeURIComponent(btn.dataset.remove),'DELETE',null,'Ticker removed.');});
  $('mark-form').addEventListener('submit',async e=>{e.preventDefault();const symbol=$('mark-symbol').value,price=Number($('mark-price').value);const ok=await mutate('/api/marks','POST',{symbol,price},'Scenario price saved (not a live quote).');if(ok)e.target.reset();});
  $('market-refresh').addEventListener('click',async()=>{
    const btn=$('market-refresh');btn.disabled=true;
    try{const r=await api('/api/market/refresh','POST',{});
        await loadMarket();notice(`Dated bars updated: ${r.updated.length}; cached: ${r.cached.length}; unavailable: ${r.errors.length}. No paper positions changed.`, r.errors.length>0);
    }catch(e){notice(e.message,true);}finally{btn.disabled=false;}
  });
  $('backup-download').addEventListener('click', async()=>{
    const button=$('backup-download');button.disabled=true;
    try {
      const response=await fetch('/api/backup/export',{credentials:'same-origin',headers:{Accept:'application/json'}});
      if(!response.ok){const err=await response.json().catch(()=>({}));throw Error(err.detail||`Download failed (${response.status})`);}
      const blob=await response.blob();
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=url;a.download=`algo-trader-paper-${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      notice('Paper backup downloaded. Keep it in a safe place; cloud demo records are temporary.');
    }catch(err){notice(err.message,true);}finally{button.disabled=false;}
  });
  $('backup-restore-form').addEventListener('submit',async e=>{
    e.preventDefault();const message=$('backup-message');message.textContent='';
    const file=$('backup-file').files[0];if(!file)return;
    if(file.size>2000000){message.textContent='File is larger than 2 MB.';return;}
    let doc;
    try{doc=JSON.parse(await file.text());}catch(_){message.textContent='Choose a valid JSON backup.';return;}
    if(doc.format!=='algo-trader-paper-ledger'||doc.version!==1||!Array.isArray(doc.trades)){
      message.textContent='This is not a supported Algo Trader backup.';return;
    }
    const detail=`Restore ${doc.trades.length} paper trades from ${doc.created_at || 'an unknown date'}? All current paper trades, watchlist and scenario marks will be REPLACED. Login credentials stay unchanged.`;
    if(!confirm(detail))return;
    if(!confirm('Final confirmation: did you download a backup of your current records? This replacement cannot be undone.'))return;
    const button=$('backup-restore-button');button.disabled=true;
    try{
      const response=await fetch('/api/backup/restore',{method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':app.csrf,'X-Restore-Confirm':'REPLACE'},body:JSON.stringify(doc)});
      const result=await response.json().catch(()=>({}));
      if(!response.ok)throw Error(result.detail||`Restore failed (${response.status})`);
      e.target.reset();await refresh();notice(`Paper backup restored: ${result.trades} trades, ${result.watchlist} watchlist symbols. No broker orders.`);
      message.textContent='Restore complete. Account login credentials were not changed.';
    }catch(err){message.textContent=err.message;notice(err.message,true);}finally{button.disabled=false;}
  });
  $('replay-scanner').addEventListener('click',async()=>{const btn=$('replay-scanner');btn.disabled=true;try{const r=await api('/api/scanner/replay','POST',{});$('scanner-output').hidden=false;$('scanner-output').textContent=`OFFLINE HISTORICAL REPLAY — ${r.fixture_date}\nExit status: ${r.exit_code}\n\n${r.output}\n${r.error}`;notice('Historical offline scan completed.');}catch(e){notice(e.message,true);}finally{btn.disabled=false;}});
  try{const user=await api('/api/auth/me');showApp(user);await refresh();chooseTab('overview');}catch(e){showLogin();}
});
