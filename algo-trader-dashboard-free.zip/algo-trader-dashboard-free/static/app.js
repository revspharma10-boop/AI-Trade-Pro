'use strict';
const app = { csrf: null, username: '', data: null, tab: 'overview' };
const $ = id => document.getElementById(id);
const money = v => new Intl.NumberFormat('en-US', {style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(v)||0);
const safe = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const miniDate = v => v ? new Date(v).toLocaleString() : '—';
let noticeTimer;
function notice(message, isError=false){const n=$('notification');n.textContent=message;n.classList.toggle('error',isError);n.hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>n.hidden=true,9000);}
async function api(path, method='GET', body=null){
  const headers = {'Accept':'application/json'};
  if(body !== null)headers['Content-Type']='application/json';
  if(method !== 'GET' && app.csrf)headers['X-CSRF-Token']=app.csrf;
  let resp;try{resp=await fetch(path,{method,headers,credentials:'same-origin',body:body===null?undefined:JSON.stringify(body)});}catch(e){throw Error('Cannot reach dashboard server');}
  const data=await resp.json().catch(()=>({}));
  if(!resp.ok){if(resp.status===401 && !['/api/auth/reset-password','/api/auth/change-password'].includes(path))showLogin();const detail=Array.isArray(data.detail)?data.detail.map(x=>x.msg).join('; '):data.detail;throw Error(detail||`Request failed (${resp.status})`);}
  return data;
}
function showLogin(){$('login-view').hidden=false;$('app-view').hidden=true;$('reset-form').hidden=true;$('login-form').hidden=false;app.csrf=null;}
function showApp(user){app.csrf=user.csrf;app.username=user.username;$('username-display').textContent=user.username;$('profile-avatar').textContent=user.username.charAt(0).toUpperCase();$('app-view').hidden=false;$('login-view').hidden=true;}
function table(headers,rows){if(!rows.length)return '<div class="empty">Nothing recorded yet. Enter a scenario trade to get started.</div>';return `<table><thead><tr>${headers.map(h=>`<th>${safe(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;}
function pnlClass(n){return n>0?'positive':n<0?'negative':'';}
function render(){const d=app.data;if(!d)return;
  $('stat-equity').textContent=money(d.equity);$('stat-cash').textContent=money(d.cash);$('stat-pnl').textContent=money(d.realized_today);$('stat-pnl').className=`metric-value ${pnlClass(d.realized_today)}`;$('stat-positions').textContent=d.positions.length;
  const rows=d.positions.map(p=>`<tr><td><b>${safe(p.symbol)}</b></td><td>${p.qty}</td><td>${money(p.entry_price)}</td><td>${money(p.mark_price)}</td><td class="${pnlClass(p.unrealized_pnl)}">${money(p.unrealized_pnl)}</td></tr>`);
  $('positions-overview').innerHTML=table(['TICKER','QTY','ENTRY','MARK*','UNREALIZED P/L'],rows);
  $('trade-history').innerHTML=table(['TICKER','QTY','ENTRY','EXIT','REALIZED P/L','CLOSED'],d.closed_trades.map(t=>`<tr><td><b>${safe(t.symbol)}</b></td><td>${t.qty}</td><td>${money(t.entry_price)}</td><td>${money(t.exit_price)}</td><td class="${pnlClass(t.pnl)}">${money(t.pnl)}</td><td>${safe(miniDate(t.closed_at))}</td></tr>`));
  const lines=[['open',d.open_risk,d.limits.max_daily_loss],['day',d.open_risk+d.loss_today,d.limits.max_daily_loss],['entries',d.entries_today,d.limits.max_trades_per_day]];
  for(const [id,value,max] of lines){$('risk-'+id+'-label').textContent=id==='entries'?`${value} / ${max}`:`${money(value)} / ${money(max)}`;$('risk-'+id+'-meter').style.width=Math.min(100,(value/max)*100)+'%';}
  $('positions-manage').innerHTML=d.positions.length?d.positions.map(p=>`<div class="position-item"><h3>${safe(p.symbol)} · ${p.qty} shares</h3><small>Entry ${money(p.entry_price)} · Stop ${money(p.stop_price)} · Target ${money(p.target_price)}</small><form class="close-form" data-trade-id="${p.id}"><label class="visually-hidden" for="close-${p.id}">Scenario close price</label><input id="close-${p.id}" name="exit_price" type="number" min=".0001" step="any" required placeholder="Exit price ($)"><button class="btn btn-outline" type="submit">Close paper trade</button></form></div>`).join(''):'<div class="empty">No positions open. Record a paper buy on the left.</div>';
  $('watchlist-items').innerHTML=d.watchlist.length?d.watchlist.map(s=>`<div class="watch-row"><b>${safe(s)}</b><button type="button" data-remove="${safe(s)}" aria-label="Remove ${safe(s)}">Remove</button></div>`).join(''):'<div class="empty">Your watchlist is empty.</div>';
  $('mark-list').innerHTML=d.marks.length?`<div class="eyebrow" style="margin:25px 0 8px">RECENT USER SCENARIOS</div>`+d.marks.slice(0,12).map(m=>`<div class="mark-row"><b>${safe(m.symbol)}</b><span>${money(m.price)} · ${safe(miniDate(m.recorded_at))}</span></div>`).join(''):'';
}
async function refresh(){app.data=await api('/api/overview');render();}
function chooseTab(tab){app.tab=tab;for(const button of document.querySelectorAll('[data-tab]'))button.classList.toggle('active',button.dataset.tab===tab);for(const panel of document.querySelectorAll('.tab-panel'))panel.hidden=panel.id!==`tab-${tab}`;
  const titles={overview:['Trading overview','A transparent workspace for offline paper trading and scenario analysis.'],trade:['Paper trading','Build scenarios with manual prices and strictly enforced simulated risk limits.'],watchlist:['Watchlist & scenarios','Track tickers and enter your own valuation scenarios.'],market:['Historical daily data','Read-only, delayed closing bars with visible dates and no effect on paper fills.'],btc:['BTC strategy lab','Explore six BTC/USD spot strategies using completed candles and friction-adjusted next-bar backtests.'],'btc-paper':['BTC paper ledger','Fractional BTC/USD scenarios with fees and strict risk limits. No broker orders.'],'btc-signals':['BTC signal monitor','Check all six BTC/USD strategies on completed candles; no automatic orders.'],'btc-plan':['BTC entry / exit plan','Conditional BTC/USD paper scenarios with entry trigger, stop-loss, targets and size.'],scanner:['Scanner replay','Run the external skill pack only against its historical offline fixtures.'],backup:['Backup & restore','Save your paper ledger before the free server resets, or restore a saved snapshot.'],account:['Account security','Manage your login password and recovery options.']};
  $('page-title').textContent=titles[tab][0];$('page-subtitle').textContent=titles[tab][1];$('current-location').textContent=titles[tab][0].toUpperCase();if(tab==='scanner')loadScanner();if(tab==='market')loadMarket();if(tab==='btc-paper')loadBTCPaper();if(tab==='btc-signals')loadBTCSignals();
}
function preview(){const f=$('trade-form');const qty=Number(f.elements.qty.value),e=Number(f.elements.entry_price.value),s=Number(f.elements.stop_price.value),t=Number(f.elements.target_price.value);if(!(qty>0&&e>0&&s>0&&t>0)){ $('trade-preview').textContent='Enter a planned entry, stop, target and quantity to preview risk.';return;}
 const risk=qty*(e-s),notional=qty*e,rr=(t-e)/(e-s);$('trade-preview').textContent=`Paper notional ${money(notional)} · planned stop loss ${money(risk)} · reward/risk ${Number.isFinite(rr)?rr.toFixed(2):'—'}R. ${s>=e||t<=e?'Invalid long setup: stop must be below entry and target above.':''} Stops are not guaranteed fills or live monitored.`;
}
async function loadMarket(){
  try{
    const m=await api('/api/market/status');
    $('market-status').textContent=m.enabled?'● Optional Stooq historical feed enabled. No real-time quotes.':'○ Feed disabled by host configuration (ALGO_MARKET_DATA_ENABLED=1 to opt in).';
    $('market-refresh').disabled=!m.enabled;
    const rows=m.quotes.map(q=>`<tr><td><b>${safe(q.symbol)}</b></td><td>${money(q.price)}</td><td>${safe(q.bar_date)}</td><td>${safe(q.provider)}</td><td>${safe(new Date(q.fetched_at*1000).toLocaleString())}</td></tr>`);
    $('market-quotes').innerHTML=table(['TICKER','HISTORICAL CLOSE','BAR DATE','SOURCE','LAST FETCH'],rows);
  }catch(e){notice(e.message,true);}
}
async function loadScanner(){try{const s=await api('/api/scanner/status');$('scanner-connection').textContent=s.ready?'● Local scanner files found. Historical replay available.':'○ Not connected — '+s.message;$('replay-scanner').disabled=!s.ready;}catch(e){notice(e.message,true);}}
async function mutate(path,method,body,after){try{const response=await api(path,method,body);await refresh();notice(after||'Scenario updated successfully.');return response;}catch(e){notice(e.message,true);return null;}}
const btcQty = v => Number(v).toFixed(8).replace(/0+$/,'').replace(/\.$/,'');
async function loadBTCPaper(){
  try { const d=await api('/api/btc/paper/portfolio');
    $('btc-paper-equity').textContent=money(d.equity);
    $('btc-paper-cash').textContent=money(d.cash);
    $('btc-paper-count').textContent=`${d.entries_today} / ${d.limits.max_entries_utc_day}`;
    $('btc-paper-risk').textContent=`${money(d.loss_today+d.planned_open_risk)} / $150`;
    $('btc-paper-positions').innerHTML=d.positions.length ? d.positions.map(t=>`<div class="position-item">
      <h3>BTC/USD · ${btcQty(t.qty)} BTC</h3>
      <small>Entry ${money(t.entry_price)} · Manual mark ${money(t.mark_price)} (${safe(t.mark_source)}) · Stop ${money(t.stop_price)} · Target ${money(t.target_price)}</small>
      <p>After-fee unrealized P/L: <b class="${pnlClass(t.unrealized_pnl_after_fees)}">${money(t.unrealized_pnl_after_fees)}</b></p>
      <form class="btc-paper-close-form close-form" data-trade-id="${t.id}">
      <label for="btc-exit-${t.id}">Manual exit scenario USD/BTC</label>
      <input id="btc-exit-${t.id}" name="exit_price" type="number" min="0.0001" step="0.0001" required>
      <button class="btn btn-outline">Close simulated BTC position</button></form></div>`).join('') : '<div class="empty">No open BTC paper position. No orders have been placed.</div>';
    $('btc-paper-history').innerHTML=table(['BTC QTY','ENTRY','EXIT','ENTRY FEE','EXIT FEE','NET P/L','CLOSED'],d.closed_trades.map(t=>
      `<tr><td>${btcQty(t.qty)}</td><td>${money(t.entry_price)}</td><td>${money(t.exit_price)}</td><td>${money(t.entry_fee)}</td><td>${money(t.exit_fee)}</td><td class="${pnlClass(t.pnl)}">${money(t.pnl)}</td><td>${safe(miniDate(t.closed_at))}</td></tr>`));
  } catch (e){notice(e.message,true);$('btc-paper-positions').textContent=e.message;}
}
function previewBTCPaper(){
  const f=$('btc-paper-open-form'), q=Number(f.elements.qty.value), e=Number(f.elements.entry_price.value),s=Number(f.elements.stop_price.value),t=Number(f.elements.target_price.value);
  if(!(q>0&&e>0&&s>0&&t>0))return;
  const notional=q*e, fees=.001*(notional+q*s), risk=q*(e-s)+fees,rr=(t-e)/(e-s);
  $('btc-paper-preview').textContent=`BTC ${q} · notional ${money(notional)} · approx. stop risk with fees ${money(risk)} · target ${rr.toFixed(2)}R. ${s>=e||t<=e?'INVALID long setup.':''} No automatic stops, exits or live orders.`;
}
window.addEventListener('DOMContentLoaded',async()=>{
  try {
    const deployment = await api('/api/deployment');
    for (const id of ['free-login-warning', 'free-app-warning']) $(id).hidden = !(deployment.free_demo && !deployment.durable_storage);
  } catch (_) { /* local offline setup can still sign in */ }
  $('login-form').addEventListener('submit',async e=>{e.preventDefault();$('login-error').textContent='';try{const result=await api('/api/auth/login','POST',{username:$('login-username').value.trim(),password:$('login-password').value});$('login-password').value='';showApp(result);await refresh();chooseTab('btc-paper');}catch(err){$('login-error').textContent=err.message;}});
  $('forgot-toggle').addEventListener('click',()=>{$('login-form').hidden=true;$('reset-form').hidden=false;$('reset-message').textContent='';});
  $('back-to-login').addEventListener('click',()=>{$('reset-form').hidden=true;$('login-form').hidden=false;});
  $('reset-form').addEventListener('submit',async e=>{
    e.preventDefault();$('reset-message').textContent='';
    if($('reset-new').value!==$('reset-confirm').value){$('reset-message').textContent='PINs do not match';return;}
    try {
      await api('/api/auth/reset-password','POST',{
        username:$('reset-username').value.trim(),recovery_key:$('reset-key').value,new_password:$('reset-new').value
      });
      $('reset-form').reset();$('reset-form').hidden=true;$('login-form').hidden=false;
      $('login-error').textContent='PIN reset. Sign in with your new 4-digit PIN.';
    } catch(err){$('reset-message').textContent=err.message;}
  });
  $('change-form').addEventListener('submit',async e=>{
    e.preventDefault();$('change-message').textContent='';
    if($('change-new').value!==$('change-confirm').value){$('change-message').textContent='PINs do not match';return;}
    try {
      await api('/api/auth/change-password','POST',{
        current_password:$('change-current').value,new_password:$('change-new').value
      });
      $('change-form').reset();showLogin();
      $('login-error').textContent='PIN changed. Please sign in again.';
    }catch(err){$('change-message').textContent=err.message;}
  });
  $('logout').addEventListener('click',async()=>{try{await api('/api/auth/logout','POST',{});}catch(e){}showLogin();});
  $('refresh-button').addEventListener('click',()=>refresh().then(()=>notice('Simulation ledger refreshed.')).catch(e=>notice(e.message,true)));
  for(const button of document.querySelectorAll('[data-tab]'))button.addEventListener('click',()=>chooseTab(button.dataset.tab));
  $('trade-form').addEventListener('input',preview);
  $('trade-form').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const payload={symbol:f.elements.symbol.value,qty:Number(f.elements.qty.value),entry_price:Number(f.elements.entry_price.value),stop_price:Number(f.elements.stop_price.value),target_price:Number(f.elements.target_price.value)};
    if(!confirm(`Record a SIMULATED BUY for ${payload.qty} ${payload.symbol.toUpperCase()} shares at ${money(payload.entry_price)}? No real order will be sent.`))return;
    const result=await mutate('/api/trades/open','POST',payload,'Paper buy recorded. No broker order was placed.');if(result){f.reset();preview();}
  });
  $('positions-manage').addEventListener('submit',async e=>{const f=e.target.closest('form.close-form');if(!f)return;e.preventDefault();const id=f.dataset.tradeId,exitPrice=Number(f.elements.exit_price.value);if(!confirm(`Close simulated position #${id} at scenario price ${money(exitPrice)}?`))return;await mutate(`/api/trades/${id}/close`,'POST',{exit_price:exitPrice},'Simulated close recorded. No broker order was placed.');});
  $('watchlist-form').addEventListener('submit',async e=>{e.preventDefault();const v=$('watch-symbol').value;const ok=await mutate('/api/watchlist','POST',{symbol:v},'Ticker added to watchlist.');if(ok)$('watch-symbol').value='';});
  $('watchlist-items').addEventListener('click',async e=>{const btn=e.target.closest('button[data-remove]');if(btn)await mutate('/api/watchlist/'+encodeURIComponent(btn.dataset.remove),'DELETE',null,'Ticker removed.');});
  $('mark-form').addEventListener('submit',async e=>{e.preventDefault();const symbol=$('mark-symbol').value,price=Number($('mark-price').value);const ok=await mutate('/api/marks','POST',{symbol,price},'Scenario price saved (not a live quote).');if(ok)e.target.reset();});
  $('btc-paper-open-form').addEventListener('input',previewBTCPaper);
  $('btc-paper-open-form').addEventListener('submit',async e=>{
    e.preventDefault();const f=e.currentTarget,payload={qty:Number(f.elements.qty.value),entry_price:Number(f.elements.entry_price.value),stop_price:Number(f.elements.stop_price.value),target_price:Number(f.elements.target_price.value)};
    if(!confirm(`Record a SIMULATED BTC buy for ${btcQty(payload.qty)} BTC at manually chosen price ${money(payload.entry_price)}? No order will be sent.`))return;
    try{const r=await api('/api/btc/paper/open','POST',payload);f.reset();$('btc-paper-preview').textContent=`Simulated position #${r.trade_id} recorded. Entry fee ${money(r.entry_fee)}.`;await loadBTCPaper();notice('BTC paper entry recorded online. No real order sent.');}catch(err){notice(err.message,true);}
  });
  $('btc-paper-positions').addEventListener('submit',async e=>{
    const f=e.target.closest('form.btc-paper-close-form');if(!f)return;e.preventDefault();
    const id=Number(f.dataset.tradeId),exit_price=Number(f.elements.exit_price.value);
    if(!confirm(`Close simulated BTC position #${id} at manual price ${money(exit_price)}? No exchange order will be placed.`))return;
    try{const r=await api(`/api/btc/paper/${id}/close`,'POST',{exit_price});await loadBTCPaper();notice(`Paper BTC exit recorded, net P/L ${money(r.pnl_after_fees)}.`);}catch(err){notice(err.message,true);}
  });
  $('btc-paper-mark-form').addEventListener('submit',async e=>{e.preventDefault();
    try{await api('/api/btc/paper/mark','POST',{price:Number(e.currentTarget.elements.price.value)});await loadBTCPaper();notice('Manual BTC scenario mark saved; no order placed.');}catch(err){notice(err.message,true);}
  });
  async function showSignalCheck(r){
    $('btc-signal-info').textContent=`BTC/USD · latest completed candle ${miniDate(new Date(r.candle_time*1000).toISOString())} · checked ${miniDate(r.checked_at)} · ${r.signals.length} strategies · ZERO orders placed.`;
    const rows=r.signals.map(x=>`<tr><td>${safe(x.name)}</td><td><b>${safe(x.signal)}</b></td><td>${money(x.close_price)}</td><td>${safe(miniDate(new Date(x.candle_time*1000).toISOString()))}</td></tr>`);
    $('btc-signal-results').innerHTML=table(['STRATEGY','SIGNAL','COMPLETED CLOSE','CANDLE START UTC'],rows);
  }
  async function loadBTCSignals(){
    try{const r=await api('/api/btc/signals/history?timeframe='+Number($('btc-signal-timeframe').value));
      const newest=r.checks.reduce((acc,row)=>acc===null||row.candle_time>acc?row.candle_time:acc,null);
      $('btc-signal-info').textContent=newest===null?'No recorded BTC signals for this timeframe yet.':`Last recorded candle start: ${miniDate(new Date(newest*1000).toISOString())} · ${r.checks.length} saved strategy observations · No paper orders placed.`;
      const rows=r.checks.map(x=>`<tr><td>${safe(x.strategy)}</td><td>${safe(x.signal)}</td><td>${money(x.close_price)}</td><td>${safe(miniDate(new Date(x.candle_time*1000).toISOString()))}</td></tr>`);
      $('btc-signal-results').innerHTML=rows.length?table(['STRATEGY','SIGNAL','COMPLETED CLOSE','CANDLE START UTC'],rows):'<p class="subdued">No observations. Click Check BTC signals now.</p>';
    }catch(e){$('btc-signal-info').textContent=e.message;}
  }
  $('btc-signal-timeframe').addEventListener('change',loadBTCSignals);
  $('btc-signal-refresh').addEventListener('click',loadBTCSignals);
  $('btc-signal-check').addEventListener('click',async()=>{
    const btn=$('btc-signal-check');btn.disabled=true;$('btc-signal-info').textContent='Checking completed Kraken candles…';
    try{const r=await api('/api/btc/signals/check','POST',{timeframe:Number($('btc-signal-timeframe').value)});
      await showSignalCheck(r);notice('Six BTC signal observations saved to Neon. No orders placed.');
    }catch(e){$('btc-signal-info').textContent=e.message;notice(e.message,true);}finally{btn.disabled=false;}
  });
  let latestBTCPlan=null;
  $('btc-plan-run').addEventListener('click',async()=>{
    const btn=$('btc-plan-run');btn.disabled=true;latestBTCPlan=null;
    $('btc-plan-to-paper').hidden=true;$('btc-plan-output').textContent='';
    $('btc-plan-info').textContent='Fetching completed BTC candles and applying risk limits…';
    try{
      const r=await api('/api/btc/plan','POST',{timeframe:Number($('btc-plan-timeframe').value)});
      latestBTCPlan=r;
      $('btc-plan-info').textContent=`${r.pair} · ${r.state==='WAIT'?'WAIT — No entry':'CONDITIONAL long only'} · ${r.bullish_strategies}/6 strategies long · last completed candle ${miniDate(r.latest_completed_candle_utc)} · setup expires ${miniDate(r.setup_expires_utc)}. ${r.reason}`;
      const metrics=[
        ['Last observed close',money(r.observed_close_usd)],['ATR(14) volatility',money(r.atr_14_usd)],
        ['Entry BREAKOUT trigger',r.entry_trigger_usd===null?'WAIT':money(r.entry_trigger_usd)],
        ['Manual stop-loss',r.stop_loss_usd===null?'—':money(r.stop_loss_usd)],
        ['Profit target 1',r.target_1_usd===null?'—':money(r.target_1_usd)],
        ['Profit target 2',r.target_2_usd===null?'—':money(r.target_2_usd)],
        ['Max paper BTC quantity',r.max_paper_btc_qty===null?'—':btcQty(r.max_paper_btc_qty)],
        ['Illustrative stop risk',r.estimated_stop_risk_usd===null?'—':money(r.estimated_stop_risk_usd)]
      ];
      $('btc-plan-output').innerHTML=`<div class="btc-summary">${metrics.map(([k,v])=>`<div><small>${safe(k)}</small><strong>${safe(v)}</strong></div>`).join('')}</div><p class="fine-print">${safe(r.warning)}</p>`;
      $('btc-plan-to-paper').hidden=r.state!=='CONDITIONAL_LONG';
      notice(r.state==='WAIT'?'No qualifying BTC long setup; WAIT.':'Conditional BTC paper setup calculated. No trade has been placed.');
    }catch(e){$('btc-plan-info').textContent=e.message;notice(e.message,true);}finally{btn.disabled=false;}
  });
  $('btc-plan-to-paper').addEventListener('click',()=>{
    const r=latestBTCPlan;
    if(!r||r.state!=='CONDITIONAL_LONG')return;
    // Purely populates the manual form; submit and confirm remain separate user actions.
    const f=$('btc-paper-open-form');
    f.elements.qty.value=btcQty(r.max_paper_btc_qty);
    f.elements.entry_price.value=r.entry_trigger_usd;
    f.elements.stop_price.value=r.stop_loss_usd;
    f.elements.target_price.value=r.target_1_usd;
    chooseTab('btc-paper');previewBTCPaper();
    notice('Scenario copied into the paper form. No buy executed. Check prices and risk before manually submitting.');
  });
  $('btc-compare').addEventListener('click',async()=>{
    const btn=$('btc-compare'), output=$('btc-comparison');btn.disabled=true;output.textContent='Comparing all six strategies using the same finished BTC candles…';
    try{const r=await api('/api/btc/strategies/compare','POST',{timeframe:Number($('btc-timeframe').value)});
      const rows=r.comparison.map(x=>`<tr><td>${safe(x.name)}</td><td class="${pnlClass(x.return_pct)}">${x.return_pct}%</td><td>${x.buy_hold_return_pct}%</td><td>${x.max_drawdown_pct}%</td><td>${x.closed_trades}</td><td>${x.win_rate_pct===null?'N/A':x.win_rate_pct+'%'}</td></tr>`);
      output.innerHTML=`<p class="fine-print">${r.candles} shared completed BTC/USD candles. Same trading-cost assumptions for all strategies. Ranking historical results is subject to selection bias; not an investment recommendation.</p>`+table(['STRATEGY','NET RETURN','HOLD BTC','MAX DRAWDOWN','CLOSED TRADES','WIN RATE'],rows);
      notice('Historical BTC strategy comparison finished. Paper ledger unchanged.');
    }catch(err){output.textContent=err.message;notice(err.message,true);}finally{btn.disabled=false;}
  });
  $('btc-research-form').addEventListener('submit', async e => {
    e.preventDefault();
    const btn=$('btc-run'), output=$('btc-results');
    btn.disabled=true;output.textContent='Fetching completed BTC candles and running a historical simulation…';
    try {
      const r=await api('/api/btc/strategies/run','POST',{
        strategy:$('btc-strategy').value,timeframe:Number($('btc-timeframe').value)});
      output.textContent=[
        `${r.name} · BTC/USD · ${r.timeframe_minutes} minute candles`,
        `Historical window: ${miniDate(r.from_utc)} — ${miniDate(r.through_utc)}`,
        `Candles: ${r.candles} · Simulated starting cash: ${money(r.starting_cash_usd)}`,
        `Backtest ending equity: ${money(r.ending_equity_usd)} (${r.return_pct}%)`,
        `BTC buy-and-hold benchmark: ${r.buy_hold_return_pct}%`,
        `Maximum peak-to-trough drawdown: ${r.max_drawdown_pct}%`,
        `Completed round trips: ${r.closed_trades} · Win rate: ${r.win_rate_pct===null?'N/A':r.win_rate_pct+'%'}`,
        `Last completed-bar decision: ${r.latest_decision} (not an order)`,
        'No fills, orders or portfolio changes occurred. Past performance is not predictive.'
      ].join('\n');
      output.style.whiteSpace='pre-line';
      notice('BTC historical research completed; paper portfolio unchanged.');
    } catch(err){output.textContent=err.message;notice(err.message,true);}finally{btn.disabled=false;}
  });
  $('market-refresh').addEventListener('click',async()=>{
    const btn=$('market-refresh');btn.disabled=true;
    try{const r=await api('/api/market/refresh','POST',{});
        await loadMarket();notice(`Dated bars updated: ${r.updated.length}; cached: ${r.cached.length}; unavailable: ${r.errors.length}. No paper positions changed.`, r.errors.length>0);
    }catch(e){notice(e.message,true);}finally{btn.disabled=false;}
  });
  // A browser-only transfer: source GET and destination POST are always same-origin.
  // No cross-origin credentials, third-party relay, file storage, or localStorage.
  $('cloud-copy').addEventListener('click', async()=>{
    const button=$('cloud-copy');button.disabled=true;
    const message=$('cloud-message');message.textContent='';
    try {
      const response=await fetch('/api/backup/export',{credentials:'same-origin',headers:{Accept:'application/json'}});
      if(!response.ok){const err=await response.json().catch(()=>({}));throw Error(err.detail||`Export failed (${response.status})`);}
      const content=await response.text();
      if(new Blob([content]).size>2000000)throw Error('Paper records are too large for this transfer.');
      let onClipboard=false;
      if(navigator.clipboard?.writeText){
        try{await navigator.clipboard.writeText(content);onClipboard=true;}catch(_){/* some browsers block clipboard permissions */}
      }
      if(onClipboard){
        $('cloud-payload').value='';
        message.textContent='Copied to clipboard. Open your NEW cloud dashboard, sign in, then select Paste and restore records.';
      }else{
        $('cloud-payload').value=content;
        $('cloud-payload').focus();$('cloud-payload').select();
        message.textContent='Clipboard permission blocked. Use Select All / Copy on the transfer text, then paste it on the NEW dashboard. No file required.';
      }
      notice('Paper records prepared in your browser. No file downloaded. Clear clipboard after transfer.');
    }catch(err){message.textContent=err.message;notice(err.message,true);}finally{button.disabled=false;}
  });
  $('cloud-paste').addEventListener('click', async()=>{
    const message=$('cloud-message');message.textContent='';
    const button=$('cloud-paste');button.disabled=true;
    try {
      let content=$('cloud-payload').value.trim();
      if(!content){
        if(!navigator.clipboard?.readText)throw Error('Clipboard access unavailable. Paste the text into the box manually.');
        content=(await navigator.clipboard.readText()).trim();
      }
      if(!content)throw Error('No transfer text found. Copy records from the previous dashboard first.');
      if(new Blob([content]).size>2000000)throw Error('Transfer data exceeds the 2 MB limit.');
      let doc;try{doc=JSON.parse(content);}catch(_){throw Error('Clipboard is not valid JSON. Copy records again.');}
      if(doc?.format!=='algo-trader-paper-ledger'||doc.version!==1||!Array.isArray(doc.trades))throw Error('Not an Algo Trader paper-ledger export.');
      if(!confirm(`Import ${doc.trades.length} paper trades into THIS account? All current trades, watchlist and scenario prices will be replaced. Your PIN stays unchanged.`))return;
      if(!confirm('FINAL CHECK: Replace the current cloud ledger with the copied records? This cannot be undone.'))return;
      const response=await fetch('/api/backup/restore',{method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':app.csrf,'X-Restore-Confirm':'REPLACE'},body:content});
      const result=await response.json().catch(()=>({}));
      if(!response.ok)throw Error(result.detail||`Restore failed (${response.status})`);
      $('cloud-payload').value='';
      await refresh();
      message.textContent=`Transferred ${result.trades} trades and ${result.watchlist} symbols. Confirm the destination records and clear your clipboard.`;
      notice('Paper records restored online. No real trades placed.');
    }catch(err){message.textContent=err.message;notice(err.message,true);}finally{button.disabled=false;}
  });
  $('cloud-clear').addEventListener('click', async()=>{
    $('cloud-payload').value='';
    try{if(navigator.clipboard?.writeText)await navigator.clipboard.writeText('');}catch(_){/* browser permission may deny clipboard clear */}
    $('cloud-message').textContent='Temporary transfer text cleared from this page. Check your system clipboard history separately.';
  });
  $('backup-download').addEventListener('click', async()=>{
    const button=$('backup-download');button.disabled=true;
    try {
      const response=await fetch('/api/backup/export',{credentials:'same-origin',headers:{Accept:'application/json'}});
      if(!response.ok){const err=await response.json().catch(()=>({}));throw Error(err.detail||`Download failed (${response.status})`);}
      const blob=await response.blob();
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=url;a.download=`algo-trader-paper-${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      notice('Paper backup downloaded. Keep it in a safe place; cloud demo records are temporary.');
    }catch(err){notice(err.message,true);}finally{button.disabled=false;}
  });
  $('backup-restore-form').addEventListener('submit',async e=>{
    e.preventDefault();const message=$('backup-message');message.textContent='';
    const file=$('backup-file').files[0];if(!file)return;
    if(file.size>2000000){message.textContent='File is larger than 2 MB.';return;}
    let doc;
    try{doc=JSON.parse(await file.text());}catch(_){message.textContent='Choose a valid JSON backup.';return;}
    if(doc.format!=='algo-trader-paper-ledger'||doc.version!==1||!Array.isArray(doc.trades)){
      message.textContent='This is not a supported Algo Trader backup.';return;
    }
    const detail=`Restore ${doc.trades.length} paper trades from ${doc.created_at || 'an unknown date'}? All current paper trades, watchlist and scenario marks will be REPLACED. Login credentials stay unchanged.`;
    if(!confirm(detail))return;
    if(!confirm('Final confirmation: did you download a backup of your current records? This replacement cannot be undone.'))return;
    const button=$('backup-restore-button');button.disabled=true;
    try{
      const response=await fetch('/api/backup/restore',{method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':app.csrf,'X-Restore-Confirm':'REPLACE'},body:JSON.stringify(doc)});
      const result=await response.json().catch(()=>({}));
      if(!response.ok)throw Error(result.detail||`Restore failed (${response.status})`);
      e.target.reset();await refresh();notice(`Paper backup restored: ${result.trades} trades, ${result.watchlist} watchlist symbols. No broker orders.`);
      message.textContent='Restore complete. Account login credentials were not changed.';
    }catch(err){message.textContent=err.message;notice(err.message,true);}finally{button.disabled=false;}
  });
  $('replay-scanner').addEventListener('click',async()=>{const btn=$('replay-scanner');btn.disabled=true;try{const r=await api('/api/scanner/replay','POST',{});$('scanner-output').hidden=false;$('scanner-output').textContent=`OFFLINE HISTORICAL REPLAY — ${r.fixture_date}\nExit status: ${r.exit_code}\n\n${r.output}\n${r.error}`;notice('Historical offline scan completed.');}catch(e){notice(e.message,true);}finally{btn.disabled=false;}});
  try{const user=await api('/api/auth/me');showApp(user);await refresh();chooseTab('btc-paper');}catch(e){showLogin();}
});
