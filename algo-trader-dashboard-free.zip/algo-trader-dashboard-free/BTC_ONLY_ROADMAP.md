# Algo Trader: BTC-only roadmap

BTC/USD **spot** paper trading only. Continuous trading in the underlying market does **not** imply the free hosting runs continuously.

## Built in BTC research candidate
- Signed-in, CSRF-protected, manually triggered Kraken public spot OHLC retrieval. No API key or order capability.
- Six long-only backtest rules: SMA 10/30, EMA 12/26, RSI(14), Bollinger 20/2, Donchian 20, and 12-bar momentum. Choose 5m, 15m, 1h, 4h, or 1d.
- Drop Kraken's most recent still-forming candle. Signals generated from a closed candle; hypothetical entry/exit at **the next candle's open**.
- Illustrative 0.10% fee + 0.05% slippage **per side**, spot-only no shorting or leverage, 95% cash allocation. Outputs returns, buy-and-hold benchmark, closed-trade win rate and max drawdown.
- Protected, 60-second server-side request cooldown. No database writes beyond cooldown metadata; no real or paper orders; no persistent live signal execution.
- The **legacy stock scenario ledger remains accessible** solely until BTC fractional quantity and cloud migration have been implemented and tested; do not describe it as BTC-only trading yet.
- Local test suite **51 passed** on 25 October 2026. This is not historical performance validation or an external data-provider uptime guarantee.

## Still pending
1. Complete cloud-only migration of any existing legacy paper records to Neon; preserve PIN and verified user data.
2. Replace legacy equity trade engine with BTC fractional units, decimal-safe accounting, spot-only long positions, per-order risk, fees, and spread; migrate DB schema safely.
3. Strategy comparison on the same fixed periods, walk-forward/out-of-sample tests, stress testing across trending/ranging/choppy markets; incorporate funding-free spot spreads.
4. Store historical candles to Neon and add scheduled backtest replay. Avoid overfitting, look-ahead/survivorship biases, and parameter mining.
5. Build an always-on **paper** signal service only when suitable reliable hosting is available. Render Free spins down after 15 minutes of inactivity (https://render.com/docs/free).
6. Define cloud recovery beyond Neon's limited Free restore history. Never put credentials, user exports or password hashes in public GitHub.
7. Manual review of strategy performance before any automation; no real exchange orders or API-key trading.

API docs: https://docs.kraken.com/api-reference/market-data/get-ohlc-data (up to 720 recent candles; last still forming).
