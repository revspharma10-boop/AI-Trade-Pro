# Deployment checklist

- [ ] Explicitly approve Render workspace and billable service + disk.
- [ ] Push these files to a **new** GitHub repository (do not alter the skill-pack root).
- [ ] Confirm `render.yaml` deploys to a supported paid plan with 1 GB disk at `/var/data`.
- [ ] Set unique `ALGO_BOOTSTRAP_PASSWORD` in Render secrets; never send the password in chat.
- [ ] Deploy, check `/health`, then sign in at the HTTPS service root.
- [ ] Confirm `ALGO_DB_PATH=/var/data/algo.sqlite3` and secure cookie headers.
- [ ] Confirm session survives redeploy and database contents persist.
- [ ] Add watchlist ticker, fetch historical dated daily data if available, and verify manual scenario marks remain unchanged.
- [ ] Export and secure a tested offsite backup.
- [ ] Restrict who can access the hosted service; plan security audit before broader usage.
- [ ] Keep all broker connections and live trading disabled.
