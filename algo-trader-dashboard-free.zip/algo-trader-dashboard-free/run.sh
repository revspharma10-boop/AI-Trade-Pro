#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
if [ ! -f "${ALGO_DB_PATH:-data/algo.sqlite3}" ]; then
  python3 app.py init --username admin
else
  echo "If this is a fresh database, run: python3 app.py init --username admin"
fi
python3 app.py run
