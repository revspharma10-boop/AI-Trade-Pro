# Cloud-only transfer (no files or laptop storage)

Stage this feature on the Neon preview branch first. Both sites must be logged in separately.

1. On the **old** dashboard choose **Backup & restore → Copy paper records**. This calls its own authenticated JSON export endpoint and copies the ledger to the clipboard. Credentials and recovery keys are not exported.
2. On the **new** dashboard choose **Backup & restore → Paste and restore records**. If clipboard reading is denied, paste into the temporary transfer text box. Confirm both destructive-restore prompts.
3. The destination calls its existing authenticated, CSRF-protected, 2 MB-limited `/api/backup/restore`. It verifies the SHA-256 checksum and replays ledger accounting checks before writing. It does not modify login credentials.
4. Confirm balances/positions/watchlist and use **Clear transfer text**. The OS clipboard may retain history; browser cannot guarantee deletion of system clipboard history.

**No user file download is required.** JSON passes through clipboard/browser memory; it is not a durable backup. Browser clipboard requires HTTPS and user permission, and system clipboard can be accessible to other apps. Never paste a recovery key or database URL.

**Important rollout constraint:** upgrading the existing Render Free site can itself erase its ephemeral SQLite data and PIN. Do not redeploy the source site just to add this feature until old records have been migrated to Neon or the user explicitly accepts losing them. The Neon preview must first have `ALGO_DATABASE_URL` and private credentials set in Render and pass health, login, and redeploy-persistence checks. The new migration screen does **not** replace this requirement.
