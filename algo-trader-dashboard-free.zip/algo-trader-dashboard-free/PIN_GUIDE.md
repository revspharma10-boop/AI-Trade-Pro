# Four-digit PIN login and recovery

**For a paper-only demo.** A four-digit PIN has 10,000 possibilities and is much weaker than a long password. Never reuse a bank or brokerage PIN. This feature must never be used for real brokerage orders.

- If you remember the original password, sign in and open **Account & PIN**. Enter your existing password in the current-credential field, set your own new **exactly four numeric digits**, and confirm it. Avoid common PINs such as 1234 and 0000.
- If you forgot the old password, select **Forgot PIN / password?** on the login page. Enter username `admin`, the recovery key from the private Render setting `ALGO_RECOVERY_KEY`, then your chosen four-digit PIN and confirmation. Your recovery key is a separate long secret; it cannot be replaced by the PIN.
- Forgot both password and recovery key? Only the Render administrator can perform a manual password-recovery procedure; no bypass is provided through the public website.
- Incorrect sign-ins are throttled across IPs **per username**: three attempts in 15 minutes, twelve per 24 hours; IP-wide throttling also applies. Reset attempts are separately rate-limited. Login sessions are invalidated after change/reset.
- Existing strong passwords still work until changed; first-time environment bootstrap **requires a 12+ character password**, not a PIN. The PIN is set with the authenticated change or recovery flow.
- Render Free without Neon loses PIN changes when its SQLite storage resets. For lasting PINs, activate Neon durable storage first and verify a redeploy.
- No PIN values or recovery keys are included in backups, the public source code, or the API responses.
