#!/usr/bin/env bash
set -Eeuo pipefail
# Usage: bash verify_deployment.sh https://your-dashboard.onrender.com
if [[ $# -ne 1 ]]; then
  echo "Usage: bash verify_deployment.sh https://YOUR-SERVICE.onrender.com" >&2; exit 2
fi
python3 - "$1" <<'PYINNER'
import json, ssl, sys, urllib.request, urllib.parse
base=sys.argv[1].rstrip('/')
u=urllib.parse.urlparse(base)
if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path:
    raise SystemExit('Provide the service base HTTPS URL only (no path/query).')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): raise ValueError('Unexpected redirect')
opener=urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl.create_default_context()),NoRedirect())
with opener.open(urllib.request.Request(base+'/health',headers={'User-Agent':'algo-trader-stage-check/1.0'}),timeout=20) as r:
    assert r.status == 200, 'Bad health response'
    payload=json.load(r)
    assert payload.get('ok') is True, 'Health response not OK'
print('PASS: HTTPS health check')
print('Manual steps still required: log in, verify paper-only mode, create a small imaginary trade, then redeploy and confirm state persists.')
PYINNER
