# Stage 7 — Durable storage with Neon Free Postgres

**Status: implementation ready; activation needs a verified Neon project and database URL.**
This version preserves the current SQLite fallback for local development.
Nothing attempts external storage unless `ALGO_DATABASE_URL` is configured.

## Why Neon rather than Render Free Postgres?

Render Free web instances erase local files on sleep/redeploy, and Render Free
Postgres expires after 30 days. Neon offers a Postgres Free plan with storage
included (as of 25 October 2026: 1 GB/project, 100 CU-hours/project monthly,
5 GB network transfer). Those free quotas can change; monitor them.

## Activate safely

1. **First download a JSON backup** from the existing live application's
   **Backup & restore** page and store the file privately. Deploying a new
   version may already reset the old ephemeral SQLite storage.
2. Connect the Neon integration to ChatGPT, or create a Neon Free project at
   https://console.neon.tech/ . No financial/broker credentials are needed.
3. Copy the Neon **PostgreSQL connection string** directly into the *existing*
   Render web service's `ALGO_DATABASE_URL` secret environment variable.
   Do not paste the URL in this chat and do not commit it to GitHub.
   If possible, use a dedicated restricted application database role.
4. Set `ALGO_REQUIRE_DURABLE=1` on the same service *only after* the secret is set and
   validated. Deploy this version on the isolated branch after the Render environment
   variable exists. **Never allow the app to deploy with a blank/invalid URL
   while assuming it is durable.** The application fails at startup if the
   configured database is unreachable; it will NOT silently create an empty
   SQLite fallback database.
5. Open `/api/deployment`: after activation, `storage` must equal
   `remote_postgresql` and `durable_storage` must equal `true`.
   Confirm `/health` returns 200. Login using the bootstrap admin credentials
   (first initialization only), then restore your earlier JSON paper ledger.
   Re-check paper balances and test persistence after a Render redeploy.
6. Keep manually exporting JSON backups; cloud storage is not itself a
   substitute for backups. **This code is a prototype, not security-audited.**

## Schema

- User credentials (salted scrypt hashes), session hashes, simulated account,
  paper trades, watchlist and scenario marks live in PostgreSQL.
- The `trades.id` identity sequence is resynchronized after JSON restores.
- All baseline SQLite tests run in local mode. SQL compatibility tests
  validate query translation, but integration tests require an actual Neon
  database to confirm connection and transaction behavior.
- No brokerage order submission; this remains paper-only.

## Known limitation

This transitional single-instance PostgreSQL adapter preserves the
application’s existing SQL workflow and enables remote persistence. It
has not yet been tested against a live Neon database. Do not use the
dashboard for real-money trading or as the only copy of important data.
