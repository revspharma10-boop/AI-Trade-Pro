"""Paper-only BTC/USD signal surveillance on completed candles.

No exchange APIs, no automatic paper entries. A scan records historical decisions
in durable storage; future schedulers can invoke the fail-closed job endpoint.
"""
from __future__ import annotations
from datetime import datetime, timezone
import time
from btc_lab import STRATEGIES, TIMEFRAMES, _regime, validate_candles, DataUnavailable

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_signal_checks (
 strategy TEXT NOT NULL, timeframe INTEGER NOT NULL,
 candle_time BIGINT NOT NULL, signal TEXT NOT NULL,
 close_price REAL NOT NULL, detected_at TEXT NOT NULL,
 PRIMARY KEY(strategy,timeframe,candle_time));
"""
POSTGRES_SCHEMA = """
CREATE TABLE IF NOT EXISTS btc_signal_checks (
 strategy TEXT NOT NULL, timeframe INTEGER NOT NULL,
 candle_time BIGINT NOT NULL, signal TEXT NOT NULL,
 close_price NUMERIC(20,4) NOT NULL, detected_at TEXT NOT NULL,
 PRIMARY KEY(strategy,timeframe,candle_time));
"""

class StaleCandle(DataUnavailable):
    pass


def evaluate(candles, timeframe: int, timestamp: int | None = None):
    """Scan only the latest *finished* candle and never retroactively create signals.

    We reject stale feeds and candles that have not closed; no future-price claims.
    The initial observation is not an order, even when a crossing is detected.
    """
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported BTC candle interval')
    candles = validate_candles(candles)
    now = int(time.time() if timestamp is None else timestamp)
    seconds = timeframe * 60
    stamp = candles[-1]['time']
    if stamp + seconds > now:
        raise StaleCandle('Latest BTC candle has not finished; no signal recorded')
    if now > stamp + 2 * seconds + 120:
        raise StaleCandle('BTC data is stale; no signal recorded')
    results = []
    for key, (name, _) in STRATEGIES.items():
        regime = _regime(candles, key)
        if len(regime) < 2:
            raise DataUnavailable('Not enough completed BTC candles')
        previous, current = regime[-2], regime[-1]
        action = 'BUY' if current and not previous else ('EXIT' if previous and not current else ('HOLD_LONG' if current else 'HOLD_FLAT'))
        results.append({'strategy':key,'name':name,'signal':action,
                        'candle_time':stamp, 'close_price':candles[-1]['close']})
    return results


def record(db, candles, timeframe, *, timestamp=None):
    decisions = evaluate(candles, timeframe, timestamp)
    now = datetime.fromtimestamp(int(time.time() if timestamp is None else timestamp), timezone.utc).isoformat(timespec='seconds')
    db.execute('BEGIN IMMEDIATE')
    try:
        for row in decisions:
            db.execute('''INSERT INTO btc_signal_checks
                (strategy,timeframe,candle_time,signal,close_price,detected_at)
                VALUES(?,?,?,?,?,?) ON CONFLICT(strategy,timeframe,candle_time) DO NOTHING''',
                (row['strategy'], timeframe, row['candle_time'],row['signal'], row['close_price'], now))
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK')
        raise
    return {'pair':'BTC/USD','timeframe_minutes':timeframe,'candle_time':decisions[0]['candle_time'],
            'checked_at':now,'source':'Kraken completed spot OHLC','signals':decisions,
            'paper_auto_execution_enabled':False,'real_order_execution_enabled':False,
            'notice':'Signals are observations from completed candles only. No paper or real orders are sent.'}


def history(db, timeframe: int = 60):
    if type(timeframe) is not int or timeframe not in TIMEFRAMES:
        raise DataUnavailable('Unsupported BTC candle interval')
    data = [dict(row) for row in db.execute('''SELECT strategy,timeframe,candle_time,signal,close_price,detected_at
       FROM btc_signal_checks WHERE timeframe=? ORDER BY candle_time DESC,strategy ASC LIMIT 60''',(timeframe,)).fetchall()]
    return {'pair':'BTC/USD','timeframe_minutes':timeframe,'checks':data,
            'paper_auto_execution_enabled':False,'real_order_execution_enabled':False,
            'scheduler_active':False,'notice':'Monitoring requires manual checks until a secure external scheduler is configured.'}
